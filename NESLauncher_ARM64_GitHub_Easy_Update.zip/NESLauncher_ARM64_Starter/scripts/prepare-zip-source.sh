#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZIP_PATH="${1:-}"

# If no path is supplied (e.g. a push-triggered workflow), prefer the stable
# upload name used for routine updates. This avoids relying on ZIP mtimes,
# which GitHub checkout may normalize. Otherwise choose the most recently
# committed root-level ZIP using Git history. If none exists, use checked-out files.
if [[ -z "$ZIP_PATH" ]]; then
  CANONICAL_ZIP="$ROOT/NESLauncher_ARM64_GitHub_Easy_Update.zip"
  if [[ -f "$CANONICAL_ZIP" ]]; then
    ZIP_PATH="$CANONICAL_ZIP"
  else
    ZIP_PATH="$(
      find "$ROOT" -maxdepth 1 -type f -iname '*.zip' -print0 \
        | while IFS= read -r -d '' candidate; do
            committed_at="$(git -C "$ROOT" log -1 --format=%ct -- "$candidate" 2>/dev/null || true)"
            [[ -n "$committed_at" ]] || committed_at="$(stat -c %Y "$candidate")"
            printf '%s %s\n' "$committed_at" "$candidate"
          done \
        | sort -nr | head -n 1 | cut -d' ' -f2- || true
    )"
  fi
fi

if [[ -z "$ZIP_PATH" ]]; then
  echo "No root-level ZIP found; using source files already checked out."
  exit 0
fi
if [[ "$ZIP_PATH" != /* ]]; then ZIP_PATH="$ROOT/$ZIP_PATH"; fi
if [[ ! -f "$ZIP_PATH" ]]; then
  echo "ERROR: source ZIP not found: $ZIP_PATH" >&2
  exit 2
fi

# Reject archive paths that could write outside the extraction directory.
while IFS= read -r entry; do
  case "$entry" in
    /*|..|../*|*/../*|*/..) echo "ERROR: unsafe ZIP entry: $entry" >&2; exit 3 ;;
  esac
done < <(unzip -Z1 "$ZIP_PATH")
unzip -tq "$ZIP_PATH"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
unzip -q "$ZIP_PATH" -d "$TMP_DIR"
PROJECT_FILE="$(find "$TMP_DIR" -type f -name settings.gradle.kts -print -quit)"
if [[ -z "$PROJECT_FILE" ]]; then
  echo "ERROR: ZIP does not contain a Gradle Android project (settings.gradle.kts missing)." >&2
  exit 4
fi
PROJECT_ROOT="$(dirname "$PROJECT_FILE")"
if [[ ! -d "$PROJECT_ROOT/app/src/main" || ! -f "$PROJECT_ROOT/app/build.gradle.kts" ]]; then
  echo "ERROR: ZIP project layout is incomplete (app/src/main or app/build.gradle.kts missing)." >&2
  exit 5
fi

# Copy the archive's project contents over the checkout. The ZIP itself stays
# in the repository root and is not copied into the Gradle project directory.
cp -a "$PROJECT_ROOT/." "$ROOT/"
echo "Prepared Android project from ZIP: $(basename "$ZIP_PATH")"
echo "Gradle project root: $ROOT"
