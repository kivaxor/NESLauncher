# Native test results

## Recompiler (2026-10-24)

- Unit tests (ASan + UBSan): 10 existing + `jit_diff_test` (100k random blocks, 0 mismatches) + `jit_machine_test` pass.
- `jit_rom_parity` over 149 public test/homebrew ROMs, 300 frames each (interpreter vs ARM64 code in Unicorn): identical frames, CPU registers, RAM and cycle counts. 10 ROMs skipped (unsupported mappers).
- Not verified: execution on a real ARM64 device, performance.


Date: 2026-10-23

Host toolchain: GNU C++ 14.2.0, C++20.

## Strict warning build

```sh
cmake -S app/src/main/cpp -B build-werror -DBUILD_NES_TESTS=ON -DCMAKE_CXX_FLAGS='-Werror'
cmake --build build-werror -j2
ctest --test-dir build-werror --output-on-failure
```

Result: **7/7 tests passed** (`cpu6502_test`, `rom_parser_test`, `nrom_test`, `ppu2c02_test`, `nes_machine_test`, `controller_test`, `dma_test`). Build uses `-Wall -Wextra -Wpedantic -Werror`.

## Coverage
- ROM parser: header/signature checks, truncation, and trainer offset.
- NROM: 16 KiB mirroring, 32 KiB PRG mapping, CHR ROM read-only and CHR RAM writable, PRG RAM, trainer copy, reset vector, CPU fetch from mapped ROM, and rejection of unsupported mapper/layout.
- CPU: RAM mirroring, official instruction subset, flags and ADC overflow, branch timing, indexed page crossing and zero-page wrap, NMOS JMP-indirect page-wrap behavior, JSR/RTS stack flow, and NMI/IRQ entry/stack semantics.
- PPU: pattern RAM, palette masking and universal-background aliases, horizontal and vertical nametable mirroring, PPUADDR/PPUDATA buffering, VRAM increment-by-32, vblank status clearing, NMI-enable behavior, CPU-visible PPU register mirrors, background tile bitplane decoding, palette selection, disabled-background fill, left-edge clipping, sprite palette, sprite/background priority, and sprite-zero overlap flag.
- Machine integration: reject run without a ROM, load synthetic NROM, reset-vector mapping, execute CPU/PPU until a frame boundary, return a 256×240 frame, and report invalid ROM load.
- OAM DMA: copy all 256 bytes from CPU RAM pages to PPU OAM, verify OAM address wrap, and verify DMA stall-cycle consumption.

## Sanitizer build

```sh
cmake -S app/src/main/cpp -B build-asan -DBUILD_NES_TESTS=ON -DCMAKE_CXX_FLAGS='-fsanitize=address,undefined -g' -DCMAKE_EXE_LINKER_FLAGS='-fsanitize=address,undefined'
cmake --build build-asan -j2
ctest --test-dir build-asan --output-on-failure
```

Result: **7/7 tests passed** under AddressSanitizer and UndefinedBehaviorSanitizer.

## Limitations
These unit tests do not establish full NES compatibility. The PPU snapshot renderer supports basic background and sprite composition but not scrolling or dot/scanline-accurate sprite evaluation/timing. APU, non-NROM mappers, save states, full save states, complete undocumented CPU opcode behavior, cycle-accurate bus timing, and dynamic ARM64 recompilation remain unfinished. Android APK build and gameplay have not been verified.


## Update: PPU timing dasar

- Menambahkan clock PPU NTSC dengan rasio 3 dot per siklus CPU.
- Memodelkan transisi VBlank pada scanline 241 dot 1 dan membersihkan status pada pre-render scanline 261 dot 1.
- Menambahkan tes posisi scanline/dot, permintaan NMI, dan pembersihan VBlank.
- Verifikasi terbaru: 4/4 tes lulus dengan `-Werror` dan 4/4 lulus dengan AddressSanitizer + UndefinedBehaviorSanitizer.
- Batasan: belum ada odd-frame dot skip, raster rendering cycle-accurate, atau integrasi clock CPU/PPU ke loop gameplay Android.


## Update: CPU/PPU machine coordinator and Android frame preview

- Added `NesMachine` to coordinate NROM loading, CPU instruction execution, 3:1 NTSC PPU clocking, NMI forwarding, and one-frame snapshot output.
- Added JNI methods to load a ROM and request the next framebuffer; Kotlin now has explicit "Muat ROM NROM" and "Render Frame" controls and converts palette indices to an Android `Bitmap`.
- Strict warning build: **5/5 tests passed**.
- AddressSanitizer + UndefinedBehaviorSanitizer build: **5/5 tests passed**.
- Android APK build is still unverified because Android SDK/Gradle tooling is not installed in this environment. Frame rendering is manual and does not yet represent a complete playable emulator.


## Update: NES controller serial ports and Android touch controls

- CPU bus now implements controller strobe/latch reads at `$4016` and `$4017`, including serial button order and the post-eight-read high bit.
- JNI exposes `nativeSetControllerState`; Android UI includes touch controls for directions, A/B, Select, and Start. Buttons are press/release based, not toggle based.
- Added `controller_test` covering strobe behavior, all eight serialized bits, player-two input, and port bit 6.
- Strict warning build: **6/6 tests passed**. AddressSanitizer + UndefinedBehaviorSanitizer: **6/6 tests passed**.
- This is not yet a real-time playable APK: the app still advances only when the user taps Render Frame, and Android SDK/Gradle are unavailable in this environment.
- Frame presentation posts are coalesced with an atomic pending flag to avoid unbounded UI callback buildup if the main thread is temporarily busy.


## Update: reset-safe ROM replacement (2026-10-23)

- `CpuBus::reset()` clears volatile RAM and controller state while preserving device connections.
- `Ppu2C02::reset()` resets volatile PPU memory/registers and timing/frame counters.
- Machine integration test now checks that reloading starts from frame zero and a failed ROM replacement disables further frame execution.
- Strict `-Werror` build: **6/6 passed**.
- AddressSanitizer + UndefinedBehaviorSanitizer build: **6/6 passed**.
- Android APK build/device testing remains unverified.


## Update: OAM DMA foundation (2026-10-23)

- Implemented CPU write `$4014`: copies 256 bytes from the selected CPU address page into PPU OAM starting at current OAMADDR, with byte-address wrap.
- The machine advances PPU timing for the 513-cycle DMA stall and clears the pending stall once consumed. This instruction-level implementation uses a fixed 513-cycle stall; hardware parity-dependent 513/514 timing and per-cycle bus contention remain future work.
- Added `dma_test` to verify every copied byte for two pages, OAM wrap behavior, and one-shot stall consumption.
- Strict `-Werror` build: **7/7 passed**. AddressSanitizer + UBSan build: **7/7 passed**.
- Android APK build and device gameplay remain unverified.


## Scroll-aware renderer update (2026-10-23)
- Added background sampling from coarse/fine scroll values written through PPU `$2005`, base nametable bits, and horizontal/vertical nametable crossing.
- Added horizontal coarse-scroll and fine-X regression assertions to `ppu2c02_test`.
- Strict native build with `-Werror`: 7/7 tests passed.
- Android build and device gameplay remain unverified.


## Update: NTSC odd-frame dot skip (2026-10-23)

- Implemented the 2C02 one-dot skip at pre-render dot 339 on odd frames when rendering is enabled (`PPUMASK` background or sprite bit set).
- Added regression checks proving the rendered frame is one PPU dot shorter and rendering-disabled frames keep the full duration.
- Strict `-Werror` build: **7/7 passed**. AddressSanitizer + UndefinedBehaviorSanitizer: **7/7 passed**.
- This does not make the PPU cycle-accurate; the renderer still composes a frame snapshot. Android APK/device testing remains unverified.

## Update: PPU grayscale output (2026-10-23)

- Renderer now applies `PPUMASK` bit 0 as grayscale output (`palette_index & $30`) for universal background, background pixels, and sprite pixels.
- Palette RAM is not modified; disabling grayscale restores full six-bit palette indices.
- Added regression checks for grayscale background output and unchanged palette RAM.
- Strict `-Werror` build: **7/7 passed**.
- Android APK/device testing remains unverified; emphasis output and per-dot video behavior are not modeled.


Battery RAM regression coverage verifies exact 8 KiB export/import for iNES cartridges with the battery flag, rejects wrong-sized blobs, and refuses persistence operations for cartridges without battery-backed RAM. Kotlin app-private file persistence is now wired to the JNI hooks; device validation remains outstanding.

## Update: battery-backed PRG RAM API (2026-10-23)

- Added exact 8 KiB battery RAM export/import methods to the NROM cartridge and machine layers.
- Added JNI hooks `nativeExportBatteryRam` and `nativeImportBatteryRam`, protected by the same machine mutex as frame execution and ROM operations.
- Regression tests verify export/import round-trip, exact length validation, and rejection when the iNES battery flag is not set.
- Strict `-Werror` native suite: **7/7 passed**.
- AddressSanitizer + UndefinedBehaviorSanitizer suite: **7/7 passed**.
- JNI syntax check with JDK 21 headers: passed.
- Kotlin now calls these hooks and uses app-private AtomicFile persistence keyed by the ROM SHA-256. The flow restores on successful ROM load and saves on pause/lifecycle/ROM replacement. Native tests and JNI syntax check pass; Android Gradle/APK build and on-device persistence remain unverified.


## Update: automatic Android battery RAM persistence (2026-10-23)

- Added Kotlin declarations for native battery RAM export/import and wired them to private app storage.
- Each ROM gets its own save filename based on SHA-256 of the ROM bytes.
- Uses `AtomicFile`, flushes file data with `fd.sync()`, and calls `finishWrite`/`failWrite` to protect against partial writes.
- Restores save RAM after successful ROM loading; saves when pausing emulation, leaving the Activity, and before ROM replacement.
- Native strict build: **7/7 passed**. ASan + UBSan: **7/7 passed**.
- Android/Kotlin compilation and actual device persistence are still unverified because Android SDK/Gradle are unavailable in this environment.


## Regression test tambahan
- Penggantian ROM dengan mapper yang tidak didukung ditolak tanpa menghapus cartridge yang sedang aktif.
- PRG RAM berbaterai tetap berisi data yang sama setelah percobaan penggantian ROM gagal.
- Mesin tetap berjalan dan frame berikutnya dapat diproses setelah pemuatan ROM pengganti gagal.


## Update: sprite OAM priority regression (2026-10-23)

- Fixed snapshot sprite composition to process OAM entries in ascending order. The first opaque pixel now belongs to the lower OAM index, matching NES sprite priority rules.
- Added a regression with two overlapping opaque sprites using different palettes; it verifies sprite 0 wins.
- Strict C++20 `-Werror` build and ASan + UBSan suite: **7/7 passed** each.
- This remains snapshot composition; cycle-accurate sprite evaluation, overflow behavior, and sprite-zero timing are not implemented.


## Update: CPU edge-case regression coverage (2026-10-23)

- Added deterministic tests for zero-page indexed wrap, the NMOS 6502 `JMP ($xxFF)` page-wrap quirk, NMI stack/vector behavior, IRQ deferral while the interrupt-disable flag is set, and ADC overflow/carry independence.
- Added `CpuBus::set_vector()` so host tests can install NMI/IRQ vectors in backing memory without pretending to write into cartridge ROM. `set_reset_vector()` now uses the same helper.
- Strict C++20 `-Werror` build and native suite: **7/7 passed**. AddressSanitizer + UndefinedBehaviorSanitizer suite: **7/7 passed**.
- Android APK/device gameplay remains unverified.

## Update: edge-triggered PPU NMI (2026-10-23)

- Corrected the PPU NMI request logic to model the NMI output as a line derived from `PPUSTATUS.VBlank` and `PPUCTRL.NMI-enable`. A request is queued only on a low-to-high transition, not every time `PPUCTRL` is rewritten while VBlank remains active.
- Enabling NMI during an already-active VBlank still creates the required rising edge; disabling and re-enabling creates a new edge. Reading `PPUSTATUS` clears VBlank and cancels a pending request.
- Added regression coverage for enable-during-VBlank, duplicate control writes, line drop/rise, and status-read cancellation.
- Strict C++20 `-Werror` build: **7/7 passed**. AddressSanitizer + UndefinedBehaviorSanitizer: **7/7 passed**.
- PPU remains a frame-snapshot renderer; accurate cycle-level NMI race timing and Android APK/device gameplay are not yet verified.



## Update: OAM DMA parity model (2026-10-23)

- DMA requests are counted until the machine knows the current instruction's cycle length, then charged 513 cycles for estimated even-cycle alignment or 514 for estimated odd-cycle alignment.
- The machine tracks cumulative CPU cycles across frames and resets the counter when a ROM is loaded.
- Regression tests cover both stall lengths and ensure pending DMA requests are consumed once.
- Limitation: because CPU instructions execute atomically, the DMA start parity is inferred from the instruction's final cycle; exact bus-cycle alignment still requires a cycle-stepped CPU core.

### Android APK build path (2026-10-23)

- Added `scripts/build-android-apk.sh` to validate the required local Android SDK components, run `assembleDebug`, and copy the APK to `dist/NESLauncher-debug.apk`.
- Added `.github/workflows/android-apk.yml` to build a debug APK with Java 17, Gradle 8.9, Android SDK 35, CMake 3.22.1, and NDK 27.2.12479018, then publish it as a short-lived workflow artifact.
- Environment check: this workspace has Java 21 but no Gradle executable, Android SDK, or Android NDK. Therefore no APK could be generated or installed/tested in this workspace. The GitHub workflow is a build route, not proof that a build has succeeded.
- Native strict `-Werror` tests: **7/7 passed**. Native ASan + UBSan tests: **7/7 passed**.


## Update: indirect-indexed CPU page-crossing penalties (2026-10-23)

- Fixed the instruction table for ORA, AND, EOR, ADC, CMP, and SBC using `(zero page),Y`: these are now marked as page-crossing-sensitive reads.
- Added a regression that places the indirect pointer at `$00FF`, uses `Y=1`, and verifies all six opcodes consume 6 cycles when the effective address crosses to `$0100`.
- Native strict `-Werror` tests: **7/7 passed**. Native ASan + UBSan tests: **7/7 passed**.


## Update: reliable ZIP auto-selection (2026-10-23)

- The GitHub workflow's ZIP preparation script now prefers the stable root filename `NESLauncher_ARM64_GitHub_Easy_Update.zip`.
- If that filename is absent, it selects the most recently committed root-level ZIP from Git history, with filesystem time as a fallback; this avoids depending solely on mtimes normalized by GitHub checkout.
- ZIP path traversal entries are still rejected, the archive is integrity-tested, and the Gradle project layout is validated before copying files into the checkout.
- This script change was reviewed and is scheduled for an isolated extraction smoke test; the GitHub-hosted workflow itself has not been run from a remote repository in this environment.


## Update: mapper, PPU per-scanline, APU (2026-10-23)

- Mapper baru: UxROM, CNROM, AxROM, dan MMC1 (mode PRG 0–3, mode CHR 4/8 KiB, mirroring, reset serial) diuji di `mapper_test`; mapper tak didukung (mis. 4) ditolak tanpa mengubah cartridge aktif.
- `ppu_scanline_test`: scroll tengah frame hanya memengaruhi scanline berikutnya, fine-X dan clipping 8 piksel kiri, waktu sprite-zero hit per dot, dan overflow sprite.
- `apu_test`: keheningan, pulse/triangle/noise menghasilkan keluaran, length counter, IRQ frame counter beserta inhibit, serta integrasi mesin (ROM kecil yang menyalakan pulse 1 menghasilkan sampel audio tiap frame).
- Verifikasi (g++ 13.3, C++20): **10/10 tes lulus** dengan `-Wall -Wextra -Wpedantic -Werror`, dan **10/10 lulus** dengan AddressSanitizer + UndefinedBehaviorSanitizer. Dikompilasi langsung dengan `g++` (CMake tidak tersedia di lingkungan ini).
- `native-lib.cpp` diperiksa sintaksnya dengan stub `jni.h`, dan sembilan nama fungsi JNI cocok dengan sembilan deklarasi `external fun` di Kotlin.
- Belum terverifikasi: kompilasi Kotlin, `CMakeLists.txt` lewat CMake sungguhan, build APK, dan audio/gameplay di perangkat.

## Perbaikan performa JIT (lag + suara kelek)
- Penyebab utama: setiap pergantian bank PRG (mapper 1/2/4/7) membuang SELURUH cache blok JIT, mengisi ulang tabel ±1,3 MB, lalu menerjemahkan ulang semua blok panas (tiap blok = 2 syscall `mprotect`). Game dengan bank switching jadi sangat berat; frame yang terlambat membuat buffer audio kosong (suara kelek).
- Perbaikan: cache blok dan tabel chain sekarang per-mapping PRG (maks 8, LRU), jadi pindah bank tidak menerjemahkan ulang. Backend native memakai satu mapping RWX (tanpa `mprotect` per blok; otomatis kembali ke W^X bila ditolak sistem).
- Audio: buffer AudioTrack minimal ±100 ms dan diisi hening ±60 ms di awal.
- UI menampilkan FPS, ms CPU per frame (rata-rata/terburuk), dan statistik JIT tiap detik.
- Tes baru `jit_context_test` (logika konteks: 1 slot → terjemah ulang tiap ganti, 8 slot → pakai ulang; LRU). 10 tes unit lama tetap lulus (ASan+UBSan). Tes Unicorn dan perangkat ARM64 nyata belum dijalankan di lingkungan ini.

## Kontrol virtual (VirtualPadView)
- Ditambahkan `VirtualPadView.kt` + menu Kontrol di `MainActivity.kt`. Kode Kotlin ini belum dikompilasi di lingkungan pengembangan (tidak ada Kotlin/Android SDK); verifikasi pertama terjadi lewat workflow GitHub Actions dan uji di perangkat.
