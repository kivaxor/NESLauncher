package com.example.neslauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Kontrol virtual NES yang digambar sendiri dan mendukung multitouch penuh.
 *
 * - D-pad satu kesatuan: geser jari dari arah ke arah lain, diagonal otomatis.
 * - Mode atur: seret tombol untuk memindah, ketuk untuk memilih, ubah ukuran dengan resizeSelected().
 * - Tata letak, ukuran, transparansi, getaran, dan tombol turbo disimpan di SharedPreferences.
 */
internal class VirtualPadView(
    context: Context,
    private val prefs: SharedPreferences,
    private val onState: (Int) -> Unit
) : View(context) {

    private enum class Kind { DPAD, ROUND, PILL }

    private class Control(
        val id: String,
        val kind: Kind,
        val label: String,
        val mask: Int,
        val baseW: Float,       // dp
        val baseH: Float,       // dp
        val defX: Float,        // pusat, pecahan lebar view
        val defY: Float,        // pusat, pecahan tinggi view
        val optional: Boolean = false,
        val turbo: Boolean = false
    ) {
        var x = defX
        var y = defY
        var scale = 1f
        var visible = !optional
        val rect = RectF()
    }

    private companion object {
        const val A = 0x01
        const val B = 0x02
        const val SELECT = 0x04
        const val START = 0x08
        const val UP = 0x10
        const val DOWN = 0x20
        const val LEFT = 0x40
        const val RIGHT = 0x80
        const val MIN_SCALE = 0.5f
        const val MAX_SCALE = 2.0f
        const val TURBO_INTERVAL_MS = 33L
        const val KEY_ALPHA = "pad_alpha"
        const val KEY_HAPTIC = "pad_haptic"
    }

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    private val controls = listOf(
        Control("dpad", Kind.DPAD, "", 0, 150f, 150f, 0.24f, 0.46f),
        Control("b", Kind.ROUND, "B", B, 72f, 72f, 0.66f, 0.58f),
        Control("a", Kind.ROUND, "A", A, 72f, 72f, 0.87f, 0.44f),
        Control("select", Kind.PILL, "SELECT", SELECT, 92f, 38f, 0.37f, 0.91f),
        Control("start", Kind.PILL, "START", START, 92f, 38f, 0.63f, 0.91f),
        Control("turbo_b", Kind.ROUND, "TB", B, 56f, 56f, 0.60f, 0.26f, optional = true, turbo = true),
        Control("turbo_a", Kind.ROUND, "TA", A, 56f, 56f, 0.87f, 0.14f, optional = true, turbo = true)
    )

    // ---- pengaturan yang bisa diubah pengguna ----
    var opacityPercent: Int = 70
        set(value) { field = value.coerceIn(20, 100); invalidate() }
    var haptic: Boolean = true

    var editMode: Boolean = false
        set(value) {
            if (field == value) return
            releaseAll()
            field = value
            dragging = null
            invalidate()
        }

    var turboVisible: Boolean
        get() = controls.first { it.id == "turbo_a" }.visible
        set(value) {
            controls.filter { it.turbo }.forEach { it.visible = value }
            updateRects()
            invalidate()
        }

    private var selected: Control? = null
    private var dragging: Control? = null
    private var dragDx = 0f
    private var dragDy = 0f

    // ---- keadaan tekan ----
    private val pressedIds = HashSet<String>()
    private var dpadBits = 0
    private var heldMask = 0
    private var turboMask = 0
    private var turboPhase = true
    private var turboRunning = false
    private var lastSent = 0

    private val turboRunnable = object : Runnable {
        override fun run() {
            if (turboMask == 0) { turboRunning = false; return }
            turboPhase = !turboPhase
            emit()
            postDelayed(this, TURBO_INTERVAL_MS)
        }
    }

    // ---- cat ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val path = Path()
    private val tmp = RectF()

    init {
        isFocusable = false
        load()
    }

    // ---- penyimpanan ----
    private fun load() {
        opacityPercent = prefs.getInt(KEY_ALPHA, 70)
        haptic = prefs.getBoolean(KEY_HAPTIC, true)
        for (c in controls) {
            c.x = prefs.getFloat("pad_${c.id}_x", c.defX).coerceIn(0f, 1f)
            c.y = prefs.getFloat("pad_${c.id}_y", c.defY).coerceIn(0f, 1f)
            c.scale = prefs.getFloat("pad_${c.id}_s", 1f).coerceIn(MIN_SCALE, MAX_SCALE)
            if (c.optional) c.visible = prefs.getBoolean("pad_${c.id}_v", false)
        }
    }

    fun save() {
        val e = prefs.edit()
        e.putInt(KEY_ALPHA, opacityPercent)
        e.putBoolean(KEY_HAPTIC, haptic)
        for (c in controls) {
            e.putFloat("pad_${c.id}_x", c.x)
            e.putFloat("pad_${c.id}_y", c.y)
            e.putFloat("pad_${c.id}_s", c.scale)
            if (c.optional) e.putBoolean("pad_${c.id}_v", c.visible)
        }
        e.apply()
    }

    fun resetLayout() {
        for (c in controls) { c.x = c.defX; c.y = c.defY; c.scale = 1f }
        opacityPercent = 70
        updateRects()
        invalidate()
        save()
    }

    /** Ubah ukuran tombol yang dipilih (delta dalam pecahan, mis. 0.1 = 10%). */
    fun resizeSelected(delta: Float): Boolean {
        val c = selected ?: return false
        c.scale = (c.scale + delta).coerceIn(MIN_SCALE, MAX_SCALE)
        updateRects()
        invalidate()
        return true
    }

    fun hasSelection(): Boolean = selected != null

    /** Lepas semua tombol (dipakai saat jeda / pindah aplikasi). */
    fun releaseAll() {
        removeCallbacks(turboRunnable)
        turboRunning = false
        pressedIds.clear()
        dpadBits = 0
        heldMask = 0
        turboMask = 0
        if (lastSent != 0) { lastSent = 0; onState(0) }
        invalidate()
    }

    // ---- tata letak ----
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateRects()
    }

    private fun updateRects() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        for (c in controls) {
            var cw = dp(c.baseW) * c.scale
            var ch = dp(c.baseH) * c.scale
            // jangan lebih besar dari area yang tersedia
            val fit = min(1f, min(w / cw, h / ch))
            cw *= fit; ch *= fit
            val cx = (c.x * w).coerceIn(cw / 2, max(cw / 2, w - cw / 2))
            val cy = (c.y * h).coerceIn(ch / 2, max(ch / 2, h - ch / 2))
            c.rect.set(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2)
        }
    }

    // ---- sentuhan ----
    override fun onTouchEvent(e: MotionEvent): Boolean {
        return if (editMode) handleEdit(e) else handlePlay(e)
    }

    private fun handlePlay(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            parent?.requestDisallowInterceptTouchEvent(true)
            // Kirim sentuhan segera, jangan digabung per vsync (menghemat rata-rata sekitar 8 ms).
            requestUnbufferedDispatch(e)
        }
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        val release = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL

        val beforeIds = HashSet(pressedIds)
        val beforeDpad = dpadBits
        pressedIds.clear()
        dpadBits = 0
        var held = 0
        var turbo = 0
        if (!release) {
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                val px = e.getX(i)
                val py = e.getY(i)
                for (c in controls) {
                    if (!c.visible) continue
                    val m = maskAt(c, px, py)
                    if (m == 0) continue
                    pressedIds.add(c.id)
                    if (c.kind == Kind.DPAD) dpadBits = dpadBits or m
                    if (c.turbo) turbo = turbo or m else held = held or m
                }
            }
        }
        val newlyPressed = pressedIds.any { it !in beforeIds } || (dpadBits and beforeDpad.inv()) != 0

        heldMask = held
        turboMask = turbo
        if (turbo != 0) {
            if (!turboRunning) {
                turboRunning = true
                turboPhase = true
                postDelayed(turboRunnable, TURBO_INTERVAL_MS)
            }
        } else {
            removeCallbacks(turboRunnable)
            turboRunning = false
        }
        emit()                       // kirim ke emulator lebih dulu; getar menyusul
        if (haptic && newlyPressed) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        invalidate()
        return true
    }

    private fun emit() {
        val effective = heldMask or (if (turboPhase) turboMask else 0)
        if (effective != lastSent) {
            lastSent = effective
            onState(effective)
        }
    }

    /** Mask tombol NES yang ditekan oleh jari di (px, py) pada kontrol ini; 0 bila di luar. */
    private fun maskAt(c: Control, px: Float, py: Float): Int {
        val cx = c.rect.centerX()
        val cy = c.rect.centerY()
        return when (c.kind) {
            Kind.DPAD -> {
                val size = c.rect.width()
                val dx = px - cx
                val dy = py - cy
                if (hypot(dx, dy) > size * 0.62f) return 0
                val t = size * 0.16f
                var m = 0
                if (dy < -t) m = m or UP
                if (dy > t) m = m or DOWN
                if (dx < -t) m = m or LEFT
                if (dx > t) m = m or RIGHT
                m
            }
            Kind.ROUND -> if (hypot(px - cx, py - cy) <= c.rect.width() / 2f * 1.12f) c.mask else 0
            Kind.PILL -> {
                tmp.set(c.rect)
                tmp.inset(-dp(6f), -dp(6f))
                if (tmp.contains(px, py)) c.mask else 0
            }
        }
    }

    private fun handleEdit(e: MotionEvent): Boolean {
        val px = e.x
        val py = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val hit = controls.lastOrNull { c ->
                    c.visible && run {
                        tmp.set(c.rect)
                        tmp.inset(-dp(8f), -dp(8f))
                        tmp.contains(px, py)
                    }
                }
                if (hit != null) {
                    selected = hit
                    dragging = hit
                    dragDx = px - hit.rect.centerX()
                    dragDy = py - hit.rect.centerY()
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val c = dragging
                if (c != null && width > 0 && height > 0) {
                    c.x = ((px - dragDx) / width).coerceIn(0f, 1f)
                    c.y = ((py - dragDy) / height).coerceIn(0f, 1f)
                    updateRects()
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging != null) save()
                dragging = null
            }
        }
        return true
    }

    // ---- gambar ----
    private fun withAlpha(color: Int, pct: Int): Int =
        (color and 0x00FFFFFF) or ((pct.coerceIn(0, 100) * 255 / 100) shl 24)

    override fun onDraw(canvas: Canvas) {
        val normal = withAlpha(0xFF3A3A3A.toInt(), opacityPercent)
        val down = withAlpha(0xFFE53935.toInt(), min(100, opacityPercent + 15))
        val glyph = withAlpha(0xFFFFFFFF.toInt(), min(100, opacityPercent + 20))
        for (c in controls) {
            if (!c.visible) continue
            when (c.kind) {
                Kind.DPAD -> drawDpad(canvas, c, normal, down, glyph)
                Kind.ROUND -> {
                    val isDown = c.id in pressedIds
                    fill.style = Paint.Style.FILL
                    fill.color = if (isDown) down else normal
                    canvas.drawCircle(c.rect.centerX(), c.rect.centerY(), c.rect.width() / 2f, fill)
                    drawLabel(canvas, c, c.label, glyph, c.rect.width() * (if (c.turbo) 0.30f else 0.38f))
                }
                Kind.PILL -> {
                    val isDown = c.id in pressedIds
                    fill.style = Paint.Style.FILL
                    fill.color = if (isDown) down else normal
                    canvas.drawRoundRect(c.rect, c.rect.height() / 2f, c.rect.height() / 2f, fill)
                    drawLabel(canvas, c, c.label, glyph, c.rect.height() * 0.38f)
                }
            }
            if (editMode) drawEditOutline(canvas, c)
        }
    }

    private fun drawLabel(canvas: Canvas, c: Control, label: String, color: Int, size: Float) {
        text.color = color
        text.textSize = size
        val y = c.rect.centerY() - (text.ascent() + text.descent()) / 2f
        canvas.drawText(label, c.rect.centerX(), y, text)
    }

    private fun drawDpad(canvas: Canvas, c: Control, normal: Int, down: Int, glyph: Int) {
        val r = c.rect
        val size = r.width()
        val t = size / 3f                       // tebal lengan
        val cx = r.centerX()
        val cy = r.centerY()
        val round = size * 0.08f

        // Bentuk plus sebagai satu path supaya area tengah tidak ganda saat transparan.
        path.reset()
        val vertical = Path().apply { addRoundRect(cx - t / 2, r.top, cx + t / 2, r.bottom, round, round, Path.Direction.CW) }
        val horizontal = Path().apply { addRoundRect(r.left, cy - t / 2, r.right, cy + t / 2, round, round, Path.Direction.CW) }
        path.op(vertical, horizontal, Path.Op.UNION)
        fill.style = Paint.Style.FILL
        fill.color = normal
        canvas.drawPath(path, fill)

        // Sorot arah yang ditekan.
        fill.color = down
        if (dpadBits and UP != 0) canvas.drawRoundRect(cx - t / 2, r.top, cx + t / 2, r.top + t, round, round, fill)
        if (dpadBits and DOWN != 0) canvas.drawRoundRect(cx - t / 2, r.bottom - t, cx + t / 2, r.bottom, round, round, fill)
        if (dpadBits and LEFT != 0) canvas.drawRoundRect(r.left, cy - t / 2, r.left + t, cy + t / 2, round, round, fill)
        if (dpadBits and RIGHT != 0) canvas.drawRoundRect(r.right - t, cy - t / 2, r.right, cy + t / 2, round, round, fill)

        // Panah.
        val off = size / 2f - t / 2f
        fill.color = glyph
        drawArrow(canvas, cx, cy - off, 0f, -1f, t * 0.28f)
        drawArrow(canvas, cx, cy + off, 0f, 1f, t * 0.28f)
        drawArrow(canvas, cx - off, cy, -1f, 0f, t * 0.28f)
        drawArrow(canvas, cx + off, cy, 1f, 0f, t * 0.28f)
    }

    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, dx: Float, dy: Float, s: Float) {
        // segitiga menghadap (dx, dy)
        val tipX = cx + dx * s
        val tipY = cy + dy * s
        val baseX = cx - dx * s * 0.6f
        val baseY = cy - dy * s * 0.6f
        val px = -dy * s * 0.9f
        val py = dx * s * 0.9f
        path.reset()
        path.moveTo(tipX, tipY)
        path.lineTo(baseX + px, baseY + py)
        path.lineTo(baseX - px, baseY - py)
        path.close()
        canvas.drawPath(path, fill)
    }

    private fun drawEditOutline(canvas: Canvas, c: Control) {
        val isSel = c === selected
        stroke.strokeWidth = dp(if (isSel) 2.5f else 1.5f)
        stroke.color = if (isSel) 0xFFFFC107.toInt() else 0xAAFFFFFF.toInt()
        stroke.pathEffect = if (isSel) null else DashPathEffect(floatArrayOf(dp(6f), dp(4f)), 0f)
        tmp.set(c.rect)
        tmp.inset(-dp(4f), -dp(4f))
        canvas.drawRoundRect(tmp, dp(10f), dp(10f), stroke)
        stroke.pathEffect = null
    }
}
