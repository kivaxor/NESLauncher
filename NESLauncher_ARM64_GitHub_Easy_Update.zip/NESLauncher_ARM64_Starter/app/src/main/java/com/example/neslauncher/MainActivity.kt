package com.example.neslauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AtomicFile
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : ComponentActivity() {
    private external fun nativeEngineStatus(): String
    private external fun nativeInspectRom(bytes: ByteArray): String
    private external fun nativeLoadRom(bytes: ByteArray): String
    private external fun nativeRunFrame(): ByteArray?
    private external fun nativeTakeAudio(): ShortArray?
    private external fun nativeAudioSampleRate(): Int
    private external fun nativeSetControllerState(player: Int, buttons: Int)
    private external fun nativeExportBatteryRam(): ByteArray?
    private external fun nativeImportBatteryRam(bytes: ByteArray): String
    private external fun nativeSetRecompiler(enabled: Boolean): Boolean
    private external fun nativeRecompilerActive(): Boolean
    private external fun nativeJitStats(): String
    private var controllerButtons = 0
    private lateinit var screenView: ScreenView
    private var romLoaded = false
    private var selectedRom: ByteArray? = null
    private var activeRomSaveKey: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val emulationExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "NES-emulation").apply { isDaemon = true }
    }
    private val emulationRunning = AtomicBoolean(false)
    private val frameUpdatePending = AtomicBoolean(false)
    private val nativeAccessLock = Any()
    private val emulationGeneration = AtomicLong(0L)
    private lateinit var toggleButton: Button
    private lateinit var jitButton: Button
    private var recompilerWanted = true
    private val prefs by lazy { getSharedPreferences("neslauncher", Context.MODE_PRIVATE) }
    private var frameBitmap: Bitmap? = null
    private val frameArgb = IntArray(256 * 240)

    companion object {
        init {
            System.loadLibrary("nesengine")
        }

        // Standard 64-entry NTSC NES palette, represented as opaque Android ARGB.
        private val NES_PALETTE = intArrayOf(
            0xFF666666.toInt(), 0xFF002A88.toInt(), 0xFF1412A7.toInt(), 0xFF3B00A4.toInt(),
            0xFF5C007E.toInt(), 0xFF6E0040.toInt(), 0xFF6C0600.toInt(), 0xFF561D00.toInt(),
            0xFF333500.toInt(), 0xFF0B4800.toInt(), 0xFF005200.toInt(), 0xFF004F08.toInt(),
            0xFF00404D.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFADADAD.toInt(), 0xFF155FD9.toInt(), 0xFF4240FF.toInt(), 0xFF7527FE.toInt(),
            0xFFA01ACC.toInt(), 0xFFB71E7B.toInt(), 0xFFB53120.toInt(), 0xFF994E00.toInt(),
            0xFF6B6D00.toInt(), 0xFF388700.toInt(), 0xFF0C9300.toInt(), 0xFF008F32.toInt(),
            0xFF007C8D.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFFFFEFF.toInt(), 0xFF64B0FF.toInt(), 0xFF9290FF.toInt(), 0xFFC676FF.toInt(),
            0xFFF36AFF.toInt(), 0xFFFE6ECC.toInt(), 0xFFFE8170.toInt(), 0xFFEA9E22.toInt(),
            0xFFBCBE00.toInt(), 0xFF88D800.toInt(), 0xFF5CE430.toInt(), 0xFF45E082.toInt(),
            0xFF48CDDE.toInt(), 0xFF4F4F4F.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFFFFEFF.toInt(), 0xFFC0DFFF.toInt(), 0xFFD3D2FF.toInt(), 0xFFE8C8FF.toInt(),
            0xFFFBC2FF.toInt(), 0xFFFEC4EA.toInt(), 0xFFFECCC5.toInt(), 0xFFF7D8A5.toInt(),
            0xFFE4E594.toInt(), 0xFFCFEE96.toInt(), 0xFFBDF4AB.toInt(), 0xFFB3F3CC.toInt(),
            0xFFB5EBF2.toInt(), 0xFFB8B8B8.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt()
        )
    }

    private val romPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) inspectSelectedRom(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBackground(round: Boolean, normal: Int, pressed: Int): StateListDrawable {
        fun make(color: Int) = GradientDrawable().apply {
            setColor(color)
            if (round) this.shape = GradientDrawable.OVAL else cornerRadius = dp(12).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), make(pressed))
            addState(intArrayOf(), make(normal))
        }
    }

    private fun actionButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 15f
            setAllCaps(false)
            setTextColor(Color.WHITE)
            background = roundedBackground(false, 0xFF2D5BFF.toInt(), 0xFF1B3FC0.toInt())
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun gap(widthDp: Int, heightDp: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(widthDp) + dp(6), dp(heightDp) + dp(6))
        }
    }

    private fun jitLabel(): String =
        if (!recompilerWanted) "JIT: Mati" else if (synchronized(nativeAccessLock) { nativeRecompilerActive() }) "JIT: Aktif" else "JIT: Siap"

    private fun applyRecompilerSetting() {
        synchronized(nativeAccessLock) { nativeSetRecompiler(recompilerWanted) }
        if (::jitButton.isInitialized) jitButton.text = jitLabel()
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Crash guard for the recompiler: the flag is raised while emulation runs and cleared on a
        // clean stop. If it is still set at launch the previous run died, so fall back to the interpreter.
        var jitDisabledAfterCrash = false
        if (prefs.getBoolean("jit_guard", false)) {
            prefs.edit().putBoolean("jit_enabled", false).putBoolean("jit_guard", false).commit()
            jitDisabledAfterCrash = true
        }
        recompilerWanted = prefs.getBoolean("jit_enabled", true)
        synchronized(nativeAccessLock) { nativeSetRecompiler(recompilerWanted) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF121212.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(
                    dp(12) + insets.systemWindowInsetLeft,
                    dp(12) + insets.systemWindowInsetTop,
                    dp(12) + insets.systemWindowInsetRight,
                    dp(12) + insets.systemWindowInsetBottom
                )
                insets
            }
        }

        // Top bar: pick ROM (auto-loads and starts) and pause/resume.
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }
        topBar.addView(actionButton("Pilih ROM") {
            romPicker.launch(arrayOf("application/octet-stream", "application/x-nes-rom", "*/*"))
        })
        toggleButton = actionButton("Jeda") {
            if (emulationRunning.get()) stopEmulation() else if (romLoaded) startEmulation()
        }.apply { isEnabled = false }
        topBar.addView(toggleButton)
        jitButton = actionButton(jitLabel()) {
            recompilerWanted = !recompilerWanted
            prefs.edit().putBoolean("jit_enabled", recompilerWanted).putBoolean("jit_guard", false).apply()
            applyRecompilerSetting()
            Toast.makeText(
                this,
                if (recompilerWanted) "Recompiler ARM64 aktif (berlaku langsung)." else "Interpreter dipakai.",
                Toast.LENGTH_SHORT
            ).show()
        }
        topBar.addView(jitButton)

        screenView = ScreenView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        resultTextView = TextView(this).apply {
            text = "Tekan Pilih ROM untuk memulai."
            textSize = 12f
            setTextColor(0xFFB0B0B0.toInt())
            gravity = Gravity.CENTER
            maxLines = 3
            setPadding(0, dp(8), 0, 0)
        }

        // D-pad (cross layout).
        val dpadW = 62
        val dpadH = 62
        val dpad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rowUp = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowUp.addView(gap(dpadW, dpadH))
        rowUp.addView(controllerButton("▲", 0x10, dpadW, dpadH))
        rowUp.addView(gap(dpadW, dpadH))
        val rowMid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowMid.addView(controllerButton("◀", 0x40, dpadW, dpadH))
        rowMid.addView(gap(dpadW, dpadH))
        rowMid.addView(controllerButton("▶", 0x80, dpadW, dpadH))
        val rowDown = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowDown.addView(gap(dpadW, dpadH))
        rowDown.addView(controllerButton("▼", 0x20, dpadW, dpadH))
        rowDown.addView(gap(dpadW, dpadH))
        dpad.addView(rowUp)
        dpad.addView(rowMid)
        dpad.addView(rowDown)

        // A / B buttons (B lower-left, A upper-right, like the original pad).
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val bButton = controllerButton("B", 0x02, 76, 76, round = true, textSp = 22f)
        val aButton = controllerButton("A", 0x01, 76, 76, round = true, textSp = 22f)
        (bButton.layoutParams as LinearLayout.LayoutParams).topMargin = dp(40)
        actions.addView(bButton)
        actions.addView(aButton)

        val padRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(24) }
        }
        padRow.addView(dpad)
        padRow.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        })
        padRow.addView(actions)

        val startSelectRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(16) }
        }
        startSelectRow.addView(controllerButton("SELECT", 0x04, 96, 40, textSp = 13f))
        startSelectRow.addView(controllerButton("START", 0x08, 96, 40, textSp = 13f))

        root.addView(topBar)
        root.addView(screenView)
        root.addView(resultTextView)
        root.addView(padRow)
        root.addView(startSelectRow)
        setContentView(root)
        if (jitDisabledAfterCrash) {
            resultTextView.text = "Recompiler dimatikan otomatis karena aplikasi sempat berhenti mendadak. Ketuk tombol JIT untuk mencoba lagi."
        }
    }

    private fun loadSelectedRom(): Boolean {
        val bytes = selectedRom ?: return false
        stopEmulation()
        persistCurrentBatteryRam()
        val result = synchronized(nativeAccessLock) { nativeLoadRom(bytes) }
        return if (result.startsWith("ROM berhasil dimuat")) {
            activeRomSaveKey = romSaveKey(bytes)
            val restoreMessage = restoreBatteryRamForActiveRom()
            romLoaded = true
            if (::jitButton.isInitialized) jitButton.text = jitLabel()
            toggleButton.isEnabled = true
            resultTextView.text = if (restoreMessage.isBlank()) "ROM dimuat." else "ROM dimuat. $restoreMessage"
            true
        } else {
            romLoaded = false
            toggleButton.isEnabled = false
            resultTextView.text = result
            Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun startEmulation() {
        if (emulationRunning.get()) return
        val generation = emulationGeneration.incrementAndGet()
        emulationRunning.set(true)
        if (recompilerWanted) prefs.edit().putBoolean("jit_guard", true).commit()
        toggleButton.text = "Jeda"
        toggleButton.isEnabled = true
        resultTextView.text = "Emulasi berjalan."
        emulationExecutor.execute {
            val audio = createAudioTrack()
            try {
                // Discard audio generated by manual "Render Frame" taps before streaming starts.
                synchronized(nativeAccessLock) { nativeTakeAudio() }
            } catch (ignored: Exception) {
            }
            try {
            var statFrames = 0
            var statNanos = 0L
            var statWorst = 0L
            var statWindowStart = System.nanoTime()
            while (emulationRunning.get() && emulationGeneration.get() == generation) {
                val frameStart = System.nanoTime()
                var cancelledBeforeFrame = false
                val indices = try {
                    synchronized(nativeAccessLock) {
                        if (!emulationRunning.get() || emulationGeneration.get() != generation) {
                            cancelledBeforeFrame = true
                            null
                        } else {
                            nativeRunFrame()
                        }
                    }
                } catch (ignored: Exception) {
                    null
                }
                if (cancelledBeforeFrame) break
                val emuNanos = System.nanoTime() - frameStart
                statFrames++
                statNanos += emuNanos
                if (emuNanos > statWorst) statWorst = emuNanos
                if (System.nanoTime() - statWindowStart >= 1_000_000_000L) {
                    val fps = statFrames * 1_000_000_000.0 / (System.nanoTime() - statWindowStart)
                    val avgMs = statNanos / statFrames / 1_000_000.0
                    val worstMs = statWorst / 1_000_000.0
                    val jit = try { synchronized(nativeAccessLock) { nativeJitStats() } } catch (ignored: Exception) { "" }
                    val line = String.format("FPS %.1f | CPU/frame rata-rata %.1f ms, terburuk %.1f ms (batas 16.6) | %s",
                        fps, avgMs, worstMs, if (jit.isEmpty()) "JIT mati" else "JIT $jit")
                    mainHandler.post { if (emulationRunning.get() && emulationGeneration.get() == generation) resultTextView.text = line }
                    statFrames = 0; statNanos = 0L; statWorst = 0L; statWindowStart = System.nanoTime()
                }
                if (indices == null || indices.size != 256 * 240) {
                    mainHandler.post {
                        if (emulationGeneration.get() == generation && emulationRunning.get()) {
                            resultTextView.text = "Emulasi berhenti: frame gagal. Periksa ROM dan log native."
                            stopEmulation()
                        }
                    }
                    break
                }
                // Drop intermediate UI updates if the main thread is still presenting a frame.
                if (frameUpdatePending.compareAndSet(false, true)) {
                    mainHandler.post {
                        try {
                            if (emulationRunning.get() && emulationGeneration.get() == generation) {
                                showFrame(indices)
                            }
                        } finally {
                            frameUpdatePending.set(false)
                        }
                    }
                }
                if (audio != null) {
                    // A blocking write paces emulation to the audio clock (about 60.1 frames/s).
                    val pcm = try {
                        synchronized(nativeAccessLock) { nativeTakeAudio() }
                    } catch (ignored: Exception) {
                        null
                    }
                    if (pcm != null && pcm.isNotEmpty()) {
                        audio.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
                    }
                    continue
                }
                // No audio device: target about 60 updates/s.
                val elapsedMs = (System.nanoTime() - frameStart) / 1_000_000L
                val sleepMs = 16L - elapsedMs
                if (sleepMs > 0L) {
                    try {
                        Thread.sleep(sleepMs)
                    } catch (ignored: InterruptedException) {
                        Thread.currentThread().interrupt()
                        break
                    }
                }
            }
            } finally {
                releaseAudioTrack(audio)
            }
        }
    }

    private fun createAudioTrack(): AudioTrack? {
        return try {
            val rate = nativeAudioSampleRate()
            val minBytes = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBytes <= 0) return null
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBytes * 2, rate / 10 * 2)) // minimal ~100 ms: tahan lonjakan frame tanpa A/V lag besar
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            // Isi awal hening ~60 ms supaya buffer tidak langsung kosong saat emulasi mulai.
            track.write(ShortArray(rate * 60 / 1000), 0, rate * 60 / 1000, AudioTrack.WRITE_BLOCKING)
            track.play()
            track
        } catch (ignored: Exception) {
            null
        }
    }

    private fun releaseAudioTrack(track: AudioTrack?) {
        if (track == null) return
        try {
            track.pause()
            track.flush()
        } catch (ignored: Exception) {
        } finally {
            track.release()
        }
    }

    private fun stopEmulation() {
        val wasRunning = emulationRunning.getAndSet(false)
        emulationGeneration.incrementAndGet()
        if (::toggleButton.isInitialized) {
            toggleButton.text = "Lanjut"
            toggleButton.isEnabled = romLoaded
        }
        if (wasRunning) persistCurrentBatteryRam()
        prefs.edit().putBoolean("jit_guard", false).apply()
    }

    private fun romSaveKey(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xFF) }
    }

    private fun batterySaveFile(key: String): AtomicFile {
        val directory = File(filesDir, "battery_saves")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IllegalStateException("Tidak dapat membuat direktori save.")
        }
        return AtomicFile(File(directory, "$key.sav"))
    }

    private fun restoreBatteryRamForActiveRom(): String {
        val key = activeRomSaveKey ?: return ""
        return try {
            val saveFile = batterySaveFile(key)
            if (!saveFile.baseFile.exists()) return ""
            val bytes = saveFile.openRead().use { it.readBytes() }
            val result = synchronized(nativeAccessLock) { nativeImportBatteryRam(bytes) }
            if (result.startsWith("Save RAM berhasil")) {
                "Save RAM otomatis dipulihkan."
            } else {
                "Save RAM tidak dipulihkan: $result"
            }
        } catch (e: Exception) {
            "Save RAM tidak dapat dibaca: ${e.message ?: "kesalahan I/O"}"
        }
    }

    private fun persistCurrentBatteryRam() {
        val key = activeRomSaveKey ?: return
        try {
            val bytes = synchronized(nativeAccessLock) { nativeExportBatteryRam() } ?: return
            val saveFile = batterySaveFile(key)
            var output: java.io.FileOutputStream? = null
            try {
                output = saveFile.startWrite()
                output.write(bytes)
                output.fd.sync()
                saveFile.finishWrite(output)
                output = null
            } finally {
                if (output != null) saveFile.failWrite(output)
            }
        } catch (e: Exception) {
            if (::resultTextView.isInitialized) {
                resultTextView.text = resultTextView.text.toString() +
                    "\nPeringatan: save RAM gagal disimpan (${e.message ?: "kesalahan I/O"})."
            }
        }
    }

    private fun showFrame(indices: ByteArray) {
        if (indices.size != frameArgb.size) return
        for (i in indices.indices) frameArgb[i] = NES_PALETTE[indices[i].toInt() and 0x3F]
        val bitmap = frameBitmap ?: Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888).also {
            frameBitmap = it
        }
        bitmap.setPixels(frameArgb, 0, 256, 0, 0, 256, 240)
        screenView.bitmap = bitmap
        screenView.invalidate()
    }

    override fun onPause() {
        stopEmulation()
        persistCurrentBatteryRam()
        super.onPause()
    }

    override fun onDestroy() {
        stopEmulation()
        persistCurrentBatteryRam()
        emulationExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun controllerButton(
        label: String, mask: Int, widthDp: Int, heightDp: Int,
        round: Boolean = false, textSp: Float = 18f
    ): Button {
        return Button(this).apply {
            text = label
            textSize = textSp
            setAllCaps(false)
            setTextColor(Color.WHITE)
            isFocusable = false
            background = roundedBackground(round, 0xFF3A3A3A.toInt(), 0xFFE53935.toInt())
            stateListAnimator = null
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(heightDp)).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                        controllerButtons = controllerButtons or mask
                        nativeSetControllerState(0, controllerButtons)
                        view.isPressed = true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP,
                    MotionEvent.ACTION_CANCEL -> {
                        controllerButtons = controllerButtons and mask.inv()
                        nativeSetControllerState(0, controllerButtons)
                        view.isPressed = false
                    }
                }
                true
            }
        }
    }

    private fun inspectSelectedRom(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytes() }
                ?: throw IllegalStateException("Android tidak dapat membuka file ini.")
            selectedRom = bytes
            // Load immediately and start playing; errors are shown under the screen.
            if (loadSelectedRom()) startEmulation()
        } catch (e: Exception) {
            resultTextView.text = "Gagal membaca ROM: ${e.message ?: "kesalahan tidak diketahui"}"
            Toast.makeText(this, "ROM gagal dibaca", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var resultTextView: TextView

}

/** Draws the 256x240 NES frame scaled to the full width with crisp (nearest-neighbour) pixels. */
private class ScreenView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
    private val paint = Paint().apply {
        isFilterBitmap = false
        isAntiAlias = false
        isDither = false
    }
    private val dst = Rect()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(width, width * 240 / 256)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val bmp = bitmap ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(bmp, null, dst, paint)
    }
}
