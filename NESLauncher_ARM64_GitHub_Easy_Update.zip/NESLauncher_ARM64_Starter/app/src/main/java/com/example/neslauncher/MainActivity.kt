package com.example.neslauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AtomicFile
import android.view.Choreographer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private external fun nativeEngineStatus(): String
    private external fun nativeInspectRom(bytes: ByteArray): String
    private external fun nativeLoadRom(bytes: ByteArray): String
    private external fun nativeRunFrameFast(): Boolean
    private external fun nativeFillFrame(dst: IntArray)
    private external fun nativeSetAudioRateAdjust(ratio: Double)
    private external fun nativeTakeAudio(): ShortArray?
    private external fun nativeAudioSampleRate(): Int
    private external fun nativeSetControllerState(player: Int, buttons: Int)
    private external fun nativeExportBatteryRam(): ByteArray?
    private external fun nativeImportBatteryRam(bytes: ByteArray): String
    private var controllerButtons = 0
    private lateinit var screenView: ScreenView
    private var romLoaded = false
    private var selectedRom: ByteArray? = null
    private var activeRomSaveKey: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val emulationExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "NES-emulation").apply { isDaemon = true }
    }
    private val emulationRunning = AtomicBoolean(false)
    // Irama frame: callback Choreographer (vsync) menampilkan frame terbaru dan memberi "izin" jalan
    // satu frame ke thread emulasi, sehingga gerakan sejajar dengan refresh layar.
    private val tickPermits = Semaphore(0)
    private val framePending = AtomicBoolean(false)
    private val frameLock = Any()
    private var frameCallbackActive = false   // hanya diakses dari thread utama
    private var lastVsyncNs = 0L
    private var vsyncPeriodNs = 0.0
    private var vsyncAccNs = 0L
    @Volatile private var vsyncSync = true
    private val nativeAccessLock = Any()
    private val emulationGeneration = AtomicLong(0L)
    private lateinit var toggleButton: Button
    @Volatile private var showStats = false
    private lateinit var padView: VirtualPadView
    private lateinit var editBar: LinearLayout
    private var resumeAfterEdit = false
    private val prefs by lazy { getSharedPreferences("neslauncher", Context.MODE_PRIVATE) }
    private var frameBitmap: Bitmap? = null
    private val frameArgb = IntArray(256 * 240)

    companion object {
        init {
            System.loadLibrary("nesengine")
        }

        // Satu frame NES = 1 / 60,0988 detik.
        private const val NES_FRAME_NS = 16_639_267L
    }

    private val romPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) inspectSelectedRom(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundedBackground(round: Boolean, normal: Int, pressed: Int): StateListDrawable {
        fun make(color: Int) = GradientDrawable().apply {
            setColor(color)
            if (round) this.shape = GradientDrawable.OVAL else cornerRadius = dp(12).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), make(pressed))
            addState(intArrayOf(), make(normal))
        }
    }

    private fun actionButton(label: String, textSp: Float = 15f, primary: Boolean = true, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = textSp
            setAllCaps(false)
            setTextColor(Color.WHITE)
            background = if (primary) roundedBackground(false, 0xFF2D5BFF.toInt(), 0xFF1B3FC0.toInt())
                         else roundedBackground(false, 0xFF2B2B2B.toInt(), 0xFF454545.toInt())
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            }
            setOnClickListener { onClick() }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Pengaturan JIT lama sudah tidak dipakai; bersihkan sisanya.
        prefs.edit().remove("jit_guard").remove("jit_enabled").remove("jit_enabled_v2").apply()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF121212.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(
                    dp(12) + insets.systemWindowInsetLeft,
                    dp(12) + insets.systemWindowInsetTop,
                    dp(12) + insets.systemWindowInsetRight,
                    dp(12) + insets.systemWindowInsetBottom
                )
                insets
            }
        }

        // Top bar: pick ROM (auto-loads and starts) and pause/resume.
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }
        topBar.addView(actionButton("Pilih ROM", textSp = 14f) {
            romPicker.launch(arrayOf("application/octet-stream", "application/x-nes-rom", "*/*"))
        })
        toggleButton = actionButton("Jeda", textSp = 14f, primary = false) {
            if (emulationRunning.get()) stopEmulation() else if (romLoaded) startEmulation()
        }.apply { isEnabled = false }
        topBar.addView(toggleButton)
        topBar.addView(actionButton("Menu", textSp = 14f, primary = false) { showMainMenu() })

        screenView = ScreenView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        screenView.smooth = prefs.getBoolean("smooth", false)
        showStats = prefs.getBoolean("show_stats", false)
        vsyncSync = prefs.getBoolean("vsync_sync", true)

        // Tinggi tetap 2 baris supaya area tombol di bawah tidak bergeser saat teks berganti.
        resultTextView = TextView(this).apply {
            text = "Tekan Pilih ROM untuk memulai."
            textSize = 12f
            setTextColor(0xFFB0B0B0.toInt())
            gravity = Gravity.CENTER
            setLines(2)
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }

        // Kontrol virtual yang bisa diatur (posisi, ukuran, transparansi, getaran, turbo).
        padView = VirtualPadView(this, prefs) { mask ->
            controllerButtons = mask
            nativeSetControllerState(0, mask)
        }
        editBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
            )
        }
        editBar.addView(actionButton("−", textSp = 18f, primary = false) { padView.resizeSelected(-0.1f) })
        editBar.addView(actionButton("+", textSp = 18f, primary = false) { padView.resizeSelected(0.1f) })
        editBar.addView(actionButton("Reset", textSp = 13f, primary = false) { padView.resetLayout() })
        editBar.addView(actionButton("Selesai", textSp = 13f) { exitPadEdit() })
        val padFrame = android.widget.FrameLayout(this).apply {
            minimumHeight = dp(200)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                .apply { topMargin = dp(4) }
        }
        padFrame.addView(padView, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        padFrame.addView(editBar)

        root.addView(topBar)
        root.addView(screenView)
        root.addView(resultTextView)
        root.addView(padFrame)
        setContentView(root)
    }

    private fun loadSelectedRom(): Boolean {
        val bytes = selectedRom ?: return false
        stopEmulation()
        persistCurrentBatteryRam()
        val result = synchronized(nativeAccessLock) { nativeLoadRom(bytes) }
        return if (result.startsWith("ROM berhasil dimuat")) {
            activeRomSaveKey = romSaveKey(bytes)
            val restoreMessage = restoreBatteryRamForActiveRom()
            romLoaded = true
            toggleButton.isEnabled = true
            resultTextView.text = if (restoreMessage.isBlank()) "ROM dimuat." else "ROM dimuat. $restoreMessage"
            true
        } else {
            romLoaded = false
            toggleButton.isEnabled = false
            resultTextView.text = result
            Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun startEmulation() {
        if (emulationRunning.get()) return
        val generation = emulationGeneration.incrementAndGet()
        emulationRunning.set(true)
        toggleButton.text = "Jeda"
        toggleButton.isEnabled = true
        resultTextView.text = "Emulasi berjalan."
        tickPermits.drainPermits()
        framePending.set(false)
        // Presentasi (dan irama emulasi) mengikuti vsync layar lewat Choreographer.
        mainHandler.post {
            if (emulationRunning.get() && !frameCallbackActive) {
                frameCallbackActive = true
                lastVsyncNs = 0L
                vsyncAccNs = 0L
                Choreographer.getInstance().postFrameCallback(frameCallback)
            }
        }
        emulationExecutor.execute {
            // Thread ini mengisi audio; jangan sampai kelaparan oleh pekerjaan UI/latar belakang.
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            } catch (ignored: Exception) {
            }
            val audio = createAudioTrack()
            val audioRate = try { nativeAudioSampleRate() } catch (ignored: Exception) { 48000 }
            // createAudioTrack mengisi hening 60 ms sebelum play(); hitung juga agar isi buffer akurat.
            var framesWritten = if (audio != null) audioRate * 60L / 1000L else 0L
            try {
                // Buang audio sisa dari render manual sebelum streaming dimulai.
                synchronized(nativeAccessLock) { nativeTakeAudio() }
            } catch (ignored: Exception) {
            }
            try {
                var statFrames = 0
                var statNanos = 0L
                var statWorst = 0L
                var statWindowStart = System.nanoTime()
                while (emulationRunning.get() && emulationGeneration.get() == generation) {
                    if (vsyncSync) {
                        // Tunggu tanda vsync dari Choreographer (batas waktu agar status tetap diperiksa).
                        val got = try {
                            tickPermits.tryAcquire(50, TimeUnit.MILLISECONDS)
                        } catch (ignored: InterruptedException) {
                            Thread.currentThread().interrupt()
                            break
                        }
                        if (!got) continue
                    }
                    val frameStart = System.nanoTime()
                    var cancelledBeforeFrame = false
                    val ok = try {
                        synchronized(nativeAccessLock) {
                            if (!emulationRunning.get() || emulationGeneration.get() != generation) {
                                cancelledBeforeFrame = true
                                false
                            } else {
                                nativeRunFrameFast()
                            }
                        }
                    } catch (ignored: Exception) {
                        false
                    }
                    if (cancelledBeforeFrame) break
                    val emuNanos = System.nanoTime() - frameStart
                    statFrames++
                    statNanos += emuNanos
                    if (emuNanos > statWorst) statWorst = emuNanos
                    if (System.nanoTime() - statWindowStart >= 1_000_000_000L) {
                        val fps = statFrames * 1_000_000_000.0 / (System.nanoTime() - statWindowStart)
                        val avgMs = statNanos / statFrames / 1_000_000.0
                        val worstMs = statWorst / 1_000_000.0
                        val line = String.format("FPS %.1f  ·  CPU %.1f ms/frame (maks %.1f dari 16,6)\nIrama frame: %s",
                            fps, avgMs, worstMs, if (vsyncSync) "ikuti layar" else "ikuti audio")
                        if (showStats) mainHandler.post { if (showStats && emulationRunning.get() && emulationGeneration.get() == generation) resultTextView.text = line }
                        statFrames = 0; statNanos = 0L; statWorst = 0L; statWindowStart = System.nanoTime()
                    }
                    if (!ok) {
                        mainHandler.post {
                            if (emulationGeneration.get() == generation && emulationRunning.get()) {
                                resultTextView.text = "Emulasi berhenti: frame gagal. Periksa ROM dan log native."
                                stopEmulation()
                            }
                        }
                        break
                    }
                    // Warna dikonversi di native; UI tinggal menyalin ke bitmap pada vsync berikutnya.
                    synchronized(frameLock) { nativeFillFrame(frameArgb) }
                    framePending.set(true)
                    if (audio != null) {
                        val pcm = try {
                            synchronized(nativeAccessLock) { nativeTakeAudio() }
                        } catch (ignored: Exception) {
                            null
                        }
                        if (pcm != null && pcm.isNotEmpty()) {
                            // Penulisan memblokir hanya bila buffer penuh; mode vsync menjaga isinya tetap sedang.
                            audio.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
                            framesWritten += pcm.size
                        }
                        if (vsyncSync) {
                            // Kendali laju dinamis: isi buffer di bawah target -> hasilkan sedikit lebih banyak sampel.
                            val played = audio.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                            val fill = framesWritten - played
                            val target = audioRate * 60L / 1000L
                            val scale = audioRate * 50L / 1000L
                            val err = ((target - fill).toDouble() / scale).coerceIn(-1.0, 1.0)
                            nativeSetAudioRateAdjust(1.0 + 0.005 * err)
                        }
                        continue
                    }
                    if (!vsyncSync) {
                        // Tanpa audio dan tanpa vsync: sekitar 60 pembaruan per detik.
                        val elapsedMs = (System.nanoTime() - frameStart) / 1_000_000L
                        val sleepMs = 16L - elapsedMs
                        if (sleepMs > 0L) {
                            try {
                                Thread.sleep(sleepMs)
                            } catch (ignored: InterruptedException) {
                                Thread.currentThread().interrupt()
                                break
                            }
                        }
                    }
                }
            } finally {
                try { nativeSetAudioRateAdjust(1.0) } catch (ignored: Exception) {}
                releaseAudioTrack(audio)
            }
        }
    }

    // Dipanggil setiap vsync di thread utama: tampilkan frame terbaru dan beri izin jalan satu frame.
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!emulationRunning.get()) {
                frameCallbackActive = false
                return
            }
            if (framePending.getAndSet(false)) presentFrame()
            if (vsyncSync) {
                val last = lastVsyncNs
                lastVsyncNs = frameTimeNanos
                if (last != 0L) {
                    val delta = frameTimeNanos - last
                    if (delta in 4_000_000L..50_000_000L) {
                        vsyncPeriodNs = if (vsyncPeriodNs == 0.0) delta.toDouble() else vsyncPeriodNs * 0.9 + delta * 0.1
                    }
                    if (abs(vsyncPeriodNs - 16_666_667.0) < 170_000.0) {
                        // Layar 60 Hz: satu frame NES per vsync (selisih ke 60,0988 Hz diserap kendali audio).
                        val n = (delta / vsyncPeriodNs + 0.5).toInt().coerceIn(1, 3)
                        repeat(n) { releaseTick() }
                    } else {
                        // Layar 90/120 Hz (atau tidak stabil): jaga kecepatan asli dengan akumulator waktu.
                        vsyncAccNs += delta
                        while (vsyncAccNs >= NES_FRAME_NS) {
                            vsyncAccNs -= NES_FRAME_NS
                            releaseTick()
                        }
                    }
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun releaseTick() {
        if (tickPermits.availablePermits() < 2) tickPermits.release()
    }

    // Minta layar berjalan di 60 Hz supaya 60 frame NES tidak dipaksa 3:2 pada layar 90 Hz.
    @Suppress("DEPRECATION")
    private fun requestSixtyHz() {
        try {
            val params = window.attributes
            params.preferredRefreshRate = 60f
            val display = windowManager.defaultDisplay
            val current = display.mode
            val match = display.supportedModes.firstOrNull {
                it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight &&
                    abs(it.refreshRate - 60f) < 1f
            }
            if (match != null) params.preferredDisplayModeId = match.modeId
            window.attributes = params
        } catch (ignored: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        requestSixtyHz()
    }

    private fun createAudioTrack(): AudioTrack? {
        return try {
            val rate = nativeAudioSampleRate()
            val minBytes = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBytes <= 0) return null
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBytes * 2, rate / 10 * 2)) // minimal ~100 ms: tahan lonjakan frame tanpa A/V lag besar
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            // Isi awal hening ~60 ms supaya buffer tidak langsung kosong saat emulasi mulai.
            track.write(ShortArray(rate * 60 / 1000), 0, rate * 60 / 1000, AudioTrack.WRITE_BLOCKING)
            track.play()
            track
        } catch (ignored: Exception) {
            null
        }
    }

    private fun releaseAudioTrack(track: AudioTrack?) {
        if (track == null) return
        try {
            track.pause()
            track.flush()
        } catch (ignored: Exception) {
        } finally {
            track.release()
        }
    }

    private fun stopEmulation() {
        val wasRunning = emulationRunning.getAndSet(false)
        emulationGeneration.incrementAndGet()
        if (::toggleButton.isInitialized) {
            toggleButton.text = "Lanjut"
            toggleButton.isEnabled = romLoaded
        }
        if (wasRunning) persistCurrentBatteryRam()
    }

    private fun romSaveKey(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xFF) }
    }

    private fun batterySaveFile(key: String): AtomicFile {
        val directory = File(filesDir, "battery_saves")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IllegalStateException("Tidak dapat membuat direktori save.")
        }
        return AtomicFile(File(directory, "$key.sav"))
    }

    private fun restoreBatteryRamForActiveRom(): String {
        val key = activeRomSaveKey ?: return ""
        return try {
            val saveFile = batterySaveFile(key)
            if (!saveFile.baseFile.exists()) return ""
            val bytes = saveFile.openRead().use { it.readBytes() }
            val result = synchronized(nativeAccessLock) { nativeImportBatteryRam(bytes) }
            if (result.startsWith("Save RAM berhasil")) {
                "Save RAM otomatis dipulihkan."
            } else {
                "Save RAM tidak dipulihkan: $result"
            }
        } catch (e: Exception) {
            "Save RAM tidak dapat dibaca: ${e.message ?: "kesalahan I/O"}"
        }
    }

    private fun persistCurrentBatteryRam() {
        val key = activeRomSaveKey ?: return
        try {
            val bytes = synchronized(nativeAccessLock) { nativeExportBatteryRam() } ?: return
            val saveFile = batterySaveFile(key)
            var output: java.io.FileOutputStream? = null
            try {
                output = saveFile.startWrite()
                output.write(bytes)
                output.fd.sync()
                saveFile.finishWrite(output)
                output = null
            } finally {
                if (output != null) saveFile.failWrite(output)
            }
        } catch (e: Exception) {
            if (::resultTextView.isInitialized) {
                resultTextView.text = resultTextView.text.toString() +
                    "\nPeringatan: save RAM gagal disimpan (${e.message ?: "kesalahan I/O"})."
            }
        }
    }

    private fun presentFrame() {
        val bitmap = frameBitmap ?: Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888).also {
            frameBitmap = it
        }
        synchronized(frameLock) { bitmap.setPixels(frameArgb, 0, 256, 0, 0, 256, 240) }
        screenView.bitmap = bitmap
        screenView.invalidate()
    }

    override fun onPause() {
        if (::padView.isInitialized) { padView.releaseAll(); padView.save() }
        stopEmulation()
        persistCurrentBatteryRam()
        super.onPause()
    }

    override fun onDestroy() {
        stopEmulation()
        persistCurrentBatteryRam()
        emulationExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun showMainMenu() {
        val items = arrayOf(
            "Kontrol layar…",
            "Info FPS: ${if (showStats) "Tampil" else "Sembunyi"}",
            "Filter gambar: ${if (screenView.smooth) "Halus" else "Tajam (pixel)"}",
            "Irama frame: ${if (vsyncSync) "Ikuti layar (halus)" else "Ikuti audio (lama)"}"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showControlMenu()
                    1 -> {
                        showStats = !showStats
                        prefs.edit().putBoolean("show_stats", showStats).apply()
                        if (!showStats && emulationRunning.get()) resultTextView.text = "Emulasi berjalan."
                    }
                    2 -> {
                        screenView.smooth = !screenView.smooth
                        prefs.edit().putBoolean("smooth", screenView.smooth).apply()
                    }
                    3 -> {
                        vsyncSync = !vsyncSync
                        prefs.edit().putBoolean("vsync_sync", vsyncSync).apply()
                        if (!vsyncSync) nativeSetAudioRateAdjust(1.0)
                        Toast.makeText(
                            this,
                            if (vsyncSync) "Irama frame mengikuti layar." else "Irama frame mengikuti audio.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else -> {}
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    // ---- menu & mode atur kontrol ----
    private fun showControlMenu() {
        val items = arrayOf(
            "Atur posisi & ukuran tombol",
            "Transparansi tombol: ${padView.opacityPercent}%",
            "Getaran: ${if (padView.haptic) "Hidup" else "Mati"}",
            "Tombol Turbo A/B: ${if (padView.turboVisible) "Tampil" else "Sembunyi"}",
            "Kembalikan tata letak awal"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("Kontrol")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> enterPadEdit()
                    1 -> showOpacityDialog()
                    2 -> { padView.haptic = !padView.haptic; padView.save() }
                    3 -> { padView.turboVisible = !padView.turboVisible; padView.save() }
                    4 -> padView.resetLayout()
                    else -> {}
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showOpacityDialog() {
        val original = padView.opacityPercent
        val seek = android.widget.SeekBar(this).apply {
            max = 80                       // 20%..100%
            progress = original - 20
            setPadding(dp(24), dp(16), dp(24), dp(8))
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                    padView.opacityPercent = value + 20
                }
                override fun onStartTrackingTouch(bar: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(bar: android.widget.SeekBar?) {}
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Transparansi tombol")
            .setView(seek)
            .setPositiveButton("Simpan") { _, _ -> padView.save() }
            .setNegativeButton("Batal") { _, _ -> padView.opacityPercent = original }
            .setOnCancelListener { padView.opacityPercent = original }
            .show()
    }

    private fun enterPadEdit() {
        resumeAfterEdit = emulationRunning.get()
        if (resumeAfterEdit) stopEmulation()   // jeda dulu supaya teks petunjuk tidak tertimpa statistik
        padView.editMode = true
        editBar.visibility = View.VISIBLE
        resultTextView.text = "Atur tombol: seret untuk memindah, ketuk untuk memilih, lalu pakai − / + untuk ukuran. Tekan Selesai bila sudah."
    }

    private fun exitPadEdit() {
        padView.editMode = false
        editBar.visibility = View.GONE
        padView.save()
        if (resumeAfterEdit && romLoaded) {
            resumeAfterEdit = false
            startEmulation()
        } else {
            resultTextView.text = "Tata letak tombol disimpan."
        }
    }

    private fun inspectSelectedRom(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytes() }
                ?: throw IllegalStateException("Android tidak dapat membuka file ini.")
            selectedRom = bytes
            // Load immediately and start playing; errors are shown under the screen.
            if (loadSelectedRom()) startEmulation()
        } catch (e: Exception) {
            resultTextView.text = "Gagal membaca ROM: ${e.message ?: "kesalahan tidak diketahui"}"
            Toast.makeText(this, "ROM gagal dibaca", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var resultTextView: TextView

}

/** Draws the 256x240 NES frame scaled to the full width with crisp (nearest-neighbour) pixels. */
private class ScreenView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
    private val paint = Paint().apply {
        isFilterBitmap = false
        isAntiAlias = false
        isDither = false
    }
    private val dst = Rect()

    /** false: piksel tajam (nearest); true: halus (bilinear), lebih nyaman di layar HD. */
    var smooth: Boolean = false
        set(value) {
            field = value
            paint.isFilterBitmap = value
            invalidate()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(width, width * 240 / 256)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val bmp = bitmap ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(bmp, null, dst, paint)
    }
}
