package com.example.neslauncher

import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.widget.ImageView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AtomicFile
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : ComponentActivity() {
    private lateinit var statusView: TextView
    private external fun nativeEngineStatus(): String
    private external fun nativeInspectRom(bytes: ByteArray): String
    private external fun nativeLoadRom(bytes: ByteArray): String
    private external fun nativeRunFrame(): ByteArray?
    private external fun nativeTakeAudio(): ShortArray?
    private external fun nativeAudioSampleRate(): Int
    private external fun nativeSetControllerState(player: Int, buttons: Int)
    private external fun nativeExportBatteryRam(): ByteArray?
    private external fun nativeImportBatteryRam(bytes: ByteArray): String
    private var controllerButtons = 0
    private lateinit var frameView: ImageView
    private var selectedRom: ByteArray? = null
    private var activeRomSaveKey: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val emulationExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "NES-emulation").apply { isDaemon = true }
    }
    private val emulationRunning = AtomicBoolean(false)
    private val frameUpdatePending = AtomicBoolean(false)
    private val nativeAccessLock = Any()
    private val emulationGeneration = AtomicLong(0L)
    private lateinit var startEmulationButton: Button
    private lateinit var pauseEmulationButton: Button
    private lateinit var renderFrameButton: Button
    private var frameBitmap: Bitmap? = null
    private val frameArgb = IntArray(256 * 240)

    companion object {
        init {
            System.loadLibrary("nesengine")
        }

        // Standard 64-entry NTSC NES palette, represented as opaque Android ARGB.
        private val NES_PALETTE = intArrayOf(
            0xFF666666.toInt(), 0xFF002A88.toInt(), 0xFF1412A7.toInt(), 0xFF3B00A4.toInt(),
            0xFF5C007E.toInt(), 0xFF6E0040.toInt(), 0xFF6C0600.toInt(), 0xFF561D00.toInt(),
            0xFF333500.toInt(), 0xFF0B4800.toInt(), 0xFF005200.toInt(), 0xFF004F08.toInt(),
            0xFF00404D.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFADADAD.toInt(), 0xFF155FD9.toInt(), 0xFF4240FF.toInt(), 0xFF7527FE.toInt(),
            0xFFA01ACC.toInt(), 0xFFB71E7B.toInt(), 0xFFB53120.toInt(), 0xFF994E00.toInt(),
            0xFF6B6D00.toInt(), 0xFF388700.toInt(), 0xFF0C9300.toInt(), 0xFF008F32.toInt(),
            0xFF007C8D.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFFFFEFF.toInt(), 0xFF64B0FF.toInt(), 0xFF9290FF.toInt(), 0xFFC676FF.toInt(),
            0xFFF36AFF.toInt(), 0xFFFE6ECC.toInt(), 0xFFFE8170.toInt(), 0xFFEA9E22.toInt(),
            0xFFBCBE00.toInt(), 0xFF88D800.toInt(), 0xFF5CE430.toInt(), 0xFF45E082.toInt(),
            0xFF48CDDE.toInt(), 0xFF4F4F4F.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
            0xFFFFFEFF.toInt(), 0xFFC0DFFF.toInt(), 0xFFD3D2FF.toInt(), 0xFFE8C8FF.toInt(),
            0xFFFBC2FF.toInt(), 0xFFFEC4EA.toInt(), 0xFFFECCC5.toInt(), 0xFFF7D8A5.toInt(),
            0xFFE4E594.toInt(), 0xFFCFEE96.toInt(), 0xFFBDF4AB.toInt(), 0xFFB3F3CC.toInt(),
            0xFFB5EBF2.toInt(), 0xFFB8B8B8.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt()
        )
    }

    private val romPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) inspectSelectedRom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val title = TextView(this).apply {
            text = "NES Launcher ARM64"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        statusView = TextView(this).apply {
            text = nativeEngineStatus()
            textSize = 14f
            setPadding(0, 20, 0, 20)
        }
        val chooseRom = Button(this).apply {
            text = "Pilih file ROM (.nes)"
            setOnClickListener { romPicker.launch(arrayOf("application/octet-stream", "application/x-nes-rom", "*/*")) }
        }
        val loadRom = Button(this).apply {
            text = "Muat ROM"
            setOnClickListener {
                val bytes = selectedRom
                if (bytes == null) {
                    Toast.makeText(this@MainActivity, "Pilih ROM terlebih dahulu", Toast.LENGTH_SHORT).show()
                } else {
                    stopEmulation()
                    persistCurrentBatteryRam()
                    val result = synchronized(nativeAccessLock) { nativeLoadRom(bytes) }
                    if (result.startsWith("ROM berhasil dimuat")) {
                        activeRomSaveKey = romSaveKey(bytes)
                        val restoreMessage = restoreBatteryRamForActiveRom()
                        resultTextView.text = if (restoreMessage.isBlank()) result else "$result\n$restoreMessage"
                        Toast.makeText(this@MainActivity, resultTextView.text, Toast.LENGTH_LONG).show()
                    } else {
                        resultTextView.text = result
                        Toast.makeText(this@MainActivity, result, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        renderFrameButton = Button(this).apply {
            text = "Render Frame"
            setOnClickListener {
                val indices = nativeRunFrame()
                if (indices == null || indices.size != 256 * 240) {
                    Toast.makeText(this@MainActivity, "Frame gagal. Muat ROM yang valid terlebih dahulu.", Toast.LENGTH_LONG).show()
                } else {
                    showFrame(indices)
                    resultTextView.text = "Frame berhasil dirender dari CPU/PPU. Output: 256 × 240 piksel."
                }
            }
        }
        startEmulationButton = Button(this).apply {
            text = "Mulai Emulasi"
            setOnClickListener { startEmulation() }
        }
        pauseEmulationButton = Button(this).apply {
            text = "Jeda Emulasi"
            isEnabled = false
            setOnClickListener { stopEmulation() }
        }
        frameView = ImageView(this).apply {
            contentDescription = "Pratinjau frame emulator NES"
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setBackgroundColor(0xFF202020.toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 220
            )
        }
        val resultTitle = TextView(this).apply {
            text = "Hasil pemeriksaan ROM"
            textSize = 18f
            setPadding(0, 24, 0, 8)
        }
        resultTextView = TextView(this).apply {
            text = "Belum ada ROM yang dipilih."
            textSize = 14f
            setTextIsSelectable(true)
        }
        val resultScroll = ScrollView(this).apply {
            addView(resultTextView)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(title)
        root.addView(statusView)
        root.addView(chooseRom)
        root.addView(loadRom)
        root.addView(renderFrameButton)
        root.addView(startEmulationButton)
        root.addView(pauseEmulationButton)

        val directionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        directionRow.addView(controllerButton("←", 0x40))
        directionRow.addView(controllerButton("↑", 0x10))
        directionRow.addView(controllerButton("↓", 0x20))
        directionRow.addView(controllerButton("→", 0x80))
        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        actionRow.addView(controllerButton("B", 0x02))
        actionRow.addView(controllerButton("A", 0x01))
        actionRow.addView(controllerButton("SELECT", 0x04))
        actionRow.addView(controllerButton("START", 0x08))
        root.addView(directionRow)
        root.addView(actionRow)
        root.addView(frameView)
        root.addView(resultTitle)
        root.addView(resultScroll)
        setContentView(root)
    }


    private fun startEmulation() {
        if (emulationRunning.get()) return
        val generation = emulationGeneration.incrementAndGet()
        emulationRunning.set(true)
        startEmulationButton.isEnabled = false
        pauseEmulationButton.isEnabled = true
        renderFrameButton.isEnabled = false
        resultTextView.text = "Emulasi berjalan. Tekan Jeda Emulasi untuk berhenti."
        emulationExecutor.execute {
            val audio = createAudioTrack()
            try {
                // Discard audio generated by manual "Render Frame" taps before streaming starts.
                synchronized(nativeAccessLock) { nativeTakeAudio() }
            } catch (ignored: Exception) {
            }
            try {
            while (emulationRunning.get() && emulationGeneration.get() == generation) {
                val frameStart = System.nanoTime()
                var cancelledBeforeFrame = false
                val indices = try {
                    synchronized(nativeAccessLock) {
                        if (!emulationRunning.get() || emulationGeneration.get() != generation) {
                            cancelledBeforeFrame = true
                            null
                        } else {
                            nativeRunFrame()
                        }
                    }
                } catch (ignored: Exception) {
                    null
                }
                if (cancelledBeforeFrame) break
                if (indices == null || indices.size != 256 * 240) {
                    mainHandler.post {
                        if (emulationGeneration.get() == generation && emulationRunning.get()) {
                            resultTextView.text = "Emulasi berhenti: frame gagal. Periksa ROM dan log native."
                            stopEmulation()
                        }
                    }
                    break
                }
                // Drop intermediate UI updates if the main thread is still presenting a frame.
                if (frameUpdatePending.compareAndSet(false, true)) {
                    mainHandler.post {
                        try {
                            if (emulationRunning.get() && emulationGeneration.get() == generation) {
                                showFrame(indices)
                            }
                        } finally {
                            frameUpdatePending.set(false)
                        }
                    }
                }
                if (audio != null) {
                    // A blocking write paces emulation to the audio clock (about 60.1 frames/s).
                    val pcm = try {
                        synchronized(nativeAccessLock) { nativeTakeAudio() }
                    } catch (ignored: Exception) {
                        null
                    }
                    if (pcm != null && pcm.isNotEmpty()) {
                        audio.write(pcm, 0, pcm.size, AudioTrack.WRITE_BLOCKING)
                    }
                    continue
                }
                // No audio device: target about 60 updates/s.
                val elapsedMs = (System.nanoTime() - frameStart) / 1_000_000L
                val sleepMs = 16L - elapsedMs
                if (sleepMs > 0L) {
                    try {
                        Thread.sleep(sleepMs)
                    } catch (ignored: InterruptedException) {
                        Thread.currentThread().interrupt()
                        break
                    }
                }
            }
            } finally {
                releaseAudioTrack(audio)
            }
        }
    }

    private fun createAudioTrack(): AudioTrack? {
        return try {
            val rate = nativeAudioSampleRate()
            val minBytes = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBytes <= 0) return null
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBytes * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            track
        } catch (ignored: Exception) {
            null
        }
    }

    private fun releaseAudioTrack(track: AudioTrack?) {
        if (track == null) return
        try {
            track.pause()
            track.flush()
        } catch (ignored: Exception) {
        } finally {
            track.release()
        }
    }

    private fun stopEmulation() {
        val wasRunning = emulationRunning.getAndSet(false)
        emulationGeneration.incrementAndGet()
        if (::startEmulationButton.isInitialized) startEmulationButton.isEnabled = true
        if (::pauseEmulationButton.isInitialized) pauseEmulationButton.isEnabled = false
        if (::renderFrameButton.isInitialized) renderFrameButton.isEnabled = true
        if (wasRunning) persistCurrentBatteryRam()
    }

    private fun romSaveKey(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { byte -> "%02x".format(byte.toInt() and 0xFF) }
    }

    private fun batterySaveFile(key: String): AtomicFile {
        val directory = File(filesDir, "battery_saves")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IllegalStateException("Tidak dapat membuat direktori save.")
        }
        return AtomicFile(File(directory, "$key.sav"))
    }

    private fun restoreBatteryRamForActiveRom(): String {
        val key = activeRomSaveKey ?: return ""
        return try {
            val saveFile = batterySaveFile(key)
            if (!saveFile.baseFile.exists()) return ""
            val bytes = saveFile.openRead().use { it.readBytes() }
            val result = synchronized(nativeAccessLock) { nativeImportBatteryRam(bytes) }
            if (result.startsWith("Save RAM berhasil")) {
                "Save RAM otomatis dipulihkan."
            } else {
                "Save RAM tidak dipulihkan: $result"
            }
        } catch (e: Exception) {
            "Save RAM tidak dapat dibaca: ${e.message ?: "kesalahan I/O"}"
        }
    }

    private fun persistCurrentBatteryRam() {
        val key = activeRomSaveKey ?: return
        try {
            val bytes = synchronized(nativeAccessLock) { nativeExportBatteryRam() } ?: return
            val saveFile = batterySaveFile(key)
            var output: java.io.FileOutputStream? = null
            try {
                output = saveFile.startWrite()
                output.write(bytes)
                output.fd.sync()
                saveFile.finishWrite(output)
                output = null
            } finally {
                if (output != null) saveFile.failWrite(output)
            }
        } catch (e: Exception) {
            if (::resultTextView.isInitialized) {
                resultTextView.text = resultTextView.text.toString() +
                    "\nPeringatan: save RAM gagal disimpan (${e.message ?: "kesalahan I/O"})."
            }
        }
    }

    private fun showFrame(indices: ByteArray) {
        if (indices.size != frameArgb.size) return
        for (i in indices.indices) frameArgb[i] = NES_PALETTE[indices[i].toInt() and 0x3F]
        val bitmap = frameBitmap ?: Bitmap.createBitmap(256, 240, Bitmap.Config.ARGB_8888).also {
            frameBitmap = it
        }
        bitmap.setPixels(frameArgb, 0, 256, 0, 0, 256, 240)
        frameView.setImageBitmap(bitmap)
    }

    override fun onPause() {
        stopEmulation()
        persistCurrentBatteryRam()
        super.onPause()
    }

    override fun onDestroy() {
        stopEmulation()
        persistCurrentBatteryRam()
        emulationExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun controllerButton(label: String, mask: Int): Button {
        return Button(this).apply {
            text = label
            isFocusable = false
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                        controllerButtons = controllerButtons or mask
                        nativeSetControllerState(0, controllerButtons)
                        view.isPressed = true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP,
                    MotionEvent.ACTION_CANCEL -> {
                        controllerButtons = controllerButtons and mask.inv()
                        nativeSetControllerState(0, controllerButtons)
                        view.isPressed = false
                    }
                }
                true
            }
        }
    }

    private fun inspectSelectedRom(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytes() }
                ?: throw IllegalStateException("Android tidak dapat membuka file ini.")
            selectedRom = bytes
            resultTextView.text = "Memeriksa ${uri.lastPathSegment ?: "ROM"} (${bytes.size} byte)...\n\n" +
                nativeInspectRom(bytes)
        } catch (e: Exception) {
            resultTextView.text = "Gagal membaca ROM: ${e.message ?: "kesalahan tidak diketahui"}"
            Toast.makeText(this, "ROM gagal dibaca", Toast.LENGTH_SHORT).show()
        }
    }

    private lateinit var resultTextView: TextView

}