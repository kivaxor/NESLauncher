#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace nes {
struct RomInfo {
    bool valid = false;
    bool nes2 = false;
    bool battery = false;
    bool trainer = false;
    bool four_screen = false;
    uint16_t mapper = 0;
    uint64_t prg_rom_bytes = 0;
    uint64_t chr_rom_bytes = 0;
    size_t payload_offset = 0;
    std::string error;
};

RomInfo inspect_rom(const uint8_t* data, size_t size);
std::string describe_rom(const RomInfo& info);
std::string engine_status();
}
