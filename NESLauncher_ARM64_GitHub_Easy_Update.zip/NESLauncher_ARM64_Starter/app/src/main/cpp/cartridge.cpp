#include "cartridge.h"
#include "nes_engine.h"

#include <algorithm>
#include <utility>

namespace nes {

bool Cartridge::mapper_supported(uint16_t mapper) {
    return mapper == 0 || mapper == 1 || mapper == 2 || mapper == 3 || mapper == 4 || mapper == 7;
}

void Cartridge::reset_mapper_state() {
    prg_bank_ = 0;
    chr_bank_ = 0;
    mmc1_shift_ = 0x10;
    mmc1_control_ = 0x0C;
    mmc1_chr0_ = 0;
    mmc1_chr1_ = 0;
    mmc1_prg_ = 0;
    mmc3_select_ = 0;
    mmc3_regs_ = {0, 2, 4, 5, 6, 7, 0, 1};
    mmc3_irq_latch_ = 0;
    mmc3_irq_counter_ = 0;
    mmc3_irq_reload_ = false;
    mmc3_irq_enabled_ = false;
    mmc3_irq_pending_ = false;
    refresh_prg_map();
}

uint64_t Cartridge::content_hash() const {
    uint64_t h = 1469598103934665603ULL;
    auto mix = [&h](const uint8_t* p, size_t n) { for (size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 1099511628211ULL; } };
    const uint8_t header[2] = {static_cast<uint8_t>(mapper_ & 0xFF), static_cast<uint8_t>(mapper_ >> 8)};
    mix(header, 2);
    mix(prg_rom_.data(), prg_rom_.size());
    if (!chr_ram_) mix(chr_.data(), chr_.size());
    return h;
}

void Cartridge::reset_mapper() {
    if (!loaded_) return;
    reset_mapper_state();
    mirroring_ = initial_mirroring_;
}

void Cartridge::save_state(StateWriter& w) const {
    w.pod(mapper_); w.pod(mirroring_); w.pod_array(prg_ram_);
    w.pod(prg_bank_); w.pod(chr_bank_);
    w.pod(mmc1_shift_); w.pod(mmc1_control_); w.pod(mmc1_chr0_); w.pod(mmc1_chr1_); w.pod(mmc1_prg_);
    w.pod(mmc3_select_); w.pod_array(mmc3_regs_); w.pod(mmc3_irq_latch_); w.pod(mmc3_irq_counter_);
    w.pod(mmc3_irq_reload_); w.pod(mmc3_irq_enabled_); w.pod(mmc3_irq_pending_);
    w.pod(four_screen_);
    const uint8_t has_chr_ram = chr_ram_ ? 1 : 0;
    w.pod(has_chr_ram);
    if (chr_ram_) w.bytes(chr_.data(), chr_.size());
}

bool Cartridge::load_state(StateReader& r) {
    uint16_t mapper = 0;
    NametableMirroring mirroring = NametableMirroring::Horizontal;
    r.pod(mapper); r.pod(mirroring);
    if (!r.ok() || !loaded_ || mapper != mapper_ || static_cast<uint8_t>(mirroring) > 4) return false;
    mirroring_ = mirroring;
    r.pod_array(prg_ram_);
    r.pod(prg_bank_); r.pod(chr_bank_);
    r.pod(mmc1_shift_); r.pod(mmc1_control_); r.pod(mmc1_chr0_); r.pod(mmc1_chr1_); r.pod(mmc1_prg_);
    r.pod(mmc3_select_); r.pod_array(mmc3_regs_); r.pod(mmc3_irq_latch_); r.pod(mmc3_irq_counter_);
    r.pod(mmc3_irq_reload_); r.pod(mmc3_irq_enabled_); r.pod(mmc3_irq_pending_);
    r.pod(four_screen_);
    uint8_t has_chr_ram = 0;
    r.pod(has_chr_ram);
    if (!r.ok() || has_chr_ram != (chr_ram_ ? 1 : 0)) return false;
    if (chr_ram_) r.bytes(chr_.data(), chr_.size());
    refresh_prg_map();
    return r.ok();
}

void Cartridge::unload() {
    loaded_ = false;
    battery_ = false;
    chr_ram_ = false;
    mapper_ = 0;
    mirroring_ = NametableMirroring::Horizontal;
    prg_rom_.clear();
    chr_.clear();
    prg_ram_.fill(0);
    reset_mapper_state(); // also clears the PRG window table
}

bool Cartridge::load_ines(const uint8_t* data, size_t size, std::string* error) {
    // Parse into temporary storage. A malformed replacement ROM must never
    // destroy the currently loaded cartridge or its battery-backed RAM.
    auto fail = [&](const std::string& message) {
        if (error) *error = message;
        return false;
    };
    if (!data) return fail("Null ROM buffer.");
    const RomInfo info = inspect_rom(data, size);
    if (!info.valid) {
        if (error) *error = info.error;
        return false;
    }
    if (!mapper_supported(info.mapper))
        return fail("Mapper " + std::to_string(info.mapper) +
                    " belum didukung (didukung: 0 NROM, 1 MMC1, 2 UxROM, 3 CNROM, 4 MMC3, 7 AxROM).");
    // NES 2.0 headers are accepted: PRG/CHR sizes and the 12-bit mapper number are
    // already decoded by inspect_rom(). Extended fields (submapper, RAM sizes) are ignored.

    const uint64_t prg_bytes = info.prg_rom_bytes;
    const uint64_t chr_bytes = info.chr_rom_bytes;
    switch (info.mapper) {
    case 0:
        if (prg_bytes != 16384 && prg_bytes != 32768) return fail("NROM requires 16 KiB or 32 KiB PRG ROM.");
        if (chr_bytes != 0 && chr_bytes != 8192)
            return fail("NROM requires 8 KiB CHR ROM or CHR RAM (zero CHR ROM size).");
        break;
    case 1:
        if (prg_bytes == 0 || prg_bytes % 16384 != 0) return fail("MMC1 requires PRG ROM in 16 KiB units.");
        if (chr_bytes % 8192 != 0) return fail("MMC1 requires CHR ROM in 8 KiB units or CHR RAM.");
        break;
    case 2:
        if (prg_bytes == 0 || prg_bytes % 16384 != 0) return fail("UxROM requires PRG ROM in 16 KiB units.");
        if (chr_bytes != 0 && chr_bytes != 8192) return fail("UxROM requires CHR RAM or 8 KiB CHR ROM.");
        break;
    case 3:
        if (prg_bytes != 16384 && prg_bytes != 32768) return fail("CNROM requires 16 KiB or 32 KiB PRG ROM.");
        if (chr_bytes == 0 || chr_bytes % 8192 != 0) return fail("CNROM requires CHR ROM in 8 KiB units.");
        break;
    case 4:
        if (prg_bytes % 8192 != 0) return fail("MMC3 requires PRG ROM in 8 KiB units.");
        if (chr_bytes != 0 && chr_bytes % 1024 != 0) return fail("MMC3 requires CHR ROM in 1 KiB units or CHR RAM.");
        break;
    case 7:
        if (prg_bytes == 0 || prg_bytes % 32768 != 0) return fail("AxROM requires PRG ROM in 32 KiB units.");
        if (chr_bytes != 0) return fail("AxROM uses CHR RAM; CHR ROM is not expected.");
        break;
    default: break;
    }

    const size_t prg_size = static_cast<size_t>(prg_bytes);
    const size_t chr_size = static_cast<size_t>(chr_bytes);
    if (info.payload_offset > size || prg_size > size - info.payload_offset)
        return fail("PRG ROM payload is truncated.");
    const size_t chr_offset = info.payload_offset + prg_size;
    if (chr_offset > size || chr_size > size - chr_offset)
        return fail("CHR ROM payload is truncated.");

    std::vector<uint8_t> new_prg(data + info.payload_offset, data + info.payload_offset + prg_size);
    // iNES trainers occupy $7000-$71FF, i.e. offset $1000 in PRG RAM.
    std::array<uint8_t, 8192> new_prg_ram{};
    if (info.trainer) {
        std::copy(data + 16, data + 16 + 512, new_prg_ram.begin() + 0x1000);
    }
    const bool new_chr_ram = chr_size == 0;
    std::vector<uint8_t> new_chr;
    if (new_chr_ram) new_chr.assign(8192, 0);
    else new_chr.assign(data + chr_offset, data + chr_offset + chr_size);
    NametableMirroring new_mirroring = info.four_screen ? NametableMirroring::FourScreen
        : ((data[6] & 0x01) ? NametableMirroring::Vertical : NametableMirroring::Horizontal);
    if (info.mapper == 7) new_mirroring = NametableMirroring::SingleScreenLower;

    // Commit only after all validation and allocations have succeeded.
    prg_rom_ = std::move(new_prg);
    chr_ = std::move(new_chr);
    prg_ram_ = new_prg_ram;
    chr_ram_ = new_chr_ram;
    battery_ = info.battery;
    mirroring_ = new_mirroring;
    initial_mirroring_ = new_mirroring;
    four_screen_ = info.four_screen;
    mapper_ = info.mapper;
    reset_mapper_state();
    if (mapper_ == 1) apply_mmc1_mirroring();
    loaded_ = true;
    refresh_prg_map();
    if (error) error->clear();
    return true;
}

void Cartridge::refresh_prg_map() {
    if (prg_rom_.empty()) { prg_pages_.fill(nullptr); return; }
    for (unsigned i = 0; i < 4; ++i)
        prg_pages_[i] = prg_rom_.data() + prg_offset(static_cast<uint16_t>(0x8000U + i * 0x2000U)) % prg_rom_.size();
}

size_t Cartridge::prg_offset(uint16_t address) const {
    const size_t banks16 = std::max<size_t>(1, prg_rom_.size() / 16384);
    const bool upper = address >= 0xC000;
    switch (mapper_) {
    case 2: {
        const size_t bank = upper ? banks16 - 1 : (static_cast<size_t>(prg_bank_) % banks16);
        return bank * 16384 + (address & 0x3FFF);
    }
    case 4: {
        const size_t banks8 = std::max<size_t>(1, prg_rom_.size() / 8192);
        const bool swap = (mmc3_select_ & 0x40) != 0;
        size_t bank;
        switch ((address >> 13) & 3U) {
        case 0: bank = swap ? banks8 - 2 : (mmc3_regs_[6] & 0x3FU); break;
        case 1: bank = mmc3_regs_[7] & 0x3FU; break;
        case 2: bank = swap ? (mmc3_regs_[6] & 0x3FU) : banks8 - 2; break;
        default: bank = banks8 - 1; break;
        }
        return (bank % banks8) * 8192 + (address & 0x1FFF);
    }
    case 7: {
        const size_t banks32 = std::max<size_t>(1, prg_rom_.size() / 32768);
        return (static_cast<size_t>(prg_bank_) % banks32) * 32768 + (address & 0x7FFF);
    }
    case 1: {
        const unsigned mode = (mmc1_control_ >> 2) & 3U;
        size_t bank;
        if (mode <= 1) bank = (static_cast<size_t>(mmc1_prg_ & 0x0E) | (upper ? 1U : 0U)) % banks16;
        else if (mode == 2) bank = upper ? (static_cast<size_t>(mmc1_prg_ & 0x0F) % banks16) : 0;
        else bank = upper ? banks16 - 1 : (static_cast<size_t>(mmc1_prg_ & 0x0F) % banks16);
        return bank * 16384 + (address & 0x3FFF);
    }
    default: // NROM and CNROM
        return prg_rom_.size() == 16384 ? (address & 0x3FFFU) : (address & 0x7FFFU);
    }
}

size_t Cartridge::chr_offset(uint16_t address) const {
    address &= 0x1FFF;
    if (chr_ram_) return address;
    if (mapper_ == 3) {
        const size_t banks8 = std::max<size_t>(1, chr_.size() / 8192);
        return (static_cast<size_t>(chr_bank_) % banks8) * 8192 + address;
    }
    if (mapper_ == 4) {
        const size_t banks1 = std::max<size_t>(1, chr_.size() / 1024);
        return (mmc3_chr_bank_1k(address) % banks1) * 1024 + (address & 0x03FF);
    }
    if (mapper_ == 1) {
        const size_t banks4 = std::max<size_t>(1, chr_.size() / 4096);
        size_t bank;
        if ((mmc1_control_ & 0x10) == 0) bank = (static_cast<size_t>(mmc1_chr0_ & 0x1E) | (address >> 12)) % banks4;
        else bank = static_cast<size_t>(address < 0x1000 ? mmc1_chr0_ : mmc1_chr1_) % banks4;
        return bank * 4096 + (address & 0x0FFF);
    }
    return address;
}

size_t Cartridge::mmc3_chr_bank_1k(uint16_t address) const {
    // CHR A12 inversion swaps which half of the pattern space holds the 2 KiB banks.
    const unsigned slot = ((address & 0x1FFFU) >> 10) ^ ((mmc3_select_ & 0x80U) ? 4U : 0U);
    switch (slot) {
    case 0: return mmc3_regs_[0] & 0xFEU;
    case 1: return (mmc3_regs_[0] & 0xFEU) | 1U;
    case 2: return mmc3_regs_[1] & 0xFEU;
    case 3: return (mmc3_regs_[1] & 0xFEU) | 1U;
    default: return mmc3_regs_[slot - 2];
    }
}

void Cartridge::write_mmc3(uint16_t address, uint8_t value) {
    const bool odd = (address & 1U) != 0;
    switch ((address >> 13) & 3U) {
    case 0: // $8000-$9FFF
        if (!odd) mmc3_select_ = value;
        else mmc3_regs_[mmc3_select_ & 7U] = value;
        break;
    case 1: // $A000-$BFFF
        if (!odd && !four_screen_)
            mirroring_ = (value & 1U) ? NametableMirroring::Horizontal : NametableMirroring::Vertical;
        break; // odd: PRG RAM protect, ignored
    case 2: // $C000-$DFFF
        if (!odd) mmc3_irq_latch_ = value;
        else { mmc3_irq_counter_ = 0; mmc3_irq_reload_ = true; }
        break;
    default: // $E000-$FFFF
        if (!odd) { mmc3_irq_enabled_ = false; mmc3_irq_pending_ = false; }
        else mmc3_irq_enabled_ = true;
        break;
    }
}

void Cartridge::clock_scanline() {
    if (!loaded_ || mapper_ != 4) return;
    if (mmc3_irq_counter_ == 0 || mmc3_irq_reload_) {
        mmc3_irq_counter_ = mmc3_irq_latch_;
        mmc3_irq_reload_ = false;
    } else {
        --mmc3_irq_counter_;
    }
    if (mmc3_irq_counter_ == 0 && mmc3_irq_enabled_) mmc3_irq_pending_ = true;
}

void Cartridge::apply_mmc1_mirroring() {
    switch (mmc1_control_ & 3U) {
    case 0: mirroring_ = NametableMirroring::SingleScreenLower; break;
    case 1: mirroring_ = NametableMirroring::SingleScreenUpper; break;
    case 2: mirroring_ = NametableMirroring::Vertical; break;
    default: mirroring_ = NametableMirroring::Horizontal; break;
    }
}

void Cartridge::write_mmc1(uint16_t address, uint8_t value) {
    if (value & 0x80) {
        mmc1_shift_ = 0x10;
        mmc1_control_ |= 0x0C;
        apply_mmc1_mirroring();
        return;
    }
    const bool complete = (mmc1_shift_ & 1U) != 0;
    mmc1_shift_ = static_cast<uint8_t>((mmc1_shift_ >> 1) | ((value & 1U) << 4));
    if (!complete) return;
    const uint8_t data = mmc1_shift_ & 0x1F;
    switch ((address >> 13) & 3U) {
    case 0: mmc1_control_ = data; apply_mmc1_mirroring(); break;
    case 1: mmc1_chr0_ = data; break;
    case 2: mmc1_chr1_ = data; break;
    default: mmc1_prg_ = data; break;
    }
    mmc1_shift_ = 0x10;
}

bool Cartridge::cpu_read(uint16_t address, uint8_t& value) const {
    if (!loaded_) return false;
    if (address >= 0x6000 && address <= 0x7FFF) {
        value = prg_ram_[address - 0x6000];
        return true;
    }
    if (address >= 0x8000) {
        value = prg_pages_[(address >> 13) & 3U][address & 0x1FFFU];
        return true;
    }
    return false;
}

bool Cartridge::cpu_write(uint16_t address, uint8_t value) {
    if (!loaded_) return false;
    if (address >= 0x6000 && address <= 0x7FFF) {
        prg_ram_[address - 0x6000] = value;
        return true;
    }
    if (address < 0x8000) return false;
    switch (mapper_) {
    case 1: write_mmc1(address, value); break;
    case 2: prg_bank_ = value; break;
    case 3: chr_bank_ = value; break;
    case 4: write_mmc3(address, value); break;
    case 7:
        prg_bank_ = value & 0x07;
        mirroring_ = (value & 0x10) ? NametableMirroring::SingleScreenUpper : NametableMirroring::SingleScreenLower;
        break;
    default: break; // NROM: ROM writes are consumed but change nothing.
    }
    refresh_prg_map();
    return true;
}

bool Cartridge::export_battery_ram(std::vector<uint8_t>& out) const {
    if (!loaded_ || !battery_) return false;
    out.assign(prg_ram_.begin(), prg_ram_.end());
    return true;
}

bool Cartridge::import_battery_ram(const uint8_t* data, size_t size, std::string* error) {
    auto fail = [&](const char* message) {
        if (error) *error = message;
        return false;
    };
    if (!loaded_) return fail("No cartridge is loaded.");
    if (!battery_) return fail("Cartridge does not declare battery-backed PRG RAM.");
    if (data == nullptr) return fail("Battery RAM input is null.");
    if (size != prg_ram_.size()) return fail("Battery RAM blob must be exactly 8192 bytes.");
    std::copy(data, data + size, prg_ram_.begin());
    if (error) error->clear();
    return true;
}

bool Cartridge::ppu_read(uint16_t address, uint8_t& value) const {
    if (!loaded_ || address >= 0x2000) return false;
    value = chr_[chr_offset(address) % chr_.size()];
    return true;
}

bool Cartridge::ppu_write(uint16_t address, uint8_t value) {
    if (!loaded_ || address >= 0x2000) return false;
    if (chr_ram_) chr_[address & 0x1FFF] = value;
    return chr_ram_;
}

} // namespace nes
