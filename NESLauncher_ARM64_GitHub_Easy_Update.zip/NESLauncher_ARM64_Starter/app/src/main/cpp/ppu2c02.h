#pragma once

#include <array>
#include <cstdint>

namespace nes {
class Cartridge;

// Register/memory-level PPU foundation. Scanline rendering and sprite evaluation
// are intentionally separate future work; this class already models CPU-visible
// PPU registers, VRAM addressing, buffering, and iNES nametable mirroring.
class Ppu2C02 {
public:
    // Resets volatile PPU state and memory but keeps the cartridge connection.
    void reset();
    void attach_cartridge(Cartridge* cartridge) { cartridge_ = cartridge; }
    uint8_t cpu_read_register(uint16_t address);
    void cpu_write_register(uint16_t address, uint8_t value);
    uint8_t read_memory(uint16_t address);
    void write_memory(uint16_t address, uint8_t value);
    void set_vblank(bool active);
    // Advances the NTSC PPU clock. Three PPU dots elapse per CPU cycle.
    void clock_cpu_cycles(uint32_t cpu_cycles);
    void clock_ppu_dots(uint32_t dots);
    uint16_t scanline() const { return scanline_; }
    uint16_t dot() const { return dot_; }
    uint64_t frame_count() const { return frame_count_; }
    bool take_nmi_request();
    // Renders a deterministic 256x240 background snapshot using current VRAM.
    // Returns NES palette color values (0..63), one byte per pixel.
    std::array<uint8_t, 256 * 240> render_background_frame();
    // Frame produced by the per-scanline renderer while the PPU clock runs. It is
    // complete when frame_count() advances. Values are NES palette indices (0..63).
    const std::array<uint8_t, 256 * 240>& frame_buffer() const { return frame_buffer_; }

    uint16_t vram_address() const { return vram_addr_; }
    uint8_t control() const { return ctrl_; }
    uint8_t mask() const { return mask_; }
    uint8_t status() const { return status_; }

private:
    uint16_t normalize_address(uint16_t address) const;
    uint16_t map_nametable_address(uint16_t address) const;
    void increment_vram_address();
    bool rendering_enabled() const { return (mask_ & 0x18) != 0; }
    // Per-scanline rendering uses the loopy v register, so mid-frame scroll
    // changes (status bars, split screens) appear on the scanline they affect.
    void render_scanline(int y);
    void increment_y();
    void copy_horizontal();
    void copy_vertical();
    // NMI is edge-triggered: only a low-to-high transition queues a request.
    void update_nmi_line();

    Cartridge* cartridge_ = nullptr;
    std::array<uint8_t, 8192> fallback_pattern_ram_{};
    std::array<uint8_t, 4096> nametable_ram_{};
    std::array<uint8_t, 32> palette_ram_{};
    std::array<uint8_t, 256> oam_{};
    uint8_t ctrl_ = 0;
    uint8_t mask_ = 0;
    uint8_t status_ = 0;
    uint8_t oam_addr_ = 0;
    uint8_t open_bus_ = 0;
    uint8_t read_buffer_ = 0;
    uint16_t vram_addr_ = 0;
    uint16_t temp_addr_ = 0;
    uint8_t fine_x_ = 0;
    bool write_latch_ = false;
    bool nmi_pending_ = false;
    bool nmi_line_ = false;
    // NTSC 2C02 timing: scanlines 0-261, dots 0-340.
    uint16_t scanline_ = 261;
    uint16_t dot_ = 0;
    uint64_t frame_count_ = 0;
    bool odd_frame_ = false;
    std::array<uint8_t, 256 * 240> frame_buffer_{};
    int sprite0_hit_dot_ = -1; // Dot on the current scanline where sprite-zero hit becomes visible.
};
} // namespace nes
