#pragma once
#include <array>
#include <cstdint>
#include <vector>

namespace nes {
class Cartridge;
class Ppu2C02;
class Apu;
class CpuBus {
public:
    CpuBus();
    uint8_t read(uint16_t address);
    void write(uint16_t address, uint8_t value);
    void load(uint16_t address, const std::vector<uint8_t>& bytes);
    void map_prg_rom(const uint8_t* data, size_t size);
    void attach_cartridge(Cartridge* cartridge) { cartridge_ = cartridge; }
    void attach_ppu(Ppu2C02* ppu) { ppu_ = ppu; }
    void attach_apu(Apu* apu) { apu_ = apu; }
    void set_reset_vector(uint16_t address);
    // Installs a vector in the open-bus backing memory, primarily for host tests.
    void set_vector(uint16_t vector, uint16_t address);
    // Button bits: A, B, Select, Start, Up, Down, Left, Right (bit 0 to 7).
    void set_controller_state(unsigned player, uint8_t buttons);
    // Clears volatile CPU-side state while preserving attached devices.
    void reset();
    // Returns and clears CPU stall cycles requested by DMA transfers.
    uint32_t take_dma_stall_cycles(bool odd_cpu_cycle = false);
    bool dma_pending() const { return dma_transfers_pending_ != 0; }
    std::array<uint8_t, 2048> ram{};
private:
    std::array<uint8_t, 65536> memory_{};
    std::array<uint8_t, 32768> prg_{};
    size_t prg_size_ = 0;
    Cartridge* cartridge_ = nullptr;
    Ppu2C02* ppu_ = nullptr;
    Apu* apu_ = nullptr;
    std::array<uint8_t, 2> controller_live_{};
    std::array<uint8_t, 2> controller_shift_{};
    bool controller_strobe_ = false;
    uint32_t dma_transfers_pending_ = 0;
};

class Cpu6502 {
public:
    explicit Cpu6502(CpuBus& bus);
    void reset();
    int step(); // Returns CPU cycles consumed; unsupported unofficial opcodes consume 2 cycles.
    void request_nmi();
    void request_irq();
    void clear_irq() { irq_pending_ = false; }
    uint8_t a() const { return a_; }
    uint8_t x() const { return x_; }
    uint8_t y() const { return y_; }
    uint8_t sp() const { return sp_; }
    uint8_t status() const { return p_; }
    uint16_t pc() const { return pc_; }
    void set_state(uint16_t pc, uint8_t a, uint8_t x, uint8_t y, uint8_t sp, uint8_t p);

    // Opcode decode table.
    enum class Mode : uint8_t { Imp, Acc, Imm, Zp, ZpX, ZpY, Abs, AbsX, AbsY, Ind, XInd, IndY, Rel };
    enum class Op : uint8_t { Ill, ADC, AND, ASL, BCC, BCS, BEQ, BIT, BMI, BNE, BPL, BRK, BVC, BVS, CLC, CLD, CLI, CLV, CMP, CPX, CPY, DEC, DEX, DEY, EOR, INC, INX, INY, JMP, JSR, LDA, LDX, LDY, LSR, NOP, ORA, PHA, PHP, PLA, PLP, ROL, ROR, RTI, RTS, SBC, SEC, SED, SEI, STA, STX, STY, TAX, TAY, TSX, TXA, TXS, TYA };
    struct Instruction { Op op = Op::Ill; Mode mode = Mode::Imp; uint8_t cycles = 2; bool page_cycle = false; };
    static const std::array<Instruction, 256>& table();

private:
    CpuBus& bus_;
    uint16_t pc_ = 0;
    uint8_t a_ = 0, x_ = 0, y_ = 0, sp_ = 0xFD, p_ = 0x24;
    bool nmi_pending_ = false, irq_pending_ = false;
    uint8_t fetch8();
    uint16_t fetch16();
    uint16_t address(Mode mode, bool* crossed = nullptr);
    uint8_t read(uint16_t addr) { return bus_.read(addr);}
    void write(uint16_t addr, uint8_t value) { bus_.write(addr, value); }
    void push(uint8_t value);
    uint8_t pull();
    void set_nz(uint8_t value);
    void compare(uint8_t lhs, uint8_t rhs);
    void interrupt(uint16_t vector, bool brk);
};
}
