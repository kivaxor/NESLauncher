#include "cartridge.h"

#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

// Builds an iNES image. PRG bytes equal their 16 KiB bank index; CHR bytes equal
// their 4 KiB bank index, so tests can tell which bank is mapped.
static std::vector<uint8_t> make_rom(unsigned mapper, size_t prg_banks16, size_t chr_banks8, uint8_t flags6 = 0) {
    const size_t prg = prg_banks16 * 16384, chr = chr_banks8 * 8192;
    std::vector<uint8_t> rom(16 + prg + chr, 0);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = static_cast<uint8_t>(prg_banks16);
    rom[5] = static_cast<uint8_t>(chr_banks8);
    rom[6] = static_cast<uint8_t>(((mapper & 0x0F) << 4) | flags6);
    rom[7] = static_cast<uint8_t>(mapper & 0xF0);
    for (size_t i = 0; i < prg; ++i) rom[16 + i] = static_cast<uint8_t>(i / 16384);
    for (size_t i = 0; i < chr; ++i) rom[16 + prg + i] = static_cast<uint8_t>(i / 4096);
    return rom;
}

static void mmc1_write(nes::Cartridge& cart, uint16_t address, uint8_t value) {
    for (int i = 0; i < 5; ++i) cart.cpu_write(address, static_cast<uint8_t>((value >> i) & 1));
}

int main() {
    std::string error;
    uint8_t v = 0;

    // UxROM (mapper 2): switchable $8000, fixed last bank at $C000, CHR RAM.
    {
        nes::Cartridge cart;
        auto rom = make_rom(2, 4, 0);
        assert(cart.load_ines(rom.data(), rom.size(), &error));
        assert(cart.mapper() == 2 && cart.chr_is_ram());
        assert(cart.cpu_read(0x8000, v) && v == 0);
        assert(cart.cpu_read(0xC000, v) && v == 3);
        assert(cart.cpu_write(0x8000, 2));
        assert(cart.cpu_read(0x8000, v) && v == 2);
        assert(cart.cpu_read(0xC000, v) && v == 3);
        assert(cart.cpu_write(0x8000, 6)); // wraps modulo bank count
        assert(cart.cpu_read(0x8000, v) && v == 2);
        assert(cart.ppu_write(0x0100, 0x5A) && cart.ppu_read(0x0100, v) && v == 0x5A);
    }

    // CNROM (mapper 3): 8 KiB CHR banks.
    {
        nes::Cartridge cart;
        auto rom = make_rom(3, 2, 4);
        assert(cart.load_ines(rom.data(), rom.size(), &error));
        assert(cart.ppu_read(0x0000, v) && v == 0);
        assert(cart.cpu_write(0x8000, 2));
        assert(cart.ppu_read(0x0000, v) && v == 4);   // 8 KiB bank 2 = 4 KiB banks 4/5
        assert(cart.ppu_read(0x1000, v) && v == 5);
        assert(!cart.ppu_write(0x0000, 1));           // CHR ROM is read-only
        auto no_chr = make_rom(3, 2, 0);
        assert(!cart.load_ines(no_chr.data(), no_chr.size(), &error) && !error.empty());
    }

    // AxROM (mapper 7): 32 KiB PRG banks and single-screen mirroring select.
    {
        nes::Cartridge cart;
        auto rom = make_rom(7, 4, 0);
        assert(cart.load_ines(rom.data(), rom.size(), &error));
        assert(cart.mirroring() == nes::NametableMirroring::SingleScreenLower);
        assert(cart.cpu_read(0x8000, v) && v == 0);
        assert(cart.cpu_write(0x8000, 0x11));
        assert(cart.cpu_read(0x8000, v) && v == 2);   // 32 KiB bank 1 begins at 16 KiB bank 2
        assert(cart.cpu_read(0xC000, v) && v == 3);
        assert(cart.mirroring() == nes::NametableMirroring::SingleScreenUpper);
        auto odd = make_rom(7, 3, 0);
        assert(!cart.load_ines(odd.data(), odd.size(), &error));
        assert(cart.loaded() && cart.mapper() == 7);
    }

    // MMC1 (mapper 1): serial register, PRG modes, CHR modes and mirroring.
    {
        nes::Cartridge cart;
        auto rom = make_rom(1, 8, 4);
        assert(cart.load_ines(rom.data(), rom.size(), &error));
        assert(cart.cpu_read(0x8000, v) && v == 0);
        assert(cart.cpu_read(0xC000, v) && v == 7);  // power-on: last bank fixed
        mmc1_write(cart, 0x8000, 0x0E);               // vertical, PRG mode 3, CHR 8 KiB mode
        assert(cart.mirroring() == nes::NametableMirroring::Vertical);
        mmc1_write(cart, 0xE000, 3);
        assert(cart.cpu_read(0x8000, v) && v == 3);
        assert(cart.cpu_read(0xC000, v) && v == 7);
        mmc1_write(cart, 0x8000, 0x0A);               // PRG mode 2: first bank fixed at $8000
        mmc1_write(cart, 0xE000, 5);
        assert(cart.cpu_read(0x8000, v) && v == 0);
        assert(cart.cpu_read(0xC000, v) && v == 5);
        mmc1_write(cart, 0x8000, 0x00);               // PRG mode 0: 32 KiB switching
        mmc1_write(cart, 0xE000, 2);
        assert(cart.cpu_read(0x8000, v) && v == 2);
        assert(cart.cpu_read(0xC000, v) && v == 3);
        assert(cart.mirroring() == nes::NametableMirroring::SingleScreenLower);
        mmc1_write(cart, 0x8000, 0x1E);               // CHR 4 KiB mode
        mmc1_write(cart, 0xA000, 2);
        mmc1_write(cart, 0xC000, 5);
        assert(cart.ppu_read(0x0000, v) && v == 2);
        assert(cart.ppu_read(0x1000, v) && v == 5);
        mmc1_write(cart, 0x8000, 0x0E);               // CHR 8 KiB mode ignores bit 0
        mmc1_write(cart, 0xA000, 3);
        assert(cart.ppu_read(0x0000, v) && v == 2);
        assert(cart.ppu_read(0x1000, v) && v == 3);
        cart.cpu_write(0x8000, 0x01);                 // partial serial write...
        cart.cpu_write(0x8000, 0x80);                 // ...is cleared by reset
        assert(cart.cpu_read(0xC000, v) && v == 7);
    }

    // Unsupported mappers fail without disturbing the current cartridge.
    {
        nes::Cartridge cart;
        auto good = make_rom(2, 2, 0);
        assert(cart.load_ines(good.data(), good.size(), &error));
        auto mmc3 = make_rom(4, 2, 2);
        assert(!cart.load_ines(mmc3.data(), mmc3.size(), &error));
        assert(error.find("4") != std::string::npos);
        assert(cart.loaded() && cart.mapper() == 2);
    }

    std::cout << "Mapper tests passed\n";
}
