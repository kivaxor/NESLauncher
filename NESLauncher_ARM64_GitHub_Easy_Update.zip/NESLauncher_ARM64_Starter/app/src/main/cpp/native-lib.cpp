#include <jni.h>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "nes_engine.h"
#include "nes_machine.h"

namespace {
std::unique_ptr<nes::NesMachine> g_machine;
std::mutex g_machine_mutex;
bool g_recompiler_wanted = true; // 6502 -> ARM64 recompiler; effective only on ARM64 builds
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeEngineStatus(
        JNIEnv* env, jobject /* thiz */) {
    const auto status = nes::engine_status();
    return env->NewStringUTF(status.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeInspectRom(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("ROM tidak valid: data kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca data ROM dari Android.");
    const auto info = nes::inspect_rom(reinterpret_cast<const uint8_t*>(raw),
                                        static_cast<size_t>(length));
    const auto description = nes::describe_rom(info);
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    return env->NewStringUTF(description.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeLoadRom(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("Gagal: data ROM kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca ROM dari Android.");

    auto candidate = std::make_unique<nes::NesMachine>();
    std::string error;
    bool wanted;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        wanted = g_recompiler_wanted;
    }
    candidate->set_recompiler_enabled(wanted);
    const bool loaded = candidate->load_rom(reinterpret_cast<const uint8_t*>(raw),
                                             static_cast<size_t>(length), &error);
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    if (!loaded) return env->NewStringUTF(("ROM tidak dapat dijalankan: " + error).c_str());
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        g_machine = std::move(candidate);
    }
    return env->NewStringUTF("ROM berhasil dimuat. Tekan Mulai Emulasi atau Render Frame.");
}

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_neslauncher_MainActivity_nativeRunFrame(
        JNIEnv* env, jobject /* thiz */) {
    std::array<uint8_t, 256 * 240> pixels{};
    std::string error;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (!g_machine || !g_machine->loaded()) return nullptr;
        if (!g_machine->run_frame(pixels, &error)) return nullptr;
    }
    jbyteArray result = env->NewByteArray(static_cast<jsize>(pixels.size()));
    if (result == nullptr) return nullptr;
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(pixels.size()),
                            reinterpret_cast<const jbyte*>(pixels.data()));
    return result;
}

extern "C"
JNIEXPORT jshortArray JNICALL
Java_com_example_neslauncher_MainActivity_nativeTakeAudio(
        JNIEnv* env, jobject /* thiz */) {
    std::vector<int16_t> samples;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (!g_machine || !g_machine->loaded()) return nullptr;
        g_machine->take_audio(samples);
    }
    jshortArray result = env->NewShortArray(static_cast<jsize>(samples.size()));
    if (result == nullptr) return nullptr;
    if (!samples.empty())
        env->SetShortArrayRegion(result, 0, static_cast<jsize>(samples.size()),
                                 reinterpret_cast<const jshort*>(samples.data()));
    return result;
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_neslauncher_MainActivity_nativeAudioSampleRate(
        JNIEnv* /* env */, jobject /* thiz */) {
    return 44100;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_neslauncher_MainActivity_nativeSetControllerState(
        JNIEnv* /* env */, jobject /* thiz */, jint player, jint buttons) {
    if (player < 0 || player > 1) return;
    std::lock_guard<std::mutex> lock(g_machine_mutex);
    if (!g_machine || !g_machine->loaded()) return;
    g_machine->set_controller_state(static_cast<unsigned>(player),
                                    static_cast<uint8_t>(buttons & 0xFF));
}


extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_neslauncher_MainActivity_nativeExportBatteryRam(
        JNIEnv* env, jobject /* thiz */) {
    std::vector<uint8_t> ram;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (!g_machine || !g_machine->export_battery_ram(ram)) return nullptr;
    }
    jbyteArray result = env->NewByteArray(static_cast<jsize>(ram.size()));
    if (result == nullptr) return nullptr;
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(ram.size()),
                            reinterpret_cast<const jbyte*>(ram.data()));
    return result;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeImportBatteryRam(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("Data save RAM kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca data save RAM.");
    std::string error;
    bool imported = false;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (g_machine && g_machine->loaded()) {
            imported = g_machine->import_battery_ram(
                    reinterpret_cast<const uint8_t*>(raw), static_cast<size_t>(length), &error);
        } else {
            error = "Belum ada ROM yang dimuat.";
        }
    }
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    if (!imported) return env->NewStringUTF(("Gagal memuat save RAM: " + error).c_str());
    return env->NewStringUTF("Save RAM berhasil dimuat.");
}


extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_neslauncher_MainActivity_nativeSetRecompiler(
        JNIEnv* /* env */, jobject /* thiz */, jboolean enabled) {
    std::lock_guard<std::mutex> lock(g_machine_mutex);
    g_recompiler_wanted = enabled == JNI_TRUE;
    if (g_machine) return g_machine->set_recompiler_enabled(g_recompiler_wanted) ? JNI_TRUE : JNI_FALSE;
    return JNI_FALSE;
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_neslauncher_MainActivity_nativeRecompilerActive(
        JNIEnv* /* env */, jobject /* thiz */) {
    std::lock_guard<std::mutex> lock(g_machine_mutex);
    return g_machine && g_machine->recompiler_active() ? JNI_TRUE : JNI_FALSE;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeJitStats(
        JNIEnv* env, jobject /* thiz */) {
    std::string text;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (g_machine && g_machine->recompiler_active()) {
            text = "blok=" + std::to_string(g_machine->jit_compiled_blocks()) +
                   " jalan=" + std::to_string(g_machine->recompiled_blocks_run()) +
                   " interp=" + std::to_string(g_machine->interpreted_steps()) +
                   " flush=" + std::to_string(g_machine->jit_flushes()) +
                   " ganti-bank=" + std::to_string(g_machine->jit_mapping_switches()) +
                   " (pakai ulang " + std::to_string(g_machine->jit_mapping_reuses()) + ")";
        }
    }
    return env->NewStringUTF(text.c_str());
}
