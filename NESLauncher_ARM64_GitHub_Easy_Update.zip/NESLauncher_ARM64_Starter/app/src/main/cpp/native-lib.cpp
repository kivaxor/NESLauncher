#include <jni.h>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "nes_engine.h"
#include "nes_machine.h"

namespace {
std::unique_ptr<nes::NesMachine> g_machine;
std::mutex g_machine_mutex;
// Touch input must never wait for a running frame, so buttons live in atomics and are applied
// at the start of every frame (<= 1 frame of latency).
std::atomic<uint8_t> g_pad[2] = {0, 0};
// Audio stretch factor chosen by the host's rate controller (applied at the start of each frame).
std::atomic<double> g_audio_ratio{1.0};
// Last completed frame as NES palette indices; converted to ARGB by nativeFillFrame.
std::array<uint8_t, 256 * 240> g_last_frame{};
// Standard 64-entry NTSC palette as opaque ARGB.
constexpr uint32_t kNesPalette[64] = {
    0xFF666666u, 0xFF002A88u, 0xFF1412A7u, 0xFF3B00A4u,
    0xFF5C007Eu, 0xFF6E0040u, 0xFF6C0600u, 0xFF561D00u,
    0xFF333500u, 0xFF0B4800u, 0xFF005200u, 0xFF004F08u,
    0xFF00404Du, 0xFF000000u, 0xFF000000u, 0xFF000000u,
    0xFFADADADu, 0xFF155FD9u, 0xFF4240FFu, 0xFF7527FEu,
    0xFFA01ACCu, 0xFFB71E7Bu, 0xFFB53120u, 0xFF994E00u,
    0xFF6B6D00u, 0xFF388700u, 0xFF0C9300u, 0xFF008F32u,
    0xFF007C8Du, 0xFF000000u, 0xFF000000u, 0xFF000000u,
    0xFFFFFEFFu, 0xFF64B0FFu, 0xFF9290FFu, 0xFFC676FFu,
    0xFFF36AFFu, 0xFFFE6ECCu, 0xFFFE8170u, 0xFFEA9E22u,
    0xFFBCBE00u, 0xFF88D800u, 0xFF5CE430u, 0xFF45E082u,
    0xFF48CDDEu, 0xFF4F4F4Fu, 0xFF000000u, 0xFF000000u,
    0xFFFFFEFFu, 0xFFC0DFFFu, 0xFFD3D2FFu, 0xFFE8C8FFu,
    0xFFFBC2FFu, 0xFFFEC4EAu, 0xFFFECCC5u, 0xFFF7D8A5u,
    0xFFE4E594u, 0xFFCFEE96u, 0xFFBDF4ABu, 0xFFB3F3CCu,
    0xFFB5EBF2u, 0xFFB8B8B8u, 0xFF000000u, 0xFF000000u,
};

// 48 kHz is the native output rate of nearly all Android devices, so the system mixer does not resample.
constexpr uint32_t kAudioRate = 48000;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeEngineStatus(
        JNIEnv* env, jobject /* thiz */) {
    const auto status = nes::engine_status();
    return env->NewStringUTF(status.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeInspectRom(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("ROM tidak valid: data kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca data ROM dari Android.");
    const auto info = nes::inspect_rom(reinterpret_cast<const uint8_t*>(raw),
                                        static_cast<size_t>(length));
    const auto description = nes::describe_rom(info);
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    return env->NewStringUTF(description.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeLoadRom(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("Gagal: data ROM kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca ROM dari Android.");

    auto candidate = std::make_unique<nes::NesMachine>(kAudioRate);
    // Buttons are sampled live when the game polls the controller (lowest possible input latency).
    candidate->set_controller_source(0, &g_pad[0]);
    candidate->set_controller_source(1, &g_pad[1]);
    std::string error;
    const bool loaded = candidate->load_rom(reinterpret_cast<const uint8_t*>(raw),
                                             static_cast<size_t>(length), &error);
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    if (!loaded) return env->NewStringUTF(("ROM tidak dapat dijalankan: " + error).c_str());
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        g_machine = std::move(candidate);
    }
    return env->NewStringUTF("ROM berhasil dimuat. Tekan Mulai Emulasi atau Render Frame.");
}

// Runs one frame and keeps the result in g_last_frame (no per-frame Java allocation).
extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_neslauncher_MainActivity_nativeRunFrameFast(
        JNIEnv* /* env */, jobject /* thiz */) {
    std::string error;
    std::lock_guard<std::mutex> lock(g_machine_mutex);
    if (!g_machine || !g_machine->loaded()) return JNI_FALSE;
    g_machine->set_audio_rate_adjust(g_audio_ratio.load(std::memory_order_relaxed));
    if (!g_machine->run_frame(g_last_frame, &error)) return JNI_FALSE;
    return JNI_TRUE;
}

// Converts the last frame to ARGB ints (the layout Bitmap.setPixels expects) into dst[61440].
extern "C"
JNIEXPORT void JNICALL
Java_com_example_neslauncher_MainActivity_nativeFillFrame(
        JNIEnv* env, jobject /* thiz */, jintArray dst) {
    if (dst == nullptr || env->GetArrayLength(dst) < 256 * 240) return;
    static std::array<jint, 256 * 240> argb; // 240 KB: kept off the thread stack
    std::lock_guard<std::mutex> lock(g_machine_mutex);
    for (size_t i = 0; i < argb.size(); ++i)
        argb[i] = static_cast<jint>(kNesPalette[g_last_frame[i] & 0x3F]);
    env->SetIntArrayRegion(dst, 0, static_cast<jsize>(argb.size()), argb.data());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_neslauncher_MainActivity_nativeSetAudioRateAdjust(
        JNIEnv* /* env */, jobject /* thiz */, jdouble ratio) {
    g_audio_ratio.store(ratio, std::memory_order_relaxed);
}

extern "C"
JNIEXPORT jshortArray JNICALL
Java_com_example_neslauncher_MainActivity_nativeTakeAudio(
        JNIEnv* env, jobject /* thiz */) {
    std::vector<int16_t> samples;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (!g_machine || !g_machine->loaded()) return nullptr;
        g_machine->take_audio(samples);
    }
    jshortArray result = env->NewShortArray(static_cast<jsize>(samples.size()));
    if (result == nullptr) return nullptr;
    if (!samples.empty())
        env->SetShortArrayRegion(result, 0, static_cast<jsize>(samples.size()),
                                 reinterpret_cast<const jshort*>(samples.data()));
    return result;
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_neslauncher_MainActivity_nativeAudioSampleRate(
        JNIEnv* /* env */, jobject /* thiz */) {
    return static_cast<jint>(kAudioRate);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_neslauncher_MainActivity_nativeSetControllerState(
        JNIEnv* /* env */, jobject /* thiz */, jint player, jint buttons) {
    if (player < 0 || player > 1) return;
    g_pad[player].store(static_cast<uint8_t>(buttons & 0xFF), std::memory_order_relaxed);
}


extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_neslauncher_MainActivity_nativeExportBatteryRam(
        JNIEnv* env, jobject /* thiz */) {
    std::vector<uint8_t> ram;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (!g_machine || !g_machine->export_battery_ram(ram)) return nullptr;
    }
    jbyteArray result = env->NewByteArray(static_cast<jsize>(ram.size()));
    if (result == nullptr) return nullptr;
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(ram.size()),
                            reinterpret_cast<const jbyte*>(ram.data()));
    return result;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_neslauncher_MainActivity_nativeImportBatteryRam(
        JNIEnv* env, jobject /* thiz */, jbyteArray bytes) {
    if (bytes == nullptr) return env->NewStringUTF("Data save RAM kosong.");
    const jsize length = env->GetArrayLength(bytes);
    jbyte* raw = env->GetByteArrayElements(bytes, nullptr);
    if (raw == nullptr) return env->NewStringUTF("Gagal membaca data save RAM.");
    std::string error;
    bool imported = false;
    {
        std::lock_guard<std::mutex> lock(g_machine_mutex);
        if (g_machine && g_machine->loaded()) {
            imported = g_machine->import_battery_ram(
                    reinterpret_cast<const uint8_t*>(raw), static_cast<size_t>(length), &error);
        } else {
            error = "Belum ada ROM yang dimuat.";
        }
    }
    env->ReleaseByteArrayElements(bytes, raw, JNI_ABORT);
    if (!imported) return env->NewStringUTF(("Gagal memuat save RAM: " + error).c_str());
    return env->NewStringUTF("Save RAM berhasil dimuat.");
}
