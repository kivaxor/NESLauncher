#include "ppu2c02.h"
#include "cartridge.h"

#include <algorithm>

namespace nes {
namespace {
constexpr uint8_t kVblank = 0x80;
constexpr uint8_t kSpriteZeroHit = 0x40;
constexpr uint8_t kSpriteOverflow = 0x20;
}

void Ppu2C02::reset() {
    fallback_pattern_ram_.fill(0);
    nametable_ram_.fill(0);
    palette_ram_.fill(0);
    oam_.fill(0xFF);
    ctrl_ = 0;
    mask_ = 0;
    status_ = 0;
    oam_addr_ = 0;
    open_bus_ = 0;
    read_buffer_ = 0;
    vram_addr_ = 0;
    temp_addr_ = 0;
    fine_x_ = 0;
    write_latch_ = false;
    nmi_pending_ = false;
    nmi_line_ = false;
    scanline_ = 261;
    dot_ = 0;
    frame_count_ = 0;
    odd_frame_ = false;
    frame_buffer_.fill(0);
    sprite0_hit_dot_ = -1;
}

uint16_t Ppu2C02::normalize_address(uint16_t address) const {
    address &= 0x3FFF;
    // $3000-$3EFF mirrors $2000-$2EFF.
    if (address >= 0x3000 && address < 0x3F00) address -= 0x1000;
    return address;
}

uint16_t Ppu2C02::map_nametable_address(uint16_t address) const {
    const uint16_t relative = static_cast<uint16_t>((address - 0x2000) & 0x0FFF);
    const uint16_t table = relative / 0x400;
    const uint16_t offset = relative & 0x03FF;
    NametableMirroring mirroring = cartridge_ && cartridge_->loaded()
        ? cartridge_->mirroring() : NametableMirroring::Horizontal;
    uint16_t physical = 0;
    switch (mirroring) {
    case NametableMirroring::Vertical: physical = table & 1; break;
    case NametableMirroring::Horizontal: physical = table >> 1; break;
    case NametableMirroring::FourScreen: physical = table; break;
    case NametableMirroring::SingleScreenLower: physical = 0; break;
    case NametableMirroring::SingleScreenUpper: physical = 1; break;
    }
    return static_cast<uint16_t>(physical * 0x400 + offset);
}

uint8_t Ppu2C02::read_memory(uint16_t address) {
    address = normalize_address(address);
    if (address < 0x2000) {
        uint8_t value = 0;
        if (cartridge_ && cartridge_->ppu_read(address, value)) return value;
        return fallback_pattern_ram_[address];
    }
    if (address < 0x3F00) return nametable_ram_[map_nametable_address(address)];
    uint16_t index = static_cast<uint16_t>((address - 0x3F00) & 0x1F);
    // Universal background color mirrors: $3F10/$14/$18/$1C alias $3F00/$04/$08/$0C.
    if ((index & 0x13) == 0x10) index &= 0x0F;
    return static_cast<uint8_t>(palette_ram_[index] & 0x3F);
}

void Ppu2C02::write_memory(uint16_t address, uint8_t value) {
    address = normalize_address(address);
    if (address < 0x2000) {
        if (cartridge_) {
            if (cartridge_->ppu_write(address, value)) return;
            if (cartridge_->loaded()) return; // CHR ROM is read-only.
        }
        fallback_pattern_ram_[address] = value;
        return;
    }
    if (address < 0x3F00) {
        nametable_ram_[map_nametable_address(address)] = value;
        return;
    }
    uint16_t index = static_cast<uint16_t>((address - 0x3F00) & 0x1F);
    if ((index & 0x13) == 0x10) index &= 0x0F;
    palette_ram_[index] = static_cast<uint8_t>(value & 0x3F);
}

void Ppu2C02::increment_vram_address() {
    vram_addr_ = static_cast<uint16_t>((vram_addr_ + ((ctrl_ & 0x04) ? 32 : 1)) & 0x7FFF);
}

uint8_t Ppu2C02::cpu_read_register(uint16_t address) {
    address &= 7;
    uint8_t value = open_bus_;
    switch (address) {
    case 2: // PPUSTATUS: reading clears vblank and the $2005/$2006 write toggle.
        value = static_cast<uint8_t>((status_ & 0xE0) | (open_bus_ & 0x1F));
        status_ &= static_cast<uint8_t>(~kVblank);
        write_latch_ = false;
        nmi_pending_ = false;
        update_nmi_line();
        break;
    case 4: value = oam_[oam_addr_]; break;
    case 7: {
        const uint16_t address_now = static_cast<uint16_t>(vram_addr_ & 0x3FFF);
        const uint8_t fetched = read_memory(address_now);
        if (address_now >= 0x3F00) {
            value = fetched;
            // Palette reads bypass the buffer but refill it from the mirrored nametable region.
            read_buffer_ = read_memory(static_cast<uint16_t>(address_now - 0x1000));
        } else {
            value = read_buffer_;
            read_buffer_ = fetched;
        }
        increment_vram_address();
        break;
    }
    default: break; // Write-only registers return the PPU open-bus value.
    }
    open_bus_ = value;
    return value;
}

void Ppu2C02::cpu_write_register(uint16_t address, uint8_t value) {
    address &= 7;
    open_bus_ = value;
    switch (address) {
    case 0:
        ctrl_ = value;
        temp_addr_ = static_cast<uint16_t>((temp_addr_ & 0xF3FF) | ((value & 3) << 10));
        update_nmi_line();
        break;
    case 1: mask_ = value; break;
    case 3: oam_addr_ = value; break;
    case 4: oam_[oam_addr_++] = value; break;
    case 5:
        if (!write_latch_) {
            fine_x_ = value & 7;
            temp_addr_ = static_cast<uint16_t>((temp_addr_ & 0x7FE0) | (value >> 3));
        } else {
            temp_addr_ = static_cast<uint16_t>((temp_addr_ & 0x0C1F) | ((value & 0xF8) << 2) | ((value & 7) << 12));
        }
        write_latch_ = !write_latch_;
        break;
    case 6:
        if (!write_latch_) temp_addr_ = static_cast<uint16_t>((temp_addr_ & 0x00FF) | ((value & 0x3F) << 8));
        else { temp_addr_ = static_cast<uint16_t>((temp_addr_ & 0x7F00) | value); vram_addr_ = temp_addr_; }
        write_latch_ = !write_latch_;
        break;
    case 7: write_memory(vram_addr_, value); increment_vram_address(); break;
    default: break;
    }
}

void Ppu2C02::update_nmi_line() {
    const bool next_line = (status_ & kVblank) != 0 && (ctrl_ & 0x80) != 0;
    if (next_line && !nmi_line_) nmi_pending_ = true;
    nmi_line_ = next_line;
}

void Ppu2C02::set_vblank(bool active) {
    if (active) {
        status_ |= kVblank;
        update_nmi_line();
    } else {
        status_ &= static_cast<uint8_t>(~(kVblank | kSpriteZeroHit | kSpriteOverflow));
        nmi_pending_ = false;
        update_nmi_line();
    }
}

void Ppu2C02::clock_cpu_cycles(uint32_t cpu_cycles) {
    // Avoid overflowing cpu_cycles * 3 for very large caller-supplied values.
    while (cpu_cycles-- > 0) clock_ppu_dots(3);
}

void Ppu2C02::clock_ppu_dots(uint32_t dots) {
    while (dots-- > 0) {
        // NTSC 2C02 omits dot 340 on odd frames when rendering is enabled.
        // The simplified renderer has no per-dot pipeline, but preserving this
        // one-dot timing difference keeps frame boundaries closer to hardware.
        if (scanline_ == 261 && dot_ == 339 && odd_frame_ && (mask_ & 0x18) != 0) {
            dot_ = 0;
            scanline_ = 0;
            ++frame_count_;
            odd_frame_ = !odd_frame_;
            continue;
        }

        // Per-scanline rendering: draw the whole visible line at dot 0 from the
        // state latched then, and expose sprite-zero hit when its pixel is reached.
        if (scanline_ < 240) {
            if (dot_ == 0) render_scanline(scanline_);
            if (sprite0_hit_dot_ >= 0 && dot_ == sprite0_hit_dot_) {
                status_ |= kSpriteZeroHit;
                sprite0_hit_dot_ = -1;
            }
        }
        if (rendering_enabled()) {
            if (scanline_ < 240 || scanline_ == 261) {
                if (dot_ == 256) increment_y();
                else if (dot_ == 257) copy_horizontal();
            }
            if (scanline_ == 261 && dot_ >= 280 && dot_ <= 304) copy_vertical();
        }

        // PPUSTATUS flags transition at dot 1 of the relevant scanline.
        if (dot_ == 1) {
            if (scanline_ == 241) set_vblank(true);
            else if (scanline_ == 261) set_vblank(false);
        }

        ++dot_;
        if (dot_ > 340) {
            dot_ = 0;
            ++scanline_;
            if (scanline_ > 261) {
                scanline_ = 0;
                ++frame_count_;
                odd_frame_ = !odd_frame_;
            }
        }
    }
}

void Ppu2C02::increment_y() {
    uint16_t v = vram_addr_;
    if ((v & 0x7000) != 0x7000) {
        v = static_cast<uint16_t>(v + 0x1000);
    } else {
        v = static_cast<uint16_t>(v & ~0x7000);
        uint16_t y = static_cast<uint16_t>((v & 0x03E0) >> 5);
        if (y == 29) { y = 0; v ^= 0x0800; }
        else if (y == 31) y = 0;
        else ++y;
        v = static_cast<uint16_t>((v & ~0x03E0) | (y << 5));
    }
    vram_addr_ = v;
}

void Ppu2C02::copy_horizontal() {
    vram_addr_ = static_cast<uint16_t>((vram_addr_ & ~0x041F) | (temp_addr_ & 0x041F));
}

void Ppu2C02::copy_vertical() {
    vram_addr_ = static_cast<uint16_t>((vram_addr_ & ~0x7BE0) | (temp_addr_ & 0x7BE0));
}

void Ppu2C02::render_scanline(int y) {
    uint8_t* row = &frame_buffer_[static_cast<size_t>(y) * 256];
    auto output_color = [this](uint16_t address) -> uint8_t {
        const uint8_t color = read_memory(address);
        return static_cast<uint8_t>(color & ((mask_ & 0x01) ? 0x30 : 0x3F));
    };
    std::fill(row, row + 256, output_color(0x3F00));
    sprite0_hit_dot_ = -1;
    std::array<uint8_t, 256> bg_opaque{};

    if (mask_ & 0x08) {
        const unsigned v = vram_addr_;
        const int coarse_x = static_cast<int>(v & 31U);
        const int coarse_y = static_cast<int>((v >> 5) & 31U);
        const int nt_x = static_cast<int>((v >> 10) & 1U);
        const int nt_y = static_cast<int>((v >> 11) & 1U);
        const int fine_y = static_cast<int>((v >> 12) & 7U);
        const uint16_t pattern_base = (ctrl_ & 0x10) ? 0x1000 : 0x0000;
        for (int t = 0; t < 33; ++t) {
            int col = coarse_x + t;
            const int table_x = nt_x ^ ((col >> 5) & 1);
            col &= 31;
            const uint16_t nt_base = static_cast<uint16_t>(0x2000 | (nt_y << 11) | (table_x << 10));
            const uint8_t tile = read_memory(static_cast<uint16_t>(nt_base | (coarse_y << 5) | col));
            const uint8_t attr = read_memory(static_cast<uint16_t>(nt_base + 0x3C0 + ((coarse_y >> 2) << 3) + (col >> 2)));
            const int shift = ((coarse_y & 2) << 1) | (col & 2);
            const uint8_t palette = static_cast<uint8_t>((attr >> shift) & 3);
            const uint16_t pattern = static_cast<uint16_t>(pattern_base + tile * 16 + fine_y);
            const uint8_t p0 = read_memory(pattern);
            const uint8_t p1 = read_memory(static_cast<uint16_t>(pattern + 8));
            for (int bit = 0; bit < 8; ++bit) {
                const int x = t * 8 + bit - fine_x_;
                if (x < 0 || x >= 256) continue;
                if (x < 8 && (mask_ & 0x02) == 0) continue;
                const uint8_t pixel = static_cast<uint8_t>(((p0 >> (7 - bit)) & 1) | (((p1 >> (7 - bit)) & 1) << 1));
                if (pixel == 0) continue;
                row[x] = output_color(static_cast<uint16_t>(0x3F00 + palette * 4 + pixel));
                bg_opaque[static_cast<size_t>(x)] = 1;
            }
        }
    }

    if (mask_ & 0x10) {
        const int height = (ctrl_ & 0x20) ? 16 : 8;
        int selected[8];
        int count = 0;
        for (int i = 0; i < 64; ++i) {
            const int top = static_cast<int>(oam_[static_cast<size_t>(i) * 4]) + 1;
            if (y < top || y >= top + height) continue;
            if (count < 8) selected[count++] = i;
            else { status_ |= kSpriteOverflow; break; }
        }
        std::array<uint8_t, 256> color{}, present{}, behind{}, zero_opaque{};
        // Draw from the lowest priority sprite to the highest so lower OAM indexes win.
        for (int s = count - 1; s >= 0; --s) {
            const int i = selected[s];
            const size_t o = static_cast<size_t>(i) * 4;
            const int top = static_cast<int>(oam_[o]) + 1;
            const uint8_t tile = oam_[o + 1];
            const uint8_t attributes = oam_[o + 2];
            const int left = oam_[o + 3];
            int row_in_sprite = y - top;
            if (attributes & 0x80) row_in_sprite = height - 1 - row_in_sprite;
            uint16_t pattern;
            if (height == 16) {
                const uint16_t bank = (tile & 1) ? 0x1000 : 0x0000;
                pattern = static_cast<uint16_t>(bank + ((tile & 0xFE) + (row_in_sprite >= 8 ? 1 : 0)) * 16 + (row_in_sprite & 7));
            } else {
                pattern = static_cast<uint16_t>(((ctrl_ & 0x08) ? 0x1000 : 0x0000) + tile * 16 + row_in_sprite);
            }
            const uint8_t p0 = read_memory(pattern);
            const uint8_t p1 = read_memory(static_cast<uint16_t>(pattern + 8));
            for (int dx = 0; dx < 8; ++dx) {
                const int x = left + dx;
                if (x >= 256 || (x < 8 && (mask_ & 0x04) == 0)) continue;
                const int bit = 7 - ((attributes & 0x40) ? 7 - dx : dx);
                const uint8_t pixel = static_cast<uint8_t>(((p0 >> bit) & 1) | (((p1 >> bit) & 1) << 1));
                if (pixel == 0) continue;
                const size_t xi = static_cast<size_t>(x);
                present[xi] = 1;
                behind[xi] = (attributes & 0x20) ? 1 : 0;
                color[xi] = output_color(static_cast<uint16_t>(0x3F10 + (attributes & 3) * 4 + pixel));
                if (i == 0) zero_opaque[xi] = 1;
            }
        }
        for (int x = 0; x < 256; ++x) {
            const size_t xi = static_cast<size_t>(x);
            if (present[xi] && !(behind[xi] && bg_opaque[xi])) row[x] = color[xi];
            const bool clip_ok = x >= 8 || ((mask_ & 0x06) == 0x06);
            if (sprite0_hit_dot_ < 0 && zero_opaque[xi] && bg_opaque[xi] && x < 255 && clip_ok &&
                (mask_ & 0x18) == 0x18 && (status_ & kSpriteZeroHit) == 0)
                sprite0_hit_dot_ = x + 2;
        }
    }
}

std::array<uint8_t, 256 * 240> Ppu2C02::render_background_frame() {
    std::array<uint8_t, 256 * 240> frame{};
    std::array<uint8_t, 256 * 240> background_opaque{};
    std::array<uint8_t, 256 * 240> sprite_color{};
    std::array<uint8_t, 256 * 240> sprite_priority{};
    std::array<uint8_t, 256 * 240> sprite_present{};
    auto read_vram = [this](uint16_t address) -> uint8_t { return read_memory(address); };
    // PPU mask bit 0 selects grayscale output: only the upper two palette bits
    // survive. Apply this at the final palette lookup, not to palette RAM itself.
    auto output_color = [this](uint16_t address) -> uint8_t {
        const uint8_t color = read_memory(address);
        return static_cast<uint8_t>(color & ((mask_ & 0x01) ? 0x30 : 0x3F));
    };

    const uint8_t universal_color = output_color(0x3F00);
    frame.fill(universal_color);
    status_ &= static_cast<uint8_t>(~(kSpriteZeroHit | kSpriteOverflow));

    // Background layer. This is a frame snapshot, not a cycle-accurate rasterizer.
    if (mask_ & 0x08) {
        // $2005 writes populate coarse/fine scroll fields in t; use that snapshot
        // to select tiles across both nametable axes. This remains frame-snapshot
        // rendering (not the hardware's per-dot loopy-v/t pipeline).
        const int base_nametable_x = (temp_addr_ >> 10) & 1;
        const int base_nametable_y = (temp_addr_ >> 11) & 1;
        const int scroll_x = ((temp_addr_ & 0x001F) * 8) + fine_x_;
        const int scroll_y = (((temp_addr_ >> 5) & 0x001F) * 8) + ((temp_addr_ >> 12) & 7);
        const uint16_t pattern_base = (ctrl_ & 0x10) ? 0x1000 : 0x0000;
        for (int y = 0; y < 240; ++y) {
            const int world_y = (y + scroll_y) % 480;
            const int local_y = world_y % 240;
            const int tile_y = local_y >> 3;
            const int fine_y = local_y & 7;
            const int nametable_y = (base_nametable_y + world_y / 240) & 1;
            for (int x = 0; x < 256; ++x) {
                if (x < 8 && (mask_ & 0x02) == 0) continue;
                const int world_x = (x + scroll_x) % 512;
                const int tile_x = (world_x % 256) >> 3;
                const int nametable_x = (base_nametable_x + world_x / 256) & 1;
                const uint16_t nametable_base = static_cast<uint16_t>(0x2000 + (nametable_y * 2 + nametable_x) * 0x400);
                const uint16_t tile_address = static_cast<uint16_t>(nametable_base + tile_y * 32 + tile_x);
                const uint8_t tile = read_vram(tile_address);
                const uint16_t pattern_address = static_cast<uint16_t>(pattern_base + tile * 16 + fine_y);
                const uint8_t plane0 = read_vram(pattern_address);
                const uint8_t plane1 = read_vram(static_cast<uint16_t>(pattern_address + 8));
                const int bit = 7 - (world_x & 7);
                const uint8_t pixel = static_cast<uint8_t>(((plane0 >> bit) & 1) | (((plane1 >> bit) & 1) << 1));
                if (pixel == 0) continue;

                const uint16_t attribute_address = static_cast<uint16_t>(nametable_base + 0x3C0 + (tile_y >> 2) * 8 + (tile_x >> 2));
                const uint8_t attribute = read_vram(attribute_address);
                const int shift = ((tile_y & 2) << 1) | (tile_x & 2);
                const uint8_t palette = static_cast<uint8_t>((attribute >> shift) & 0x03);
                const uint16_t palette_address = static_cast<uint16_t>(0x3F00 + palette * 4 + pixel);
                const size_t index = static_cast<size_t>(y) * 256 + static_cast<size_t>(x);
                frame[index] = output_color(palette_address);
                background_opaque[index] = 1;
            }
        }
    }

    // Sprite layer. Select the first opaque OAM entry at each pixel (lower OAM
    // index has priority), then composite it against the already-rendered background.
    if (mask_ & 0x10) {
        const int sprite_height = (ctrl_ & 0x20) ? 16 : 8;
        int sprites_on_scanline[240]{};
        for (int sprite = 0; sprite < 64; ++sprite) {
            const size_t oam = static_cast<size_t>(sprite) * 4;
            const int top = static_cast<int>(oam_[oam]) + 1;
            const uint8_t tile = oam_[oam + 1];
            const uint8_t attributes = oam_[oam + 2];
            const int left = oam_[oam + 3];
            if (top >= 240 || top + sprite_height <= 0) continue;
            const int y_start = top < 0 ? 0 : top;
            const int y_end = (top + sprite_height > 240) ? 240 : top + sprite_height;
            for (int y = y_start; y < y_end; ++y) {
                if (++sprites_on_scanline[y] > 8) status_ |= kSpriteOverflow;
                const int row_unflipped = y - top;
                const int row = (attributes & 0x80) ? sprite_height - 1 - row_unflipped : row_unflipped;
                uint16_t pattern_address;
                int pattern_row;
                if (sprite_height == 16) {
                    const uint16_t bank = (tile & 1) ? 0x1000 : 0x0000;
                    const uint8_t tile_number = static_cast<uint8_t>((tile & 0xFE) + (row >= 8 ? 1 : 0));
                    pattern_address = static_cast<uint16_t>(bank + tile_number * 16);
                    pattern_row = row & 7;
                } else {
                    pattern_address = static_cast<uint16_t>(((ctrl_ & 0x08) ? 0x1000 : 0x0000) + tile * 16);
                    pattern_row = row;
                }
                const uint8_t plane0 = read_vram(static_cast<uint16_t>(pattern_address + pattern_row));
                const uint8_t plane1 = read_vram(static_cast<uint16_t>(pattern_address + pattern_row + 8));
                for (int dx = 0; dx < 8; ++dx) {
                    const int x = left + dx;
                    if (x < 0 || x >= 256 || (x < 8 && (mask_ & 0x04) == 0)) continue;
                    const int source_x = (attributes & 0x40) ? 7 - dx : dx;
                    const int bit = 7 - source_x;
                    const uint8_t pixel = static_cast<uint8_t>(((plane0 >> bit) & 1) | (((plane1 >> bit) & 1) << 1));
                    if (pixel == 0) continue;
                    const size_t index = static_cast<size_t>(y) * 256 + static_cast<size_t>(x);
                    if (sprite_present[index]) continue; // A lower OAM index already owns this pixel.
                    sprite_present[index] = 1;
                    const uint8_t palette = attributes & 0x03;
                    sprite_color[index] = output_color(static_cast<uint16_t>(0x3F10 + palette * 4 + pixel));
                    sprite_priority[index] = (attributes & 0x20) ? 1 : 0;
                    if (sprite == 0 && background_opaque[index] && x < 255 && (mask_ & 0x08))
                        status_ |= kSpriteZeroHit;
                }
            }
        }
        for (size_t i = 0; i < frame.size(); ++i) {
            if (!sprite_present[i]) continue;
            if (sprite_priority[i] && background_opaque[i]) continue;
            frame[i] = sprite_color[i];
        }
    }
    return frame;
}

bool Ppu2C02::take_nmi_request() {
    const bool result = nmi_pending_;
    nmi_pending_ = false;
    return result;
}
} // namespace nes
