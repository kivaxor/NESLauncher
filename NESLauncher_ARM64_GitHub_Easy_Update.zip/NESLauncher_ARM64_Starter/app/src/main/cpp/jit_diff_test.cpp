// Differential test: random 6502 programs are run on the interpreter and on the
// recompiled AArch64 code (executed inside Unicorn); registers, flags, pc, cycles
// and memory must match exactly. Built only with -DNES_JIT_UNICORN_DIR=<unicorn build>.
#include "cpu6502.h"
#include "jit6502.h"
#include "jit_unicorn_backend.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <random>
#include <vector>

using namespace nes;
using namespace nes::jit;

namespace {

// Host used by the helper calls: a plain CpuBus without devices, recording nothing.
struct TestHost : JitHost {
    CpuBus* bus = nullptr;
    uint8_t jit_read(JitContext&, uint16_t a) override { return bus->read(a); }
    void jit_write(JitContext&, uint16_t a, uint8_t v) override { bus->write(a, v); }
};

struct Fixture {
    CpuBus bus;
    std::vector<uint8_t> prg = std::vector<uint8_t>(32768);
};

bool is_official(uint8_t opcode) { return Cpu6502::table()[opcode].op != Cpu6502::Op::Ill && Cpu6502::table()[opcode].op != Cpu6502::Op::BRK; }

int failures = 0;

void fail(const char* what, unsigned iteration, const std::vector<uint8_t>& program, uint32_t got, uint32_t want) {
    if (++failures > 20) return;
    std::printf("MISMATCH %s (iter %u): jit=%02X interp=%02X program:", what, iteration, got, want);
    for (size_t i = 0; i < program.size() && i < 12; ++i) std::printf(" %02X", program[i]);
    std::printf("\n");
}

} // namespace

int main(int argc, char** argv) {
    const unsigned iterations = argc > 1 ? static_cast<unsigned>(std::atoi(argv[1])) : 20000;
    std::mt19937 rng(12345);
    auto rnd = [&](unsigned n) { return static_cast<unsigned>(rng() % n); };

    // Opcodes the recompiler handles.
    std::vector<uint8_t> opcodes;
    for (int i = 0; i < 256; ++i) if (is_official(static_cast<uint8_t>(i))) opcodes.push_back(static_cast<uint8_t>(i));
    std::printf("official opcodes: %zu\n", opcodes.size());

    Fixture fx_i, fx_j;
    TestHost host;
    host.bus = &fx_j.bus;
    auto backend = std::make_unique<UnicornBackend>(fx_j.bus.ram.data());
    Jit6502 jit(std::move(backend), &host, [&](uint16_t a) { return fx_j.bus.read(a); });
    if (!jit.ok()) { std::printf("jit init failed\n"); return 1; }

    unsigned blocks_run = 0, instructions_total = 0;
    for (unsigned it = 0; it < iterations && failures == 0; ++it) {
        // Random program at $8000, mix of single opcodes and short sequences.
        const unsigned count = 1 + rnd(it % 3 == 0 ? 1 : 10);
        std::vector<uint8_t> program;
        for (unsigned n = 0; n < count; ++n) {
            program.push_back(opcodes[rnd(static_cast<unsigned>(opcodes.size()))]);
            program.push_back(static_cast<uint8_t>(rng()));
            program.push_back(static_cast<uint8_t>(rng()));
        }
        // Random PRG data (including the operand bytes), shared by both machines.
        for (auto& b : fx_i.prg) b = static_cast<uint8_t>(rng());
        std::memcpy(fx_i.prg.data(), program.data(), program.size());
        fx_j.prg = fx_i.prg;
        // Make ROM-resident operands more often land in RAM/ROM: keep random.
        fx_i.bus.reset(); fx_j.bus.reset();
        fx_i.bus.map_prg_rom(fx_i.prg.data(), 32768);
        fx_j.bus.map_prg_rom(fx_j.prg.data(), 32768);
        for (unsigned a = 0; a < 2048; ++a) { const uint8_t v = static_cast<uint8_t>(rng()); fx_i.bus.ram[a] = v; fx_j.bus.ram[a] = v; }
        for (uint16_t a = 0x2000; a < 0x8000; a += 97) { const uint8_t v = static_cast<uint8_t>(rng()); fx_i.bus.write(a, v); fx_j.bus.write(a, v); }
        jit.invalidate_all();

        const uint8_t ra = static_cast<uint8_t>(rng()), rx = static_cast<uint8_t>(rng()), ry = static_cast<uint8_t>(rng());
        const uint8_t rsp = static_cast<uint8_t>(rng()), rp = static_cast<uint8_t>(rng());
        Cpu6502 cpu(fx_i.bus);
        cpu.set_state(0x8000, ra, rx, ry, rsp, rp);

        JitContext ctx{};
        ctx.pc = 0x8000; ctx.a = ra; ctx.x = rx; ctx.y = ry; ctx.sp = rsp;
        ctx.p = static_cast<uint8_t>((rp | 0x20) & ~0x10);
        unsigned executed = 0;
        if (!jit.run_block(ctx, &executed)) { continue; } // first opcode not translatable
        ++blocks_run;
        instructions_total += executed;

        uint32_t cycles = 0;
        for (unsigned n = 0; n < executed; ++n) cycles += static_cast<uint32_t>(cpu.step());

        if (ctx.cycles != cycles) fail("cycles", it, program, ctx.cycles, cycles);
        if (ctx.pc != cpu.pc()) fail("pc", it, program, ctx.pc, cpu.pc());
        if (ctx.a != cpu.a()) fail("A", it, program, ctx.a, cpu.a());
        if (ctx.x != cpu.x()) fail("X", it, program, ctx.x, cpu.x());
        if (ctx.y != cpu.y()) fail("Y", it, program, ctx.y, cpu.y());
        if (ctx.sp != cpu.sp()) fail("SP", it, program, ctx.sp, cpu.sp());
        if (ctx.p != cpu.status()) fail("P", it, program, ctx.p, cpu.status());
        for (unsigned a = 0; a < 2048; ++a)
            if (fx_i.bus.ram[a] != fx_j.bus.ram[a]) { fail("RAM", it, program, fx_j.bus.ram[a], fx_i.bus.ram[a]); break; }
        for (uint32_t a = 0x2000; a < 0x8000; ++a)
            if (fx_i.bus.read(static_cast<uint16_t>(a)) != fx_j.bus.read(static_cast<uint16_t>(a))) { fail("MEM", it, program, a, a); break; }
    }
    std::printf("blocks run: %u, instructions: %u, failures: %d\n", blocks_run, instructions_total, failures);
    if (failures) return 1;
    std::cout << "JIT differential tests passed\n";
    return 0;
}
