#include "nes_engine.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
    // Minimal iNES image: 1 x 16 KiB PRG, 1 x 8 KiB CHR.
    std::vector<uint8_t> rom(16 + 16384 + 8192, 0);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = 1; rom[5] = 1;
    auto info = nes::inspect_rom(rom.data(), rom.size());
    assert(info.valid);
    assert(info.mapper == 0);
    assert(info.prg_rom_bytes == 16384);
    assert(info.chr_rom_bytes == 8192);

    // Truncated ROM is rejected.
    auto truncated = nes::inspect_rom(rom.data(), 100);
    assert(!truncated.valid);

    // Bad magic is rejected.
    rom[0] = 'X';
    auto bad = nes::inspect_rom(rom.data(), rom.size());
    assert(!bad.valid);

    // Trainer flag moves the PRG payload offset by 512 bytes.
    rom[0] = 'N'; rom[6] = 0x04;
    rom.insert(rom.begin() + 16, 512, 0);
    auto trainer = nes::inspect_rom(rom.data(), rom.size());
    assert(trainer.valid);
    assert(trainer.trainer);
    assert(trainer.payload_offset == 528);

    std::cout << "ROM parser tests passed\n";
    return 0;
}
