#include "nes_machine.h"

#include "jit_native_backend.h"

#include <algorithm>

namespace nes {
NesMachine::NesMachine(uint32_t sample_rate) : apu_(sample_rate), cpu_(bus_) {
    // DMC sample fetches read PRG ROM through the CPU bus ($8000-$FFFF has no read side effects).
    apu_.set_dmc_reader([this](uint16_t address) { return bus_.read(address); });
}
NesMachine::~NesMachine() = default;

bool NesMachine::use_jit_backend(std::unique_ptr<jit::JitBackend> backend) {
    jit_.reset();
    if (!backend) return false;
    auto jit = std::make_unique<jit::Jit6502>(std::move(backend), this,
                                              [this](uint16_t address) { return bus_.read(address); });
    if (!jit->ok()) return false;
    jit_ = std::move(jit);
    jit_sig_ = cartridge_.prg_signature();
    jit_->select_mapping(jit_sig_);
    return true;
}

bool NesMachine::set_recompiler_enabled(bool enabled) {
    if (!enabled) { jit_.reset(); return false; }
    return use_jit_backend(jit::make_native_backend(bus_.ram.data()));
}

bool NesMachine::load_rom(const uint8_t* data, size_t size, std::string* error) {
    // Cartridge parsing is transactional. On failure, preserve the current
    // machine, including CPU/PPU state and battery-backed RAM.
    if (!cartridge_.load_ines(data, size, error)) return false;
    bus_.reset();
    ppu_.reset();
    apu_.reset();
    bus_.attach_apu(&apu_);
    bus_.attach_cartridge(&cartridge_);
    bus_.attach_ppu(&ppu_);
    ppu_.attach_cartridge(&cartridge_);
    cpu_.reset();
    cpu_cycle_count_ = 0;
    jit_synced_ = 0;
    jit_event_ = false;
    irq_line_ = false;
    jit_sig_ = cartridge_.prg_signature();
    if (jit_) { jit_->select_mapping(jit_sig_); jit_->invalidate_all(); }
    return true;
}

// Translated blocks embed bytes of the currently mapped PRG ROM, so every PRG mapping has its own block
// cache; switching is cheap and earlier mappings stay translated (no recompiling on every bank switch).
// Applies no matter whether the write came from a block or from the interpreter.
void NesMachine::jit_check_mapping() {
    const uint32_t signature = cartridge_.prg_signature();
    if (signature != jit_sig_) {
        jit_sig_ = signature;
        jit_->select_mapping(signature);
    }
}

void NesMachine::advance(uint32_t cpu_cycles) {
    cpu_cycle_count_ += cpu_cycles;
    ppu_.clock_cpu_cycles(cpu_cycles);
    apu_.clock_cpu_cycles(cpu_cycles);
    if (ppu_.take_nmi_request()) { cpu_.request_nmi(); jit_event_ = true; }
    const bool irq = apu_.frame_irq() || cartridge_.irq_pending();
    if (irq) {
        cpu_.request_irq();
        if (!irq_line_) jit_event_ = true;
    } else {
        cpu_.clear_irq();
    }
    irq_line_ = irq;
}

// ---- recompiler glue ------------------------------------------------------------------
void NesMachine::jit_sync(uint32_t block_cycles) {
    if (block_cycles > jit_synced_) {
        advance(block_cycles - jit_synced_);
        jit_synced_ = block_cycles;
    }
}

// Lower bound, in CPU cycles, until time alone can raise an NMI or IRQ edge. The recompiler only
// runs blocks that cannot reach it, so interrupts are taken at exactly the same instruction
// boundary as in the interpreter.
uint32_t NesMachine::event_horizon() const {
    constexpr uint32_t kDotsPerLine = 341, kLines = 262, kFrameDots = kDotsPerLine * kLines;
    auto cycles_before = [](uint32_t dots) { return dots / 3 > 0 ? dots / 3 - 1 : 0; };
    const uint32_t now = static_cast<uint32_t>(ppu_.scanline()) * kDotsPerLine + ppu_.dot();
    // Vblank starts at scanline 241, dot 1 (raises NMI when enabled).
    uint32_t h = cycles_before((241U * kDotsPerLine + 1U + kFrameDots - now) % kFrameDots);
    // The frame boundary too, so run_frame() stops at the same instruction in both modes.
    h = std::min(h, cycles_before((kFrameDots - now) % kFrameDots));
    if (apu_.frame_irq_armed()) {
        const uint32_t n = apu_.cycles_until_frame_irq();
        h = std::min(h, n > 0 ? n - 1 : 0);
    }
    if (cartridge_.irq_armed()) {
        // MMC3 scanline counter is clocked at dot 260 of each line.
        h = std::min(h, cycles_before((260U + kDotsPerLine - ppu_.dot()) % kDotsPerLine));
    }
    return h;
}

unsigned NesMachine::irq_armed_state() const {
    return (apu_.frame_irq_armed() ? 1U : 0U) | (cartridge_.irq_armed() ? 2U : 0U);
}

uint8_t NesMachine::jit_read(jit::JitContext& ctx, uint16_t address) {
    // Only PPU/APU/controller registers observe time; ROM, RAM and PRG RAM do not.
    if (address >= 0x2000 && address < 0x4020) jit_sync(ctx.cycles);
    const uint8_t value = bus_.read(address);
    if (jit_event_) ctx.stop = 1;
    return value;
}

void NesMachine::jit_write(jit::JitContext& ctx, uint16_t address, uint8_t value) {
    jit_sync(ctx.cycles);
    const unsigned armed = irq_armed_state();
    bus_.write(address, value);
    // An NMI queued by this write is only consumed after the instruction's cycles have been clocked
    // (as in the interpreter path, where vblank may end first); just leave the block here.
    if (ppu_.nmi_request_pending()) jit_event_ = true;
    if (irq_armed_state() != armed) jit_event_ = true;                       // IRQ source (dis)armed
    if (cartridge_.prg_signature() != jit_sig_) {
        // PRG banking changed: translated blocks are stale. The flush happens before the next block.
        jit_check_mapping();
        ctx.stop = 1;
    }
    if (bus_.dma_pending() || jit_event_) ctx.stop = 1;
}

bool NesMachine::run_jit_block() {
    if (cpu_.interrupt_pending()) return false; // let the interpreter take the interrupt
    const uint16_t pc = cpu_.pc();
    if (pc < 0x8000) return false;              // RAM/PRG RAM code may self-modify: interpret
    jit::JitContext ctx{};
    ctx.pc = pc; ctx.a = cpu_.a(); ctx.x = cpu_.x(); ctx.y = cpu_.y(); ctx.sp = cpu_.sp(); ctx.p = cpu_.status();
    jit_synced_ = 0;
    jit_event_ = false;
    if (trace_) trace_(pc, cpu_cycle_count_);
    if (!jit_->run_block(ctx, nullptr, event_horizon())) return false;
    cpu_.set_state(static_cast<uint16_t>(ctx.pc), static_cast<uint8_t>(ctx.a), static_cast<uint8_t>(ctx.x),
                   static_cast<uint8_t>(ctx.y), static_cast<uint8_t>(ctx.sp), static_cast<uint8_t>(ctx.p));
    const uint32_t remaining = ctx.cycles - jit_synced_;
    // STA $4014 ends its block, so parity is that of the block's last cycle (as in the interpreter path).
    const bool dma_start_odd = ((cpu_cycle_count_ + remaining - 1U) & 1U) != 0;
    const uint32_t dma_cycles = bus_.take_dma_stall_cycles(dma_start_odd);
    jit_synced_ = 0;
    advance(remaining + dma_cycles);
    ++jit_blocks_run_;
    return true;
}

bool NesMachine::run_frame(std::array<uint8_t, 256 * 240>& pixels, std::string* error) {
    if (!loaded()) {
        if (error) *error = "Belum ada ROM yang dimuat.";
        return false;
    }
    const uint64_t starting_frame = ppu_.frame_count();
    // A guard protects the UI from malformed ROMs that fail to make useful progress.
    // One NTSC frame is about 29,781 CPU cycles; allow a generous 2x budget.
    constexpr uint32_t kMaxInstructionsPerFrame = 100000;
    uint32_t instructions = 0;
    while (ppu_.frame_count() == starting_frame && instructions < kMaxInstructionsPerFrame) {
        ++instructions;
        if (jit_ && run_jit_block()) continue;
        if (trace_) trace_(cpu_.pc(), cpu_cycle_count_);
        const int instruction_cycles = cpu_.step();
        ++interpreted_steps_;
        if (jit_) jit_check_mapping();
        // STA $4014 writes on the final cycle of its store instruction. Infer
        // that cycle's parity from cumulative cycles; bus-level exactness awaits
        // a cycle-stepped CPU implementation.
        const bool dma_start_odd = ((cpu_cycle_count_ + static_cast<uint64_t>(instruction_cycles) - 1U) & 1U) != 0;
        const uint32_t dma_cycles = bus_.take_dma_stall_cycles(dma_start_odd);
        advance(static_cast<uint32_t>(instruction_cycles) + dma_cycles);
    }
    if (ppu_.frame_count() == starting_frame) {
        if (error) *error = "CPU tidak mencapai frame berikutnya dalam batas instruksi; ROM mungkin tidak kompatibel.";
        return false;
    }
    pixels = ppu_.completed_frame();
    if (error) error->clear();
    return true;
}
} // namespace nes
