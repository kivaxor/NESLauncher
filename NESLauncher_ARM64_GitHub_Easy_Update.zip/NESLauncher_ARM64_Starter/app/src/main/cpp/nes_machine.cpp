#include "nes_machine.h"

namespace nes {
NesMachine::NesMachine(uint32_t sample_rate) : apu_(sample_rate), cpu_(bus_) {
    // DMC sample fetches read PRG ROM through the CPU bus ($8000-$FFFF has no read side effects).
    apu_.set_dmc_reader([this](uint16_t address) { return bus_.read(address); });
}
NesMachine::~NesMachine() = default;

bool NesMachine::load_rom(const uint8_t* data, size_t size, std::string* error) {
    // Cartridge parsing is transactional. On failure, preserve the current
    // machine, including CPU/PPU state and battery-backed RAM.
    if (!cartridge_.load_ines(data, size, error)) return false;
    bus_.reset();
    ppu_.reset();
    apu_.reset();
    bus_.attach_apu(&apu_);
    bus_.attach_cartridge(&cartridge_);
    bus_.attach_ppu(&ppu_);
    ppu_.attach_cartridge(&cartridge_);
    cpu_.reset();
    cpu_cycle_count_ = 0;
    return true;
}

void NesMachine::advance(uint32_t cpu_cycles) {
    cpu_cycle_count_ += cpu_cycles;
    ppu_.clock_cpu_cycles(cpu_cycles);
    apu_.clock_cpu_cycles(cpu_cycles);
    if (ppu_.take_nmi_request()) cpu_.request_nmi();
    if (apu_.frame_irq() || cartridge_.irq_pending()) cpu_.request_irq();
    else cpu_.clear_irq();
}

bool NesMachine::run_frame(std::array<uint8_t, 256 * 240>& pixels, std::string* error) {
    if (!loaded()) {
        if (error) *error = "Belum ada ROM yang dimuat.";
        return false;
    }
    const uint64_t starting_frame = ppu_.frame_count();
    // A guard protects the UI from malformed ROMs that fail to make useful progress.
    // One NTSC frame is about 29,781 CPU cycles; allow a generous 2x budget.
    constexpr uint32_t kMaxInstructionsPerFrame = 100000;
    uint32_t instructions = 0;
    while (ppu_.frame_count() == starting_frame && instructions < kMaxInstructionsPerFrame) {
        ++instructions;
        const int instruction_cycles = cpu_.step();
        // STA $4014 writes on the final cycle of its store instruction. Infer
        // that cycle's parity from cumulative cycles; bus-level exactness awaits
        // a cycle-stepped CPU implementation.
        const bool dma_start_odd = ((cpu_cycle_count_ + static_cast<uint64_t>(instruction_cycles) - 1U) & 1U) != 0;
        const uint32_t dma_cycles = bus_.take_dma_stall_cycles(dma_start_odd);
        advance(static_cast<uint32_t>(instruction_cycles) + dma_cycles);
    }
    if (ppu_.frame_count() == starting_frame) {
        if (error) *error = "CPU tidak mencapai frame berikutnya dalam batas instruksi; ROM mungkin tidak kompatibel.";
        return false;
    }
    pixels = ppu_.completed_frame();
    if (error) error->clear();
    return true;
}
} // namespace nes
