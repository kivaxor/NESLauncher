#include "nes_machine.h"

#include <cstring>

namespace nes {
NesMachine::NesMachine(uint32_t sample_rate) : apu_(sample_rate), cpu_(bus_) {
    // DMC sample fetches read PRG ROM through the CPU bus ($8000-$FFFF has no read side effects).
    apu_.set_dmc_reader([this](uint16_t address) { return bus_.read(address); });
}
NesMachine::~NesMachine() = default;

bool NesMachine::load_rom(const uint8_t* data, size_t size, std::string* error) {
    // Cartridge parsing is transactional. On failure, preserve the current
    // machine, including CPU/PPU state and battery-backed RAM.
    if (!cartridge_.load_ines(data, size, error)) return false;
    bus_.reset();
    ppu_.reset();
    apu_.reset();
    bus_.attach_apu(&apu_);
    bus_.attach_cartridge(&cartridge_);
    bus_.attach_ppu(&ppu_);
    ppu_.attach_cartridge(&cartridge_);
    cpu_.reset();
    cpu_cycle_count_ = 0;
    return true;
}

void NesMachine::reset() {
    if (!loaded()) return;
    cartridge_.reset_mapper();   // before the CPU reads the reset vector
    bus_.reset();
    ppu_.reset();
    apu_.reset();
    cpu_.reset();
    cpu_cycle_count_ = 0;
}

namespace {
constexpr uint8_t kStateMagic[4] = {'N', 'E', 'S', 'S'};
constexpr uint32_t kStateVersion = 1;
}

std::vector<uint8_t> NesMachine::save_state() const {
    std::vector<uint8_t> out;
    out.reserve(160 * 1024);
    StateWriter w(out);
    w.bytes(kStateMagic, sizeof(kStateMagic));
    w.pod(kStateVersion);
    w.pod(cartridge_.content_hash());
    w.pod(cpu_cycle_count_);
    cpu_.save_state(w);
    bus_.save_state(w);
    ppu_.save_state(w);
    apu_.save_state(w);
    cartridge_.save_state(w);
    return out;
}

bool NesMachine::apply_state(const uint8_t* data, size_t size, std::string* error) {
    StateReader r(data, size);
    uint8_t magic[4] = {};
    uint32_t version = 0;
    uint64_t key = 0;
    r.bytes(magic, sizeof(magic));
    r.pod(version);
    r.pod(key);
    if (!r.ok() || std::memcmp(magic, kStateMagic, sizeof(magic)) != 0) {
        if (error) *error = "Berkas state tidak valid.";
        return false;
    }
    if (version != kStateVersion) {
        if (error) *error = "Versi state tidak cocok dengan aplikasi ini.";
        return false;
    }
    if (key != cartridge_.content_hash()) {
        if (error) *error = "State ini milik ROM lain.";
        return false;
    }
    r.pod(cpu_cycle_count_);
    const bool ok = cpu_.load_state(r) && bus_.load_state(r) && ppu_.load_state(r) &&
                    apu_.load_state(r) && cartridge_.load_state(r) && r.ok() && r.remaining() == 0;
    if (!ok && error) *error = "Isi state rusak atau terpotong.";
    return ok;
}

bool NesMachine::load_state(const uint8_t* data, size_t size, std::string* error) {
    if (!loaded()) {
        if (error) *error = "Belum ada ROM yang dimuat.";
        return false;
    }
    // Keep a snapshot of the current machine: a state that fails halfway must not leave a mix behind.
    const std::vector<uint8_t> backup = save_state();
    if (data == nullptr || size != backup.size()) {
        if (error) *error = "Ukuran state tidak cocok (state dari versi lain atau rusak).";
        return false;
    }
    if (apply_state(data, size, error)) {
        if (error) error->clear();
        return true;
    }
    apply_state(backup.data(), backup.size(), nullptr);
    return false;
}

void NesMachine::advance(uint32_t cpu_cycles) {
    cpu_cycle_count_ += cpu_cycles;
    ppu_.clock_cpu_cycles(cpu_cycles);
    apu_.clock_cpu_cycles(cpu_cycles);
    if (ppu_.take_nmi_request()) cpu_.request_nmi();
    if (apu_.frame_irq() || cartridge_.irq_pending()) cpu_.request_irq();
    else cpu_.clear_irq();
}

bool NesMachine::run_frame(std::array<uint8_t, 256 * 240>& pixels, std::string* error) {
    if (!loaded()) {
        if (error) *error = "Belum ada ROM yang dimuat.";
        return false;
    }
    const uint64_t starting_frame = ppu_.frame_count();
    // A guard protects the UI from malformed ROMs that fail to make useful progress.
    // One NTSC frame is about 29,781 CPU cycles; allow a generous 2x budget.
    constexpr uint32_t kMaxInstructionsPerFrame = 100000;
    uint32_t instructions = 0;
    while (ppu_.frame_count() == starting_frame && instructions < kMaxInstructionsPerFrame) {
        ++instructions;
        const int instruction_cycles = cpu_.step();
        // STA $4014 writes on the final cycle of its store instruction. Infer
        // that cycle's parity from cumulative cycles; bus-level exactness awaits
        // a cycle-stepped CPU implementation.
        const bool dma_start_odd = ((cpu_cycle_count_ + static_cast<uint64_t>(instruction_cycles) - 1U) & 1U) != 0;
        const uint32_t dma_cycles = bus_.take_dma_stall_cycles(dma_start_odd);
        advance(static_cast<uint32_t>(instruction_cycles) + dma_cycles);
    }
    if (ppu_.frame_count() == starting_frame) {
        if (error) *error = "CPU tidak mencapai frame berikutnya dalam batas instruksi; ROM mungkin tidak kompatibel.";
        return false;
    }
    pixels = ppu_.completed_frame();
    if (error) error->clear();
    return true;
}
} // namespace nes
