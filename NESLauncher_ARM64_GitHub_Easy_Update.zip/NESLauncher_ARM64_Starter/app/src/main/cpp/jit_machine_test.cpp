// Whole-machine parity: the same ROM runs with the interpreter and with the recompiler
// (generated ARM64 code executed in Unicorn). Frames, audio and RAM must be identical.
#include "jit_unicorn_backend.h"
#include "nes_machine.h"

#include <cstdio>
#include <cstring>
#include <map>
#include <memory>
#include <string>
#include <vector>

using namespace nes;

namespace {

// Tiny two-pass assembler so the test program stays readable.
struct Assembler {
    std::vector<uint8_t> code;
    std::map<std::string, uint16_t> labels;
    struct Fix { size_t at; std::string label; bool rel; };
    std::vector<Fix> fixes;
    uint16_t base;
    explicit Assembler(uint16_t b) : base(b) {}
    void label(const std::string& n) { labels[n] = static_cast<uint16_t>(base + code.size()); }
    void b(std::initializer_list<uint8_t> bytes) { code.insert(code.end(), bytes); }
    void imm(uint8_t op, uint8_t v) { b({op, v}); }
    void abs(uint8_t op, uint16_t a) { b({op, static_cast<uint8_t>(a), static_cast<uint8_t>(a >> 8)}); }
    void abs_label(uint8_t op, const std::string& l) { code.push_back(op); fixes.push_back({code.size(), l, false}); b({0, 0}); }
    void branch(uint8_t op, const std::string& l) { code.push_back(op); fixes.push_back({code.size(), l, true}); code.push_back(0); }
    void resolve() {
        for (const Fix& f : fixes) {
            const uint16_t target = labels.at(f.label);
            if (f.rel) {
                const int delta = static_cast<int>(target) - static_cast<int>(base + f.at + 1);
                code[f.at] = static_cast<uint8_t>(delta);
            } else {
                code[f.at] = static_cast<uint8_t>(target);
                code[f.at + 1] = static_cast<uint8_t>(target >> 8);
            }
        }
    }
};

std::vector<uint8_t> build_rom() {
    Assembler a(0x8000);
    a.b({0x78, 0xD8}); a.imm(0xA2, 0xFF); a.b({0x9A});             // SEI CLD LDX #$FF TXS
    a.label("w1"); a.abs(0x2C, 0x2002); a.branch(0x10, "w1");       // BIT $2002 BPL
    a.imm(0xA9, 0); a.b({0xAA});                                      // LDA #0 TAX
    a.label("clr"); a.abs(0x9D, 0x0000); a.abs(0x9D, 0x0200); a.b({0xE8}); a.branch(0xD0, "clr");
    a.label("w2"); a.abs(0x2C, 0x2002); a.branch(0x10, "w2");
    a.imm(0xA9, 0x3F); a.abs(0x8D, 0x2006); a.imm(0xA9, 0); a.abs(0x8D, 0x2006);
    a.imm(0xA2, 0);
    a.label("pal"); a.abs_label(0xBD, "palette"); a.abs(0x8D, 0x2007); a.b({0xE8}); a.imm(0xE0, 32); a.branch(0xD0, "pal");
    a.imm(0xA9, 0x00); a.abs(0x8D, 0x2006); a.imm(0xA9, 0x10); a.abs(0x8D, 0x2006); a.imm(0xA2, 0);
    a.label("pat"); a.abs_label(0xBD, "pattern"); a.abs(0x8D, 0x2007); a.b({0xE8}); a.imm(0xE0, 16); a.branch(0xD0, "pat");
    a.imm(0xA9, 0x20); a.abs(0x8D, 0x2006); a.imm(0xA9, 0); a.abs(0x8D, 0x2006); a.imm(0xA0, 4); a.imm(0xA2, 0);
    a.label("nt"); a.b({0x8A}); a.imm(0x29, 0x01); a.abs(0x8D, 0x2007); a.b({0xE8}); a.branch(0xD0, "nt"); a.b({0x88}); a.branch(0xD0, "nt");
    a.imm(0xA9, 0x40); a.abs(0x8D, 0x0200); a.imm(0xA9, 1); a.abs(0x8D, 0x0201); a.imm(0xA9, 0); a.abs(0x8D, 0x0202); a.imm(0xA9, 0x40); a.abs(0x8D, 0x0203);
    a.imm(0xA9, 0); a.abs(0x8D, 0x2005); a.abs(0x8D, 0x2005);
    a.imm(0xA9, 0x80); a.abs(0x8D, 0x2000); a.imm(0xA9, 0x1E); a.abs(0x8D, 0x2001);
    a.label("main"); a.abs_label(0x4C, "main");
    a.label("nmi");
    a.b({0x48, 0x8A, 0x48});                                          // PHA TXA PHA
    a.abs(0xEE, 0x0011);                                              // INC $11
    a.imm(0xA9, 0x02); a.abs(0x8D, 0x4014);                           // OAM DMA
    a.abs(0xAD, 0x0203); a.b({0x18}); a.imm(0x69, 1); a.abs(0x8D, 0x0203);
    a.imm(0xA9, 1); a.abs(0x8D, 0x4016); a.imm(0xA9, 0); a.abs(0x8D, 0x4016); a.imm(0xA2, 8);
    a.label("rd"); a.abs(0xAD, 0x4016); a.b({0x4A}); a.b({0x26, 0x12}); a.b({0xCA}); a.branch(0xD0, "rd");
    a.b({0xA5, 0x11}); a.abs(0x8D, 0x2005); a.imm(0xA9, 0); a.abs(0x8D, 0x2005);
    a.imm(0xA9, 1); a.abs(0x8D, 0x4015); a.imm(0xA9, 0x9F); a.abs(0x8D, 0x4000);
    a.b({0xA5, 0x11}); a.abs(0x8D, 0x4002); a.imm(0xA9, 0x08); a.abs(0x8D, 0x4003);
    a.b({0xA5, 0x11}); a.b({0x38}); a.imm(0xE9, 3); a.b({0x85, 0x13});   // LDA $11 SEC SBC #3 STA $13
    a.b({0xA6, 0x11}); a.abs(0xBD, 0x0200); a.b({0x95, 0x20});            // LDX $11 / LDA $0200,X / STA $20,X
    a.b({0x68, 0xAA, 0x68, 0x40});                                         // PLA TAX PLA RTI
    a.label("irq"); a.b({0x40});
    a.label("palette");
    for (int i = 0; i < 32; ++i) a.code.push_back(static_cast<uint8_t>((i * 7 + 3) & 0x3F));
    a.label("pattern");
    const uint8_t pat[16] = {0xFF,0x81,0xBD,0xA5,0xA5,0xBD,0x81,0xFF, 0x0F,0x0F,0x0F,0x0F,0xF0,0xF0,0xF0,0xF0};
    for (uint8_t v : pat) a.code.push_back(v);
    a.resolve();

    std::vector<uint8_t> rom(16 + 32768, 0xEA);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A; rom[4] = 2; rom[5] = 0; rom[6] = 0; rom[7] = 0;
    std::memcpy(&rom[16], a.code.data(), a.code.size());
    auto vec = [&](unsigned off, uint16_t v) { rom[16 + off] = static_cast<uint8_t>(v); rom[16 + off + 1] = static_cast<uint8_t>(v >> 8); };
    vec(0x7FFA, a.labels["nmi"]);
    vec(0x7FFC, 0x8000);
    vec(0x7FFE, a.labels["irq"]);
    return rom;
}

} // namespace

int main(int argc, char** argv) {
    const int frames = argc > 1 ? std::atoi(argv[1]) : 40;
    const auto rom = build_rom();
    NesMachine interp, jitted;
    std::string error;
    if (!interp.load_rom(rom.data(), rom.size(), &error) || !jitted.load_rom(rom.data(), rom.size(), &error)) {
        std::printf("load failed: %s\n", error.c_str()); return 1;
    }
    if (!jitted.use_jit_backend(std::make_unique<jit::UnicornBackend>(jitted.cpu_ram_data()))) {
        std::printf("jit init failed\n"); return 1;
    }
    interp.set_controller_state(0, 0xA5);
    jitted.set_controller_state(0, 0xA5);

    std::array<uint8_t, 256 * 240> fa{}, fb{};
    int bad = 0;
    for (int f = 0; f < frames && bad == 0; ++f) {
        if (!interp.run_frame(fa, &error) || !jitted.run_frame(fb, &error)) { std::printf("run_frame failed: %s\n", error.c_str()); return 1; }
        if (fa != fb) { std::printf("frame %d: framebuffers differ\n", f); ++bad; }
        std::vector<int16_t> sa, sb;
        interp.take_audio(sa); jitted.take_audio(sb);
        const size_t n = std::min(sa.size(), sb.size());
        if (sa.size() != sb.size() && (sa.size() > sb.size() ? sa.size() - sb.size() : sb.size() - sa.size()) > 2) {
            std::printf("frame %d: audio length %zu vs %zu\n", f, sa.size(), sb.size()); ++bad;
        }
        for (size_t i = 0; i < n && bad == 0; ++i)
            if (sa[i] != sb[i]) { std::printf("frame %d: audio sample %zu differs (%d vs %d)\n", f, i, sa[i], sb[i]); ++bad; }
        for (uint16_t addr : {0x11, 0x12, 0x13}) {
            if (interp.cpu_peek_ram(addr) != jitted.cpu_peek_ram(addr)) {
                std::printf("frame %d: RAM[%02X] %02X vs %02X\n", f, addr, interp.cpu_peek_ram(addr), jitted.cpu_peek_ram(addr)); ++bad;
            }
        }
    }
    std::printf("frames: %d  jit blocks: %llu  interpreted steps: %llu  cpu cycles: %llu vs %llu\n", frames,
                static_cast<unsigned long long>(jitted.recompiled_blocks_run()),
                static_cast<unsigned long long>(jitted.interpreted_steps()),
                static_cast<unsigned long long>(interp.cpu_cycle_count()), static_cast<unsigned long long>(jitted.cpu_cycle_count()));
    {
        std::map<int, int> colors;
        for (uint8_t px : fb) ++colors[px];
        std::printf("distinct colors: %zu  nmi counter: %u  controller byte: %02X\n", colors.size(),
                    jitted.cpu_peek_ram(0x11), jitted.cpu_peek_ram(0x12));
        if (colors.size() < 3 || jitted.cpu_peek_ram(0x11) + 12 < frames) { std::printf("test program did not run as intended\n"); return 1; }
    }
    if (bad) return 1;
    std::printf("JIT machine parity test passed\n");
    return 0;
}
