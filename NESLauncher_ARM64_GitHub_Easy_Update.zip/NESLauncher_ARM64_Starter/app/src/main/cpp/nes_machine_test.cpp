#include "nes_machine.h"

#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

int main() {
    nes::NesMachine machine;
    std::string error;
    std::array<uint8_t, 256 * 240> frame{};
    assert(!machine.run_frame(frame, &error));
    assert(!error.empty());

    // Minimal iNES NROM-128: JMP $8000 loop and reset vector at $FFFC.
    std::vector<uint8_t> rom(16 + 16384, 0xEA);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = 1; rom[5] = 0; rom[6] = 0; rom[7] = 0;
    rom[16] = 0x4C; rom[17] = 0x00; rom[18] = 0x80;
    rom[16 + 0x3FFC] = 0x00;
    rom[16 + 0x3FFD] = 0x80;
    assert(machine.load_rom(rom.data(), rom.size(), &error));
    assert(error.empty());
    assert(machine.program_counter() == 0x8000);
    assert(machine.cpu_cycle_count() == 0);
    assert(machine.run_frame(frame, &error));
    assert(error.empty());
    assert(machine.frame_count() >= 1);
    assert(machine.cpu_cycle_count() > 0);
    assert(machine.program_counter() >= 0x8000);
    assert(frame.size() == 256U * 240U);

    // Loading the same ROM resets PPU timing and controller state.
    assert(machine.load_rom(rom.data(), rom.size(), &error));
    assert(machine.frame_count() == 0);
    assert(machine.cpu_cycle_count() == 0);
    assert(machine.program_counter() == 0x8000);
    assert(machine.run_frame(frame, &error));
    assert(machine.frame_count() >= 1);

    // A failed replacement must preserve the currently running machine.
    const uint64_t frames_before_failed_load = machine.frame_count();
    std::vector<uint8_t> invalid(16, 0);
    assert(!machine.load_rom(invalid.data(), invalid.size(), &error));
    assert(!error.empty());
    assert(machine.loaded());
    assert(machine.frame_count() == frames_before_failed_load);
    assert(machine.run_frame(frame, &error));
    assert(error.empty());
    assert(machine.frame_count() > frames_before_failed_load);
    std::cout << "NES machine integration tests passed\n";
}
