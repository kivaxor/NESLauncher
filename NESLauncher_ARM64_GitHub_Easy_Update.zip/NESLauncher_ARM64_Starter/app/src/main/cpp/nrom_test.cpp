#include "cartridge.h"
#include "cpu6502.h"

#include <cassert>
#include <cstdint>
#include <iostream>
#include <algorithm>
#include <string>
#include <vector>

static std::vector<uint8_t> make_nrom(size_t prg_size, size_t chr_size, uint8_t flags6 = 0) {
    std::vector<uint8_t> rom(16 + prg_size + chr_size, 0);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = static_cast<uint8_t>(prg_size / 16384);
    rom[5] = static_cast<uint8_t>(chr_size / 8192);
    rom[6] = flags6;
    for (size_t i = 0; i < prg_size; ++i) rom[16 + i] = static_cast<uint8_t>((i / 0x4000) + 0x40);
    rom[16] = 0xEA; // NOP at reset entry
    if (prg_size >= 6) {
        const size_t vector = 16 + prg_size - 6;
        rom[vector] = 0x00; rom[vector + 1] = 0x80; // NMI
        rom[vector + 2] = 0x00; rom[vector + 3] = 0x80; // RESET
        rom[vector + 4] = 0x00; rom[vector + 5] = 0x80; // IRQ/BRK
    }
    for (size_t i = 0; i < chr_size; ++i) rom[16 + prg_size + i] = static_cast<uint8_t>(i & 0xFF);
    return rom;
}

int main() {
    std::string error;
    nes::NromCartridge cart;
    auto rom16 = make_nrom(16384, 8192, 0x01); // vertical mirroring
    assert(cart.load_ines(rom16.data(), rom16.size(), &error));
    assert(cart.loaded() && cart.mapper() == 0 && !cart.chr_is_ram());
    assert(cart.mirroring() == nes::NametableMirroring::Vertical);
    uint8_t value = 0;
    assert(cart.cpu_read(0x8000, value) && value == 0xEA);
    assert(cart.cpu_read(0xC000, value) && value == 0xEA); // 16 KiB mirror
    assert(cart.cpu_read(0xFFFC, value) && value == 0x00);
    assert(cart.cpu_read(0xFFFD, value) && value == 0x80);
    assert(cart.ppu_read(0x0012, value) && value == 0x12);
    assert(!cart.ppu_write(0x0012, 0xAA)); // CHR ROM is read-only
    assert(cart.ppu_read(0x0012, value) && value == 0x12);

    // Verify the CPU sees the cartridge's reset vector and executable PRG ROM.
    nes::CpuBus bus;
    bus.attach_cartridge(&cart);
    nes::Cpu6502 cpu(bus);
    cpu.reset();
    assert(cpu.pc() == 0x8000);
    assert(cpu.step() == 2 && cpu.pc() == 0x8001); // NOP fetched through cartridge bus

    // 32 KiB PRG is not mirrored; CHR RAM is writable.
    auto rom32 = make_nrom(32768, 0);
    assert(cart.load_ines(rom32.data(), rom32.size(), &error));
    assert(cart.chr_is_ram());
    assert(cart.cpu_read(0x8000, value) && value == 0xEA);
    assert(cart.cpu_read(0xC000, value) && value == 0x41);
    assert(cart.ppu_write(0x1FFF, 0xAB));
    assert(cart.ppu_read(0x1FFF, value) && value == 0xAB);
    assert(cart.cpu_write(0x6001, 0x5A));
    assert(cart.cpu_read(0x6001, value) && value == 0x5A);

    // Trainer data is mapped into CPU RAM at $7000-$71FF.
    std::vector<uint8_t> trainer_rom(16 + 512 + 16384 + 8192, 0);
    trainer_rom[0] = 'N'; trainer_rom[1] = 'E'; trainer_rom[2] = 'S'; trainer_rom[3] = 0x1A;
    trainer_rom[4] = 1; trainer_rom[5] = 1; trainer_rom[6] = 0x04;
    std::fill(trainer_rom.begin() + 16, trainer_rom.begin() + 16 + 512, 0x77);
    std::fill(trainer_rom.begin() + 16 + 512, trainer_rom.begin() + 16 + 512 + 16384, 0xEA);
    assert(cart.load_ines(trainer_rom.data(), trainer_rom.size(), &error));
    assert(cart.cpu_read(0x7000, value) && value == 0x77);
    assert(cart.cpu_read(0x71FF, value) && value == 0x77);

    // Battery-backed PRG RAM can be exported/imported as an exact 8 KiB save blob.
    auto battery_rom = make_nrom(16384, 8192, 0x02);
    assert(cart.load_ines(battery_rom.data(), battery_rom.size(), &error));
    assert(cart.has_battery());
    assert(cart.cpu_write(0x6000, 0xA5));
    assert(cart.cpu_write(0x7FFF, 0x5A));
    std::vector<uint8_t> save_blob;
    assert(cart.export_battery_ram(save_blob));
    assert(save_blob.size() == 8192 && save_blob[0] == 0xA5 && save_blob[8191] == 0x5A);
    assert(cart.cpu_write(0x6000, 0x00));
    assert(cart.import_battery_ram(save_blob.data(), save_blob.size(), &error));
    assert(cart.cpu_read(0x6000, value) && value == 0xA5);
    assert(cart.cpu_read(0x7FFF, value) && value == 0x5A);
    // Failed ROM replacement must preserve the loaded cartridge and save RAM.
    auto unsupported_mapper = make_nrom(16384, 8192, 0x40);
    assert(!cart.load_ines(unsupported_mapper.data(), unsupported_mapper.size(), &error));
    assert(cart.loaded() && cart.has_battery());
    assert(cart.cpu_read(0x6000, value) && value == 0xA5);
    assert(cart.cpu_read(0x7FFF, value) && value == 0x5A);
    assert(!cart.import_battery_ram(save_blob.data(), save_blob.size() - 1, &error));
    assert(!error.empty());
    auto volatile_ram_rom = make_nrom(16384, 8192, 0x00);
    assert(cart.load_ines(volatile_ram_rom.data(), volatile_ram_rom.size(), &error));
    assert(!cart.export_battery_ram(save_blob));
    assert(!cart.import_battery_ram(save_blob.data(), save_blob.size(), &error));

    // Reject non-NROM mapper and invalid NROM PRG sizes cleanly.
    auto mapper2 = make_nrom(16384, 8192, 0x40);
    assert(!cart.load_ines(mapper2.data(), mapper2.size(), &error));
    assert(cart.loaded() && !error.empty());
    assert(cart.cpu_read(0x6000, value) && value == 0x00); // failed replacement preserved old cartridge
    auto invalid_prg = make_nrom(16384, 8192);
    invalid_prg[4] = 3; // claims 48 KiB PRG, while payload is only 16 KiB
    assert(!cart.load_ines(invalid_prg.data(), invalid_prg.size(), &error));
    assert(cart.loaded() && cart.cpu_read(0x8000, value) && value == 0xEA);

    std::cout << "NROM mapper tests passed\n";
    return 0;
}
