#include "cartridge.h"
#include "cpu6502.h"
#include "ppu2c02.h"

#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

static std::vector<uint8_t> make_rom(bool vertical, bool chr_ram = true) {
    std::vector<uint8_t> rom(16 + 16384 + (chr_ram ? 0 : 8192), 0);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = 1; rom[5] = chr_ram ? 0 : 1; rom[6] = vertical ? 1 : 0;
    return rom;
}

static void set_ppu_address(nes::Ppu2C02& ppu, uint16_t address) {
    ppu.cpu_write_register(6, static_cast<uint8_t>(address >> 8));
    ppu.cpu_write_register(6, static_cast<uint8_t>(address));
}

int main() {
    // Pattern RAM works without a cartridge; palette entries are six-bit and universal-color aliases work.
    nes::Ppu2C02 bare;
    bare.write_memory(0x0012, 0xA5);
    assert(bare.read_memory(0x0012) == 0xA5);
    bare.write_memory(0x3F10, 0xFF);
    assert(bare.read_memory(0x3F00) == 0x3F);
    assert(bare.read_memory(0x3F10) == 0x3F);
    bare.write_memory(0x3F24, 0x22);
    assert(bare.read_memory(0x3F04) == 0x22);

    // Horizontal mirroring: $2000 == $2400 and $2800 == $2C00.
    auto horizontal_rom = make_rom(false);
    nes::NromCartridge horizontal;
    assert(horizontal.load_ines(horizontal_rom.data(), horizontal_rom.size()));
    nes::Ppu2C02 hppu; hppu.attach_cartridge(&horizontal);
    hppu.write_memory(0x2003, 0x31);
    assert(hppu.read_memory(0x2403) == 0x31);
    hppu.write_memory(0x2803, 0x42);
    assert(hppu.read_memory(0x2C03) == 0x42);

    // Vertical mirroring: $2000 == $2800 and $2400 == $2C00.
    auto vertical_rom = make_rom(true);
    nes::NromCartridge vertical;
    assert(vertical.load_ines(vertical_rom.data(), vertical_rom.size()));
    nes::Ppu2C02 vppu; vppu.attach_cartridge(&vertical);
    vppu.write_memory(0x2007, 0x51);
    assert(vppu.read_memory(0x2807) == 0x51);
    vppu.write_memory(0x2407, 0x62);
    assert(vppu.read_memory(0x2C07) == 0x62);

    // PPUADDR/PPUDATA buffering and VRAM increment control.
    nes::Ppu2C02 regs;
    regs.write_memory(0x2100, 0x17);
    set_ppu_address(regs, 0x2100);
    assert(regs.cpu_read_register(7) == 0); // first non-palette read returns old buffer
    assert(regs.cpu_read_register(7) == 0x17);
    assert(regs.vram_address() == 0x2102);
    regs.cpu_write_register(0, 0x04); // increment by 32
    set_ppu_address(regs, 0x2200);
    regs.cpu_write_register(7, 0x66);
    assert(regs.vram_address() == 0x2220);
    assert(regs.read_memory(0x2200) == 0x66);

    // Background snapshot decodes tile bitplanes and applies the selected palette.
    nes::Ppu2C02 renderer;
    renderer.write_memory(0x2000, 1);       // First nametable tile = tile 1.
    renderer.write_memory(0x0010, 0x80);    // Tile 1, row 0: leftmost pixel is color 1.
    renderer.write_memory(0x0018, 0x00);
    renderer.write_memory(0x3F00, 0x0F);    // Universal backdrop.
    renderer.write_memory(0x3F01, 0x21);    // Background palette 0, color 1.
    renderer.cpu_write_register(1, 0x0A);   // Enable background + leftmost 8 pixels.
    const auto frame = renderer.render_background_frame();
    assert(frame.size() == 256U * 240U);
    assert(frame[0] == 0x21);
    assert(frame[1] == 0x0F);
    assert(frame[255] == 0x0F);
    // Grayscale output masks palette indices to $30/$20/$10/$00 while keeping
    // palette RAM intact, then restoring normal color output when disabled.
    renderer.cpu_write_register(1, 0x0B); // Background + left edge + grayscale.
    const auto grayscale_frame = renderer.render_background_frame();
    assert(grayscale_frame[0] == 0x20); // $21 & $30
    assert(grayscale_frame[1] == 0x00); // $0F & $30
    assert(renderer.read_memory(0x3F01) == 0x21); // Palette RAM unchanged.
    renderer.cpu_write_register(1, 0x00);
    const auto blank_frame = renderer.render_background_frame();
    assert(blank_frame[0] == 0x0F && blank_frame[255U * 239U + 255U] == 0x0F);

    // Horizontal scrolling: an 8-pixel scroll exposes the next nametable tile
    // at the left edge. Tile 0 uses plane 0; tile 1 uses plane 1 (color index 2).
    nes::Ppu2C02 scrolled;
    scrolled.write_memory(0x2000, 0);
    scrolled.write_memory(0x2001, 1);
    scrolled.write_memory(0x0000, 0xFF);
    scrolled.write_memory(0x0008, 0x00);
    scrolled.write_memory(0x0010, 0x00);
    scrolled.write_memory(0x0018, 0xFF);
    scrolled.write_memory(0x3F01, 0x11);
    scrolled.write_memory(0x3F02, 0x22);
    scrolled.cpu_write_register(5, 8); // coarse X scroll = one tile
    scrolled.cpu_write_register(5, 0); // fine Y/coarse Y = zero
    scrolled.cpu_write_register(1, 0x0A);
    const auto scrolled_frame = scrolled.render_background_frame();
    assert(scrolled_frame[0] == 0x22);
    assert(scrolled_frame[8] == 0x11);

    // Fine-X scrolling shifts the pixel sampling within the selected tile.
    nes::Ppu2C02 fine_scrolled;
    fine_scrolled.write_memory(0x2000, 0);
    fine_scrolled.write_memory(0x0000, 0x80); // only the leftmost source pixel is opaque
    fine_scrolled.write_memory(0x3F00, 0x0F);
    fine_scrolled.write_memory(0x3F01, 0x2A);
    fine_scrolled.cpu_write_register(5, 1);
    fine_scrolled.cpu_write_register(5, 0);
    fine_scrolled.cpu_write_register(1, 0x0A);
    const auto fine_frame = fine_scrolled.render_background_frame();
    assert(fine_frame[0] == 0x0F);
    assert(fine_frame[7] == 0x2A);

    // Sprite snapshot: OAM coordinates, transparent pixel handling, palette, and sprite-zero hit.
    nes::Ppu2C02 sprite_renderer;
    sprite_renderer.write_memory(0x2000, 1); // Opaque background tile at (0,0).
    sprite_renderer.write_memory(0x0010, 0x80);
    sprite_renderer.write_memory(0x0011, 0x80);
    sprite_renderer.write_memory(0x0018, 0x00);
    sprite_renderer.write_memory(0x0000, 0x80); // Sprite tile 0, row 0, pixel 0 opaque.
    sprite_renderer.write_memory(0x0008, 0x00);
    sprite_renderer.write_memory(0x3F01, 0x21);
    sprite_renderer.write_memory(0x3F11, 0x30);
    // Hide all sprites first; OAM zero-initialization would otherwise put 64 sprites at (0,1).
    sprite_renderer.cpu_write_register(3, 0);
    for (int i = 0; i < 64; ++i) {
        sprite_renderer.cpu_write_register(4, 0xFF);
        sprite_renderer.cpu_write_register(4, 0);
        sprite_renderer.cpu_write_register(4, 0);
        sprite_renderer.cpu_write_register(4, 0);
    }
    sprite_renderer.cpu_write_register(3, 0);
    sprite_renderer.cpu_write_register(4, 0);   // Y => top scanline 1.
    sprite_renderer.cpu_write_register(4, 0);   // Tile 0.
    sprite_renderer.cpu_write_register(4, 0);   // In front of background, palette 0.
    sprite_renderer.cpu_write_register(4, 0);   // X = 0.
    sprite_renderer.cpu_write_register(1, 0x1E); // Background + sprites and both left-edge enables.
    const auto sprite_frame = sprite_renderer.render_background_frame();
    assert(sprite_frame[256] == 0x30); // Sprite covers pixel (0,1).
    assert(sprite_renderer.status() & 0x40); // Sprite zero overlaps opaque background at x=0,y=1.
    sprite_renderer.cpu_write_register(3, 2);
    sprite_renderer.cpu_write_register(4, 0x20); // Sprite priority: behind opaque background.
    const auto behind_frame = sprite_renderer.render_background_frame();
    assert(behind_frame[256] == 0x21);
    assert(sprite_renderer.status() & 0x40); // Priority affects display, not overlap detection.

    // Lower OAM index must win when two opaque sprites overlap the same pixel.
    sprite_renderer.cpu_write_register(3, 0);
    sprite_renderer.cpu_write_register(4, 0); // Sprite 0: top scanline 1.
    sprite_renderer.cpu_write_register(4, 0);
    sprite_renderer.cpu_write_register(4, 0); // Palette 0, in front of background.
    sprite_renderer.cpu_write_register(4, 0);
    sprite_renderer.cpu_write_register(3, 4);
    sprite_renderer.cpu_write_register(4, 0); // Sprite 1 overlaps sprite 0 exactly.
    sprite_renderer.cpu_write_register(4, 0);
    sprite_renderer.cpu_write_register(4, 1); // Different palette makes the winner observable.
    sprite_renderer.cpu_write_register(4, 0);
    sprite_renderer.write_memory(0x3F15, 0x16);
    const auto overlap_frame = sprite_renderer.render_background_frame();
    assert(overlap_frame[256] == 0x30); // Sprite 0 wins, regardless of later OAM entries.

    // PPUSTATUS reports and clears vblank; NMI is generated only when enabled.
    regs.cpu_write_register(0, 0x80);
    regs.set_vblank(true);
    assert(regs.status() & 0x80);
    assert(regs.take_nmi_request());
    assert(regs.cpu_read_register(2) & 0x80);
    assert(!(regs.status() & 0x80));
    regs.set_vblank(false);
    regs.cpu_write_register(0, 0);
    regs.set_vblank(true);
    assert(!regs.take_nmi_request());

    // NMI is edge-triggered: enabling it during VBlank queues one request,
    // but rewriting PPUCTRL while the NMI line stays high must not retrigger.
    nes::Ppu2C02 nmi_edges;
    nmi_edges.set_vblank(true);
    assert(!nmi_edges.take_nmi_request());
    nmi_edges.cpu_write_register(0, 0x80);
    assert(nmi_edges.take_nmi_request());
    nmi_edges.cpu_write_register(0, 0x80);
    assert(!nmi_edges.take_nmi_request());
    nmi_edges.cpu_write_register(0, 0x00); // Drop the line.
    nmi_edges.cpu_write_register(0, 0x80); // Rising edge queues a new request.
    assert(nmi_edges.take_nmi_request());
    nmi_edges.cpu_read_register(2); // Reading PPUSTATUS cancels VBlank/NMI.
    assert(!nmi_edges.take_nmi_request());
    nmi_edges.cpu_write_register(0, 0x80);
    assert(!nmi_edges.take_nmi_request()); // Still outside VBlank.

    // NTSC clock advances at three PPU dots per CPU cycle and raises VBlank
    // at scanline 241, dot 1. The pre-render line clears it at dot 1.
    nes::Ppu2C02 timed;
    timed.cpu_write_register(0, 0x80);
    assert(timed.scanline() == 261 && timed.dot() == 0);
    timed.clock_ppu_dots(242U * 341U + 2U);
    assert(timed.scanline() == 241 && timed.dot() == 2);
    assert(timed.status() & 0x80);
    assert(timed.take_nmi_request());
    timed.clock_ppu_dots(20U * 341U - 1U);
    assert(timed.scanline() == 261 && timed.dot() == 1);
    timed.clock_ppu_dots(1);
    assert(!(timed.status() & 0x80));
    const auto old_frame_count = timed.frame_count();
    timed.clock_cpu_cycles(100U); // 300 PPU dots, remaining on the pre-render scanline.
    assert(timed.frame_count() == old_frame_count);

    // NTSC odd-frame dot skip applies only when background or sprite rendering is enabled.
    nes::Ppu2C02 frame_timing;
    frame_timing.cpu_write_register(1, 0x08);
    frame_timing.clock_ppu_dots(341U); // Finish the initial pre-render scanline.
    assert(frame_timing.frame_count() == 1);
    assert(frame_timing.scanline() == 0 && frame_timing.dot() == 0);
    frame_timing.clock_ppu_dots(262U * 341U - 1U);
    assert(frame_timing.frame_count() == 2);
    assert(frame_timing.scanline() == 0 && frame_timing.dot() == 0);

    nes::Ppu2C02 no_render_timing;
    no_render_timing.clock_ppu_dots(341U);
    no_render_timing.clock_ppu_dots(262U * 341U);
    assert(no_render_timing.frame_count() == 2);

    // CPU bus mirrors PPU registers throughout $2000-$3FFF.
    nes::CpuBus bus;
    bus.attach_ppu(&regs);
    bus.write(0x2001, 0x1E);
    assert(regs.mask() == 0x1E);
    bus.write(0x2008 + 1, 0x2A);
    assert(regs.mask() == 0x2A);

    std::cout << "PPU 2C02 register/memory tests passed\n";
    return 0;
}
