#include "nes_engine.h"
#include "cpu6502.h"

#include <limits>
#include <sstream>

namespace nes {
namespace {
constexpr size_t kHeaderSize = 16;
constexpr uint8_t kTrainerFlag = 0x04;

bool has_magic(const uint8_t* data, size_t size) {
    return size >= 4 && data[0] == 'N' && data[1] == 'E' &&
           data[2] == 'S' && data[3] == 0x1A;
}

bool add_overflows(size_t a, size_t b) {
    return b > std::numeric_limits<size_t>::max() - a;
}
}

RomInfo inspect_rom(const uint8_t* data, size_t size) {
    RomInfo out;
    if (data == nullptr || size < kHeaderSize) {
        out.error = "File terlalu kecil: header iNES membutuhkan 16 byte.";
        return out;
    }
    if (!has_magic(data, size)) {
        out.error = "Header tidak valid: signature NES\\x1A tidak ditemukan.";
        return out;
    }

    const uint8_t flags6 = data[6];
    const uint8_t flags7 = data[7];
    out.nes2 = (flags7 & 0x0C) == 0x08;
    out.battery = (flags6 & 0x02) != 0;
    out.trainer = (flags6 & kTrainerFlag) != 0;
    out.four_screen = (flags6 & 0x08) != 0;

    out.mapper = static_cast<uint16_t>((flags6 >> 4) | (flags7 & 0xF0));

    if (out.nes2) {
        const uint8_t size_msb = data[9];
        const uint8_t prg_msb = size_msb & 0x0F;
        const uint8_t chr_msb = size_msb >> 4;
        if (prg_msb == 0x0F) {
            const uint8_t exponent = data[4] >> 2;
            const uint8_t multiplier = data[4] & 0x03;
            if (exponent >= 63) {
                out.error = "Ukuran PRG ROM NES 2.0 terlalu besar.";
                return out;
            }
            out.prg_rom_bytes = (uint64_t{1} << exponent) * (2 * multiplier + 1);
        } else {
            out.prg_rom_bytes = (static_cast<uint64_t>(prg_msb) << 8 | data[4]) * 16384ULL;
        }
        if (chr_msb == 0x0F) {
            const uint8_t exponent = data[5] >> 2;
            const uint8_t multiplier = data[5] & 0x03;
            if (exponent >= 63) {
                out.error = "Ukuran CHR ROM NES 2.0 terlalu besar.";
                return out;
            }
            out.chr_rom_bytes = (uint64_t{1} << exponent) * (2 * multiplier + 1);
        } else {
            out.chr_rom_bytes = (static_cast<uint64_t>(chr_msb) << 8 | data[5]) * 8192ULL;
        }
        out.mapper |= static_cast<uint16_t>((data[8] & 0x0F) << 8);
    } else {
        // Ignore dirty upper header bytes used by some archaic dump formats.
        out.prg_rom_bytes = static_cast<uint64_t>(data[4]) * 16384ULL;
        out.chr_rom_bytes = static_cast<uint64_t>(data[5]) * 8192ULL;
    }

    if (out.prg_rom_bytes == 0) {
        out.error = "ROM tidak memiliki PRG ROM.";
        return out;
    }

    size_t offset = kHeaderSize;
    if (out.trainer) {
        if (add_overflows(offset, 512)) {
            out.error = "Ukuran trainer tidak valid.";
            return out;
        }
        offset += 512;
    }
    if (out.prg_rom_bytes > std::numeric_limits<size_t>::max() ||
        out.chr_rom_bytes > std::numeric_limits<size_t>::max()) {
        out.error = "Ukuran ROM tidak didukung perangkat.";
        return out;
    }
    const size_t prg = static_cast<size_t>(out.prg_rom_bytes);
    const size_t chr = static_cast<size_t>(out.chr_rom_bytes);
    if (add_overflows(offset, prg) || add_overflows(offset + prg, chr)) {
        out.error = "Ukuran ROM melampaui batas.";
        return out;
    }
    const size_t required = offset + prg + chr;
    if (required > size) {
        std::ostringstream msg;
        msg << "ROM terpotong: header menyatakan minimal " << required
            << " byte, tetapi file hanya " << size << " byte.";
        out.error = msg.str();
        return out;
    }

    out.payload_offset = offset;
    out.valid = true;
    return out;
}

std::string describe_rom(const RomInfo& info) {
    if (!info.valid) return "ROM tidak valid: " + info.error;
    std::ostringstream out;
    out << "ROM valid\n"
        << "Format: " << (info.nes2 ? "NES 2.0" : "iNES 1.0") << "\n"
        << "Mapper: " << info.mapper << "\n"
        << "PRG ROM: " << info.prg_rom_bytes << " byte\n"
        << "CHR ROM: " << info.chr_rom_bytes << " byte\n"
        << "Trainer: " << (info.trainer ? "ya" : "tidak") << "\n"
        << "Battery save: " << (info.battery ? "ya" : "tidak") << "\n"
        << "Status: parser berhasil; mapper 0/1/2/3/4/7 didukung. Mapper lain belum tersedia.";
    return out.str();
}

std::string engine_status() {
#if defined(__aarch64__)
    return "Native engine ARM64 aktif. Parser ROM, CPU 6502, mapper 0/1/2/3/4/7, PPU per-scanline, dan APU dasar tersedia; DMC dan mapper lain belum tersedia. Recompiler dinamis 6502 → ARM64 tersedia (tombol JIT), interpreter sebagai cadangan.";
#elif defined(__x86_64__)
    return "Native engine x86_64 aktif. Parser ROM, CPU 6502, mapper 0/1/2/3/4/7, PPU per-scanline, dan APU dasar tersedia; DMC dan mapper lain belum tersedia; recompiler hanya untuk ARM64 (interpreter dipakai).";
#else
    return "Native engine aktif. Parser ROM, CPU 6502, mapper 0/1/2/3/4/7, PPU per-scanline, dan APU dasar tersedia; DMC, mapper lain, dan recompiler belum tersedia.";
#endif
}
}
