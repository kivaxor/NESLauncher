#include "ppu2c02.h"

#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>

static void run_to(nes::Ppu2C02& ppu, uint16_t scanline, uint16_t dot) {
    int guard = 0;
    while (!(ppu.scanline() == scanline && ppu.dot() == dot)) {
        ppu.clock_ppu_dots(1);
        assert(++guard < 400000);
    }
}

static void write_vram(nes::Ppu2C02& ppu, uint16_t address, uint8_t value) {
    ppu.cpu_write_register(0x2006, static_cast<uint8_t>(address >> 8));
    ppu.cpu_write_register(0x2006, static_cast<uint8_t>(address));
    ppu.cpu_write_register(0x2007, value);
}

static void setup(nes::Ppu2C02& ppu, bool stripe_only) {
    ppu.reset();
    // Tile 1: solid colour index 1.
    for (int row = 0; row < 8; ++row) write_vram(ppu, static_cast<uint16_t>(0x0010 + row), 0xFF);
    write_vram(ppu, 0x3F00, 0x0F);
    write_vram(ppu, 0x3F01, 0x30);
    write_vram(ppu, 0x3F11, 0x16);
    // Nametable 0: either a vertical stripe at tile column 1, or solid tile 1.
    ppu.cpu_write_register(0x2006, 0x20);
    ppu.cpu_write_register(0x2006, 0x00);
    for (int row = 0; row < 30; ++row)
        for (int col = 0; col < 32; ++col)
            ppu.cpu_write_register(0x2007, (stripe_only ? col == 1 : true) ? 1 : 0);
    ppu.cpu_write_register(0x2000, 0x00);
    ppu.cpu_write_register(0x2005, 0x00);
    ppu.cpu_write_register(0x2005, 0x00);
}

int main() {
    // A scroll write in mid-frame affects only later scanlines.
    {
        nes::Ppu2C02 ppu;
        setup(ppu, true);
        ppu.cpu_write_register(0x2001, 0x0A);
        run_to(ppu, 0, 0);
        const uint64_t frame = ppu.frame_count();
        run_to(ppu, 100, 10);
        ppu.cpu_write_register(0x2005, 0x08); // coarse X = 1
        ppu.cpu_write_register(0x2005, 0x00);
        while (ppu.frame_count() == frame) ppu.clock_ppu_dots(1);
        const auto& fb = ppu.frame_buffer();
        auto px = [&](int x, int y) { return fb[static_cast<size_t>(y) * 256 + static_cast<size_t>(x)]; };
        assert(px(0, 50) == 0x0F && px(8, 50) == 0x30 && px(15, 50) == 0x30 && px(16, 50) == 0x0F);
        assert(px(8, 100) == 0x30);                       // the line being drawn is unchanged
        assert(px(0, 101) == 0x30 && px(7, 101) == 0x30); // later lines are shifted by 8 pixels
        assert(px(8, 150) == 0x0F && px(0, 150) == 0x30);
    }
    // Fine X scroll and left-edge clipping.
    {
        nes::Ppu2C02 ppu;
        setup(ppu, true);
        ppu.cpu_write_register(0x2005, 0x03); // fine X = 3
        ppu.cpu_write_register(0x2005, 0x00);
        ppu.cpu_write_register(0x2001, 0x08); // background on, left 8 pixels clipped
        run_to(ppu, 0, 0);
        const uint64_t frame = ppu.frame_count();
        while (ppu.frame_count() == frame) ppu.clock_ppu_dots(1);
        const auto& fb = ppu.frame_buffer();
        assert(fb[10 * 256 + 4] == 0x0F);  // stripe starts at x=5 but x<8 is clipped
        assert(fb[10 * 256 + 5] == 0x0F);
        assert(fb[10 * 256 + 8] == 0x30);
        assert(fb[10 * 256 + 12] == 0x30);
        assert(fb[10 * 256 + 13] == 0x0F);
    }
    // Sprite-zero hit appears at the dot of the overlapping pixel, not at the frame end.
    {
        nes::Ppu2C02 ppu;
        setup(ppu, false); // solid background
        ppu.cpu_write_register(0x2003, 0x00);
        ppu.cpu_write_register(0x2004, 29);  // top = 30
        ppu.cpu_write_register(0x2004, 1);
        ppu.cpu_write_register(0x2004, 0);
        ppu.cpu_write_register(0x2004, 40);
        ppu.cpu_write_register(0x2001, 0x1E);
        run_to(ppu, 29, 300);
        assert((ppu.status() & 0x40) == 0);
        run_to(ppu, 30, 20);
        assert((ppu.status() & 0x40) == 0);
        run_to(ppu, 30, 60);
        assert((ppu.status() & 0x40) != 0);
        run_to(ppu, 261, 2); // cleared on the pre-render line
        assert((ppu.status() & 0x40) == 0);
        const uint64_t frame = ppu.frame_count();
        while (ppu.frame_count() == frame) ppu.clock_ppu_dots(1);
        const auto& fb = ppu.frame_buffer();
        assert(fb[30 * 256 + 40] == 0x16 && fb[37 * 256 + 47] == 0x16);
        assert(fb[38 * 256 + 40] == 0x30 && fb[30 * 256 + 39] == 0x30);
    }
    // More than eight sprites on one scanline set the overflow flag.
    {
        nes::Ppu2C02 ppu;
        setup(ppu, true);
        ppu.cpu_write_register(0x2003, 0x00);
        for (int i = 0; i < 9; ++i) {
            ppu.cpu_write_register(0x2004, 79);
            ppu.cpu_write_register(0x2004, 1);
            ppu.cpu_write_register(0x2004, 0);
            ppu.cpu_write_register(0x2004, static_cast<uint8_t>(i * 10));
        }
        ppu.cpu_write_register(0x2001, 0x1E);
        run_to(ppu, 90, 0);
        assert((ppu.status() & 0x20) != 0);
    }
    std::cout << "PPU scanline renderer tests passed\n";
}
