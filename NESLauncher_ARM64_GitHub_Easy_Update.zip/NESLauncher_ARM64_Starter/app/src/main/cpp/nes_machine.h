#pragma once

#include "apu.h"
#include "cartridge.h"
#include "cpu6502.h"
#include "ppu2c02.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace nes {
// Machine coordinator for the supported mappers (0, 1, 2, 3, 4, 7).
// CPU instruction cycles drive the PPU at 3 NTSC dots per CPU cycle.
class NesMachine {
public:
    explicit NesMachine(uint32_t sample_rate = 44100);
    bool load_rom(const uint8_t* data, size_t size, std::string* error = nullptr);
    bool loaded() const { return cartridge_.loaded(); }
    // Executes until the PPU advances to the next frame, then returns a snapshot.
    bool run_frame(std::array<uint8_t, 256 * 240>& pixels, std::string* error = nullptr);
    void set_controller_state(unsigned player, uint8_t buttons) { bus_.set_controller_state(player, buttons); }
    // Appends mono 16-bit PCM generated since the last call. Returns samples appended.
    size_t take_audio(std::vector<int16_t>& out) { return apu_.take_samples(out); }
    uint32_t audio_sample_rate() const { return apu_.sample_rate(); }
    uint64_t frame_count() const { return ppu_.frame_count(); }
    uint64_t cpu_cycle_count() const { return cpu_cycle_count_; }
    uint16_t program_counter() const { return cpu_.pc(); }
    bool export_battery_ram(std::vector<uint8_t>& out) const { return cartridge_.export_battery_ram(out); }
    bool import_battery_ram(const uint8_t* data, size_t size, std::string* error = nullptr) {
        return cartridge_.import_battery_ram(data, size, error);
    }

private:
    Cartridge cartridge_;
    Ppu2C02 ppu_;
    Apu apu_;
    CpuBus bus_;
    Cpu6502 cpu_;
    uint64_t cpu_cycle_count_ = 0;
};
} // namespace nes
