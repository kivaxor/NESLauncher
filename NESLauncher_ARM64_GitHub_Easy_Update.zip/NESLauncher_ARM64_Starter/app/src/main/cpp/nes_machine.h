#pragma once

#include "apu.h"
#include "cartridge.h"
#include "cpu6502.h"
#include "jit6502.h"
#include "ppu2c02.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace nes {
// Machine coordinator for the supported mappers (0, 1, 2, 3, 4, 7).
// CPU instruction cycles drive the PPU at 3 NTSC dots per CPU cycle.
class NesMachine final : public jit::JitHost {
public:
    explicit NesMachine(uint32_t sample_rate = 44100);
    NesMachine(const NesMachine&) = delete;
    NesMachine& operator=(const NesMachine&) = delete;
    ~NesMachine() override;

    // Dynamic recompiler (6502 -> ARM64). Enabling installs the native backend, which exists only
    // on ARM64 Linux/Android; the return value tells whether it is now active. When it is not
    // active, or when an opcode cannot be translated, the interpreter runs instead.
    bool set_recompiler_enabled(bool enabled);
    // Test hook: use an arbitrary backend (for example an emulator running the generated code).
    bool use_jit_backend(std::unique_ptr<jit::JitBackend> backend);
    bool recompiler_active() const { return jit_ != nullptr && jit_->ok(); }
    uint64_t recompiled_blocks_run() const { return jit_blocks_run_; }
    uint64_t interpreted_steps() const { return interpreted_steps_; }
    size_t jit_compiled_blocks() const { return jit_ ? jit_->compiled_blocks() : 0; }
    size_t jit_flushes() const { return jit_ ? jit_->flushes() : 0; }
    size_t jit_mapping_switches() const { return jit_ ? jit_->mapping_switches() : 0; }
    size_t jit_mapping_reuses() const { return jit_ ? jit_->mapping_reuses() : 0; }
    // Exposed for tests.
    uint8_t cpu_a() const { return cpu_.a(); }
    uint8_t cpu_x() const { return cpu_.x(); }
    uint8_t cpu_y() const { return cpu_.y(); }
    uint8_t cpu_sp() const { return cpu_.sp(); }
    uint8_t cpu_status() const { return cpu_.status(); }
    uint8_t cpu_peek_ram(uint16_t address) const { return bus_.ram[address & 0x7FF]; }
    uint8_t cpu_peek(uint16_t address) { return bus_.read(address); } // ROM/RAM only: I/O reads have side effects
    uint8_t* cpu_ram_data() { return bus_.ram.data(); }
    // Debug hook: called with (pc, cpu cycle count) before every interpreted instruction and every recompiled block.
    void set_trace_hook(std::function<void(uint16_t, uint64_t)> hook) { trace_ = std::move(hook); }

    bool load_rom(const uint8_t* data, size_t size, std::string* error = nullptr);
    bool loaded() const { return cartridge_.loaded(); }
    // Executes until the PPU advances to the next frame, then returns a snapshot.
    bool run_frame(std::array<uint8_t, 256 * 240>& pixels, std::string* error = nullptr);
    void set_controller_state(unsigned player, uint8_t buttons) { bus_.set_controller_state(player, buttons); }
    // Appends mono 16-bit PCM generated since the last call. Returns samples appended.
    size_t take_audio(std::vector<int16_t>& out) { return apu_.take_samples(out); }
    uint32_t audio_sample_rate() const { return apu_.sample_rate(); }
    uint64_t frame_count() const { return ppu_.frame_count(); }
    uint64_t cpu_cycle_count() const { return cpu_cycle_count_; }
    uint16_t program_counter() const { return cpu_.pc(); }
    bool export_battery_ram(std::vector<uint8_t>& out) const { return cartridge_.export_battery_ram(out); }
    bool import_battery_ram(const uint8_t* data, size_t size, std::string* error = nullptr) {
        return cartridge_.import_battery_ram(data, size, error);
    }

    // jit::JitHost (called from generated code).
    uint8_t jit_read(jit::JitContext& ctx, uint16_t address) override;
    void jit_write(jit::JitContext& ctx, uint16_t address, uint8_t value) override;

private:
    // Advances PPU/APU by CPU cycles and forwards NMI/IRQ requests to the CPU.
    void advance(uint32_t cpu_cycles);
    bool run_jit_block();
    uint32_t event_horizon() const;
    void jit_check_mapping();
    unsigned irq_armed_state() const;
    void jit_sync(uint32_t block_cycles);

    Cartridge cartridge_;
    Ppu2C02 ppu_;
    Apu apu_;
    CpuBus bus_;
    Cpu6502 cpu_;
    uint64_t cpu_cycle_count_ = 0;

    std::function<void(uint16_t, uint64_t)> trace_;
    std::unique_ptr<jit::Jit6502> jit_;
    uint32_t jit_synced_ = 0;     // block cycles already applied to PPU/APU
    bool jit_event_ = false;      // NMI or IRQ edge raised while a block runs
    bool irq_line_ = false;
    uint32_t jit_sig_ = 0;        // PRG mapping the cached blocks were translated for
    uint64_t jit_blocks_run_ = 0, interpreted_steps_ = 0;
};
} // namespace nes
