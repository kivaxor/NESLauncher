#include "nes_machine.h"

#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

namespace {
uint64_t fnv(const uint8_t* p, size_t n, uint64_t h = 1469598103934665603ULL) {
    for (size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}

// NROM-128 test program: enables NMI, rendering and square channel 1, then loops forever bumping a
// zero-page counter and changing the APU period. The NMI handler bumps a second counter, so CPU,
// RAM, PPU, APU and interrupts all carry state across frames.
std::vector<uint8_t> make_rom() {
    std::vector<uint8_t> rom(16 + 16384 + 8192, 0xEA);
    rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A;
    rom[4] = 1; rom[5] = 1; rom[6] = 0; rom[7] = 0;
    const uint8_t program[] = {
        0xA9, 0x80, 0x8D, 0x00, 0x20, // LDA #$80 ; STA $2000   (NMI on)
        0xA9, 0x1E, 0x8D, 0x01, 0x20, // LDA #$1E ; STA $2001   (rendering on)
        0xA9, 0x01, 0x8D, 0x15, 0x40, // LDA #$01 ; STA $4015   (pulse 1 on)
        0xA9, 0xBF, 0x8D, 0x00, 0x40, // LDA #$BF ; STA $4000
        0xE6, 0x00,                   // loop: INC $00
        0xA5, 0x00, 0x8D, 0x02, 0x40, //       LDA $00 ; STA $4002
        0xA9, 0x08, 0x8D, 0x03, 0x40, //       LDA #$08 ; STA $4003
        0x4C, 0x15, 0x80,             //       JMP loop ($8015)
    };
    for (size_t i = 0; i < sizeof(program); ++i) rom[16 + i] = program[i];
    rom[16 + 0x100] = 0xE6; rom[16 + 0x101] = 0x01; rom[16 + 0x102] = 0x40; // NMI: INC $01 ; RTI
    rom[16 + 0x3FFA] = 0x00; rom[16 + 0x3FFB] = 0x81; // NMI vector -> $8100
    rom[16 + 0x3FFC] = 0x00; rom[16 + 0x3FFD] = 0x80; // reset vector -> $8000
    return rom;
}

struct Rec { uint64_t video, audio; };
std::vector<Rec> run(nes::NesMachine& m, int frames) {
    std::vector<Rec> out;
    std::array<uint8_t, 256 * 240> px{};
    std::vector<int16_t> pcm;
    std::string error;
    for (int i = 0; i < frames; ++i) {
        assert(m.run_frame(px, &error));
        pcm.clear();
        m.take_audio(pcm);
        out.push_back({fnv(px.data(), px.size()),
                       fnv(reinterpret_cast<const uint8_t*>(pcm.data()), pcm.size() * sizeof(int16_t))});
    }
    return out;
}
bool same(const std::vector<Rec>& a, const std::vector<Rec>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i)
        if (a[i].video != b[i].video || a[i].audio != b[i].audio) return false;
    return true;
}
} // namespace

int main() {
    const std::vector<uint8_t> rom = make_rom();
    std::string error;

    nes::NesMachine m(48000);
    assert(!m.load_state(nullptr, 0, &error)); // no ROM yet
    assert(m.load_rom(rom.data(), rom.size(), &error));
    run(m, 20);
    const std::vector<uint8_t> state = m.save_state();
    assert(state.size() > 100000);

    // Continuing from a state is bit-for-bit the same as playing on from the save point.
    const auto expected = run(m, 30);
    assert(m.load_state(state.data(), state.size(), &error));
    assert(error.empty());
    assert(same(expected, run(m, 30)));

    // A fresh machine with the same ROM resumes identically.
    nes::NesMachine other(48000);
    assert(other.load_rom(rom.data(), rom.size(), &error));
    assert(other.load_state(state.data(), state.size(), &error));
    assert(same(expected, run(other, 30)));
    assert(other.rom_key() == m.rom_key());

    // Saving right after a load reproduces the same bytes.
    nes::NesMachine third(48000);
    assert(third.load_rom(rom.data(), rom.size(), &error));
    assert(third.load_state(state.data(), state.size(), &error));
    assert(third.save_state() == state);
    assert(third.last_frame().size() == 256U * 240U);

    // Invalid input is rejected and leaves the machine exactly as it was.
    nes::NesMachine victim(48000);
    assert(victim.load_rom(rom.data(), rom.size(), &error));
    run(victim, 5);
    const std::vector<uint8_t> before = victim.save_state();
    std::vector<uint8_t> truncated(state.begin(), state.end() - 10);
    assert(!victim.load_state(truncated.data(), truncated.size(), &error));
    assert(!error.empty());
    std::vector<uint8_t> bad_magic = state;
    bad_magic[0] = 'X';
    assert(!victim.load_state(bad_magic.data(), bad_magic.size(), &error));
    std::vector<uint8_t> bad_version = state;
    bad_version[4] = 99;
    assert(!victim.load_state(bad_version.data(), bad_version.size(), &error));
    assert(victim.save_state() == before);

    // A state belongs to one ROM image.
    std::vector<uint8_t> other_rom = rom;
    other_rom[16 + 0x200] = 0x55;
    nes::NesMachine stranger(48000);
    assert(stranger.load_rom(other_rom.data(), other_rom.size(), &error));
    assert(stranger.rom_key() != m.rom_key());
    assert(!stranger.load_state(state.data(), state.size(), &error));
    assert(error.find("ROM") != std::string::npos);

    // Reset equals a fresh power-on.
    nes::NesMachine fresh(48000);
    assert(fresh.load_rom(rom.data(), rom.size(), &error));
    const auto fresh_run = run(fresh, 25);
    run(victim, 15);
    victim.reset();
    assert(victim.program_counter() == 0x8000);
    assert(victim.cpu_cycle_count() == 0);
    assert(same(fresh_run, run(victim, 25)));

    std::cout << "NES state tests passed\n";
}
