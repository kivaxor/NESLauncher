#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace nes {

// Basic NES APU: two pulse channels, triangle and noise with length counters,
// envelopes, sweep and the 4/5-step frame counter. DMC registers are accepted
// but the DMC channel stays silent. Output is mono signed 16-bit PCM generated
// by clocking one CPU cycle at a time and resampling to the output rate.
class Apu {
public:
    static constexpr uint32_t kCpuHz = 1789773;

    explicit Apu(uint32_t sample_rate = 44100);
    void reset();
    void write(uint16_t address, uint8_t value); // $4000-$4013, $4015, $4017
    uint8_t read_status();                      // $4015
    void clock_cpu_cycles(uint32_t cycles);
    // Moves queued samples to out (appending). Returns the number appended.
    size_t take_samples(std::vector<int16_t>& out);
    bool frame_irq() const { return frame_irq_; }
    // True when the frame counter can still raise a new IRQ edge by itself.
    bool frame_irq_armed() const { return !irq_inhibit_ && !five_step_ && !frame_irq_; }
    // CPU cycles until the frame IRQ is raised (only meaningful when frame_irq_armed()).
    uint32_t cycles_until_frame_irq() const {
        return frame_cycle_ < 29829 ? 29829 - frame_cycle_ : 29830 - frame_cycle_ + 29829;
    }
    uint32_t sample_rate() const { return sample_rate_; }

private:
    struct Pulse {
        bool enabled = false, constant = false, loop = false, start = false;
        bool sweep_enable = false, sweep_negate = false, sweep_reload = false, ones_complement = false;
        uint8_t duty = 0, volume = 0, decay = 0, divider = 0;
        uint8_t sweep_period = 0, sweep_shift = 0, sweep_div = 0;
        uint8_t length = 0, seq = 0;
        uint16_t timer_period = 0, timer = 0;
        uint8_t output() const;
        void clock_timer();
        void clock_envelope();
        void clock_length();
        void clock_sweep();
    };
    struct Triangle {
        bool enabled = false, control = false, reload = false;
        uint8_t linear_period = 0, linear = 0, length = 0, seq = 0;
        uint16_t timer_period = 0, timer = 0;
        uint8_t output() const;
        void clock_timer();
    };
    struct Noise {
        bool enabled = false, constant = false, loop = false, start = false, mode = false;
        uint8_t volume = 0, decay = 0, divider = 0, length = 0;
        uint16_t timer_period = 4, timer = 0, shift = 1;
        uint8_t output() const;
        void clock_timer();
    };

    void clock_frame_quarter();
    void clock_frame_half();
    void tick();
    float mix() const;

    uint32_t sample_rate_;
    Pulse pulse_[2];
    Triangle triangle_;
    Noise noise_;
    bool five_step_ = false, irq_inhibit_ = false, frame_irq_ = false;
    uint32_t frame_cycle_ = 0;
    uint64_t cycle_ = 0;
    double sample_accum_ = 0.0;
    float hp_prev_in_ = 0.0f, hp_prev_out_ = 0.0f;
    std::vector<int16_t> samples_;
};

} // namespace nes
