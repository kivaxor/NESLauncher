#pragma once
// Minimal AArch64 machine-code assembler used by the 6502 recompiler.
// Only the instructions the recompiler needs are provided. All encodings are
// emitted as 32-bit words; the class is host-independent so the generated code
// can be produced (and tested) on any machine.
#include <cassert>
#include <cstdint>
#include <vector>

namespace nes::jit {

enum Cond : uint32_t { EQ = 0, NE = 1, HS = 2, LO = 3, MI = 4, PL = 5, VS = 6, VC = 7, HI = 8, LS = 9, GE = 10, LT = 11, GT = 12, LE = 13 };

inline bool encode_logical_imm32(uint32_t value, uint32_t& immr, uint32_t& imms) {
    if (value == 0 || value == 0xFFFFFFFFu) return false;
    uint32_t size = 32;
    while (size > 2) {
        const uint32_t half = size / 2;
        const uint32_t mask = (1u << half) - 1;
        if ((value & mask) == ((value >> half) & mask)) size = half; else break;
    }
    const uint32_t mask = size == 32 ? 0xFFFFFFFFu : ((1u << size) - 1);
    const uint32_t v = value & mask;
    uint32_t ones = 0;
    for (uint32_t i = 0; i < size; ++i) ones += (v >> i) & 1u;
    const uint32_t base = ones == 32 ? 0xFFFFFFFFu : ((1u << ones) - 1);
    for (uint32_t rot = 0; rot < size; ++rot) {
        // ROR(base, rot) within `size` bits.
        uint32_t r = rot == 0 ? base : (((base >> rot) | (base << (size - rot))) & mask);
        if (r == v) {
            immr = rot;
            imms = ((0u - size * 2u) & 0x3Fu) | (ones - 1);
            return true;
        }
    }
    return false;
}

class Asm {
public:
    struct Label { int id = -1; };

    explicit Asm(uint64_t base_address = 0) : base_(base_address) {}
    size_t size() const { return code_.size(); }
    uint64_t address_of(size_t index) const { return base_ + index * 4; }
    uint64_t here() const { return address_of(code_.size()); }
    const std::vector<uint32_t>& code() const { return code_; }
    std::vector<uint32_t> take() { resolve(); return std::move(code_); }

    // ---- labels -----------------------------------------------------------------
    Label new_label() { positions_.push_back(-1); return Label{static_cast<int>(positions_.size()) - 1}; }
    void bind(Label l) { positions_[l.id] = static_cast<int64_t>(code_.size()); }

    // ---- moves / immediates -----------------------------------------------------
    void movz(uint32_t rd, uint32_t imm16, uint32_t hw = 0) { emit(0x52800000u | (hw << 21) | (imm16 << 5) | rd); }
    void movk(uint32_t rd, uint32_t imm16, uint32_t hw) { emit(0x72800000u | (hw << 21) | (imm16 << 5) | rd); }
    void mov_imm(uint32_t rd, uint32_t imm) {
        movz(rd, imm & 0xFFFF, 0);
        if (imm >> 16) movk(rd, imm >> 16, 1);
    }
    void mov(uint32_t rd, uint32_t rm) { emit(0x2A0003E0u | (rm << 16) | rd); }       // W
    void mov_x(uint32_t rd, uint32_t rm) { emit(0xAA0003E0u | (rm << 16) | rd); }     // X

    // ---- arithmetic -------------------------------------------------------------
    void add_imm(uint32_t rd, uint32_t rn, uint32_t imm) { assert(imm < 4096); emit(0x11000000u | (imm << 10) | (rn << 5) | rd); }
    void sub_imm(uint32_t rd, uint32_t rn, uint32_t imm) { assert(imm < 4096); emit(0x51000000u | (imm << 10) | (rn << 5) | rd); }
    void add_imm_x(uint32_t rd, uint32_t rn, uint32_t imm) { assert(imm < 4096); emit(0x91000000u | (imm << 10) | (rn << 5) | rd); }
    void cmp_imm(uint32_t rn, uint32_t imm) { assert(imm < 4096); emit(0x7100001Fu | (imm << 10) | (rn << 5)); }
    void add(uint32_t rd, uint32_t rn, uint32_t rm, uint32_t shift = 0) { emit(0x0B000000u | (rm << 16) | (shift << 10) | (rn << 5) | rd); }
    void sub(uint32_t rd, uint32_t rn, uint32_t rm) { emit(0x4B000000u | (rm << 16) | (rn << 5) | rd); }
    void cmp(uint32_t rn, uint32_t rm) { emit(0x6B00001Fu | (rm << 16) | (rn << 5)); }
    void add_x_uxtw(uint32_t rd, uint32_t rn, uint32_t rm) { emit(0x8B200000u | (rm << 16) | (2u << 13) | (rn << 5) | rd); }

    // ---- logic ------------------------------------------------------------------
    void and_reg(uint32_t rd, uint32_t rn, uint32_t rm) { emit(0x0A000000u | (rm << 16) | (rn << 5) | rd); }
    void orr_reg(uint32_t rd, uint32_t rn, uint32_t rm, uint32_t lsl = 0) { emit(0x2A000000u | (rm << 16) | (lsl << 10) | (rn << 5) | rd); }
    void eor_reg(uint32_t rd, uint32_t rn, uint32_t rm) { emit(0x4A000000u | (rm << 16) | (rn << 5) | rd); }
    void and_imm(uint32_t rd, uint32_t rn, uint32_t imm) { logical_imm(0x12000000u, rd, rn, imm); }
    void orr_imm(uint32_t rd, uint32_t rn, uint32_t imm) { logical_imm(0x32000000u, rd, rn, imm); }
    void eor_imm(uint32_t rd, uint32_t rn, uint32_t imm) { logical_imm(0x52000000u, rd, rn, imm); }
    void tst_imm(uint32_t rn, uint32_t imm) { logical_imm(0x72000000u, 31, rn, imm); }
    void tst(uint32_t rn, uint32_t rm) { emit(0x6A00001Fu | (rm << 16) | (rn << 5)); }

    // ---- bitfield ---------------------------------------------------------------
    void lsl_imm(uint32_t rd, uint32_t rn, uint32_t n) { emit(0x53000000u | (((32 - n) & 31) << 16) | ((31 - n) << 10) | (rn << 5) | rd); }
    void lsr_imm(uint32_t rd, uint32_t rn, uint32_t n) { emit(0x53000000u | (n << 16) | (31u << 10) | (rn << 5) | rd); }
    void ubfx(uint32_t rd, uint32_t rn, uint32_t lsb, uint32_t width) { emit(0x53000000u | (lsb << 16) | ((lsb + width - 1) << 10) | (rn << 5) | rd); }

    // ---- conditional select -----------------------------------------------------
    void cset(uint32_t rd, Cond c) { emit(0x1A9F07E0u | ((static_cast<uint32_t>(c) ^ 1u) << 12) | rd); }
    void csel(uint32_t rd, uint32_t rn, uint32_t rm, Cond c) { emit(0x1A800000u | (rm << 16) | (static_cast<uint32_t>(c) << 12) | (rn << 5) | rd); }

    // ---- memory -----------------------------------------------------------------
    void ldrb_imm(uint32_t rt, uint32_t rn, uint32_t off) { assert(off < 4096); emit(0x39400000u | (off << 10) | (rn << 5) | rt); }
    void strb_imm(uint32_t rt, uint32_t rn, uint32_t off) { assert(off < 4096); emit(0x39000000u | (off << 10) | (rn << 5) | rt); }
    void ldrb_reg_uxtw(uint32_t rt, uint32_t rn, uint32_t rm) { emit(0x38604800u | (rm << 16) | (rn << 5) | rt); }
    void strb_reg_uxtw(uint32_t rt, uint32_t rn, uint32_t rm) { emit(0x38204800u | (rm << 16) | (rn << 5) | rt); }
    void ldr_w(uint32_t rt, uint32_t rn, uint32_t off) { assert(off % 4 == 0 && off < 16384); emit(0xB9400000u | ((off / 4) << 10) | (rn << 5) | rt); }
    void str_w(uint32_t rt, uint32_t rn, uint32_t off) { assert(off % 4 == 0 && off < 16384); emit(0xB9000000u | ((off / 4) << 10) | (rn << 5) | rt); }
    void ldr_x(uint32_t rt, uint32_t rn, uint32_t off) { assert(off % 8 == 0 && off < 32768); emit(0xF9400000u | ((off / 8) << 10) | (rn << 5) | rt); }
    void str_x(uint32_t rt, uint32_t rn, uint32_t off) { assert(off % 8 == 0 && off < 32768); emit(0xF9000000u | ((off / 8) << 10) | (rn << 5) | rt); }
    void stp_x(uint32_t rt, uint32_t rt2, uint32_t rn, int32_t off) { emit(0xA9000000u | ((static_cast<uint32_t>(off / 8) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt); }
    void ldp_x(uint32_t rt, uint32_t rt2, uint32_t rn, int32_t off) { emit(0xA9400000u | ((static_cast<uint32_t>(off / 8) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt); }
    void stp_x_pre(uint32_t rt, uint32_t rt2, uint32_t rn, int32_t off) { emit(0xA9800000u | ((static_cast<uint32_t>(off / 8) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt); }
    void ldp_x_post(uint32_t rt, uint32_t rt2, uint32_t rn, int32_t off) { emit(0xA8C00000u | ((static_cast<uint32_t>(off / 8) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt); }

    // ---- branches ---------------------------------------------------------------
    void b(Label l) { fix(l, Fix::B26); emit(0x14000000u); }
    void b_cond(Cond c, Label l) { fix(l, Fix::B19); emit(0x54000000u | static_cast<uint32_t>(c)); }
    void cbz(uint32_t rt, Label l) { fix(l, Fix::B19); emit(0x34000000u | rt); }
    void cbnz(uint32_t rt, Label l) { fix(l, Fix::B19); emit(0x35000000u | rt); }
    void b_abs(uint64_t target) {
        const int64_t delta = (static_cast<int64_t>(target) - static_cast<int64_t>(here())) / 4;
        assert(delta > -(1 << 25) && delta < (1 << 25));
        emit(0x14000000u | (static_cast<uint32_t>(delta) & 0x03FFFFFFu));
    }
    void blr(uint32_t rn) { emit(0xD63F0000u | (rn << 5)); }
    void br(uint32_t rn) { emit(0xD61F0000u | (rn << 5)); }
    void ret() { emit(0xD65F03C0u); }
    void nop() { emit(0xD503201Fu); }

private:
    enum class Fix { B26, B19 };
    struct Fixup { size_t index; int label; Fix kind; };
    void emit(uint32_t w) { code_.push_back(w); }
    void fix(Label l, Fix k) { fixups_.push_back({code_.size(), l.id, k}); }
    void logical_imm(uint32_t opcode, uint32_t rd, uint32_t rn, uint32_t imm) {
        uint32_t immr = 0, imms = 0;
        const bool ok = encode_logical_imm32(imm, immr, imms);
        assert(ok);
        (void)ok;
        emit(opcode | (immr << 16) | (imms << 10) | (rn << 5) | rd);
    }
    void resolve() {
        for (const Fixup& f : fixups_) {
            assert(positions_[f.label] >= 0);
            const int64_t delta = positions_[f.label] - static_cast<int64_t>(f.index);
            if (f.kind == Fix::B26) code_[f.index] |= static_cast<uint32_t>(delta) & 0x03FFFFFFu;
            else code_[f.index] |= (static_cast<uint32_t>(delta) & 0x7FFFFu) << 5;
        }
        fixups_.clear();
    }
    uint64_t base_;
    std::vector<uint32_t> code_;
    std::vector<int64_t> positions_;
    std::vector<Fixup> fixups_;
};

} // namespace nes::jit
