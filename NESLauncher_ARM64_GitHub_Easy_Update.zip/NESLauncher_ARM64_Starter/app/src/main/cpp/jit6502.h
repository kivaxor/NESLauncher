#pragma once
// 6502 -> AArch64 dynamic recompiler.
//
// Design summary
//  * Basic blocks of 6502 code are translated to AArch64 machine code on first
//    execution and cached by start address.
//  * 6502 state lives in callee-saved host registers while a block runs:
//      x19 = JitContext*, w20 = A, w21 = X, w22 = Y, w23 = SP,
//      w24 = N/Z source (Z iff (w24 & 0xFF) == 0, N iff (w24 & 0x180) != 0),
//      w25 = C (0/1), w26 = V (0/1), w27 = I/D bits (0x04 | 0x08), w28 = cycles.
//  * Flags are kept in registers (not NZCV), so helper calls never clobber them.
//  * RAM accesses with a statically known address are inlined; everything else
//    goes through the helper functions in JitContext (bus, PPU, APU, mapper).
//  * Opcodes that are not translated (BRK and unofficial opcodes) end the block
//    before them so the caller can run them with the interpreter.
//  * The compiler is host-independent: it only produces AArch64 words. A
//    JitBackend decides where the code lives and how it is executed.
#include <cstddef>
#include <cstdint>
#include <limits>
#include <functional>
#include <memory>
#include <vector>

namespace nes::jit {

// Shared between generated code and the host. Layout is part of the ABI.
struct JitContext {
    uint64_t ram;       // 0   address of the 2 KiB CPU RAM, as seen by generated code
    uint64_t read_fn;   // 8   uint8_t (*)(JitContext*, uint32_t addr)
    uint64_t write_fn;  // 16  void (*)(JitContext*, uint32_t addr, uint32_t value)
    uint64_t host;      // 24  opaque pointer for the helper functions
    uint64_t chain;     // 32  table of 65536 block addresses indexed by 6502 pc (block chaining)
    uint32_t a, x, y, sp, p, pc; // 40..60
    uint32_t cycles;    // 64  cycles consumed since entry (flushed at helper calls)
    uint32_t stop;      // 68  set by helpers: leave the block after the current instruction
    uint32_t tmp0;      // 72
    uint32_t tmp1;      // 76
    uint32_t budget;    // 80  cycles generated code may run before returning to the host
};

constexpr uint32_t kCtxRam = 0, kCtxRead = 8, kCtxWrite = 16, kCtxChain = 32, kCtxA = 40, kCtxX = 44, kCtxY = 48,
                   kCtxSp = 52, kCtxP = 56, kCtxPc = 60, kCtxCycles = 64, kCtxStop = 68, kCtxTmp0 = 72,
                   kCtxBudget = 80;
static_assert(offsetof(JitContext, ram) == kCtxRam && offsetof(JitContext, read_fn) == kCtxRead &&
              offsetof(JitContext, write_fn) == kCtxWrite && offsetof(JitContext, a) == kCtxA &&
              offsetof(JitContext, x) == kCtxX && offsetof(JitContext, y) == kCtxY &&
              offsetof(JitContext, sp) == kCtxSp && offsetof(JitContext, p) == kCtxP &&
              offsetof(JitContext, pc) == kCtxPc && offsetof(JitContext, cycles) == kCtxCycles &&
              offsetof(JitContext, stop) == kCtxStop && offsetof(JitContext, tmp0) == kCtxTmp0 &&
              offsetof(JitContext, chain) == kCtxChain && offsetof(JitContext, budget) == kCtxBudget,
              "JitContext layout is baked into generated code");

struct BlockInfo {
    std::vector<uint32_t> code;   // AArch64 instruction words
    uint16_t start_pc = 0;
    unsigned instructions = 0;    // number of 6502 instructions translated
    uint32_t max_cycles = 0;      // upper bound of the CPU cycles one run of the block can take
};

// Entry/exit trampolines. entry(ctx = x0, block = x1) loads the 6502 state from the
// context, resets cycles/stop and jumps to the block; blocks leave through the exit
// trampoline (w0 = next pc) which stores the state back and returns to the caller.
struct Thunks {
    std::vector<uint32_t> code;
    size_t exit_offset_bytes = 0;
};
Thunks build_thunks(uint64_t base_address);

using FetchFn = std::function<uint8_t(uint16_t)>;

// Translates the block starting at `pc`. Returns false when no instruction could be
// translated (the caller should interpret that instruction instead).
// With `chain` the block starts with a cycle-budget check and static/dynamic exits jump straight to the
// next translated block through JitContext::chain instead of returning to the host.
bool compile_block(uint16_t pc, const FetchFn& fetch, uint64_t code_address, uint64_t exit_address,
                   BlockInfo& out, bool chain = false);

// Host side of the helper calls made by generated code.
class JitHost {
public:
    virtual ~JitHost() = default;
    // `ctx.cycles` holds the cycles consumed by the block before the current instruction.
    virtual uint8_t jit_read(JitContext& ctx, uint16_t address) = 0;
    virtual void jit_write(JitContext& ctx, uint16_t address, uint8_t value) = 0;
};

// Where generated code lives and how it runs (native mmap on ARM64, an emulator in tests).
class JitBackend {
public:
    virtual ~JitBackend() = default;
    virtual size_t capacity_bytes() const = 0;
    virtual uint64_t code_base() const = 0;
    // Copies words to code_base()+offset and makes them executable.
    virtual bool write_code(size_t offset_bytes, const uint32_t* words, size_t count) = 0;
    // Address of the CPU RAM and of the two helper entry points as seen by generated code.
    virtual uint64_t ram_address() = 0;
    virtual uint64_t read_helper_address() = 0;
    virtual uint64_t write_helper_address() = 0;
    // Chain table: 65536 entries of block addresses indexed by 6502 pc, readable by generated code.
    virtual uint64_t chain_table_address() = 0;
    virtual void set_chain_entry(uint16_t pc, uint64_t target) = 0;
    virtual void reset_chain(uint64_t target) = 0;
    // Runs entry(ctx, block). `ctx` is read before and updated after the run.
    virtual void execute(JitContext& ctx, uint64_t entry_address, uint64_t block_address) = 0;
    // Called with every helper invocation target; the native backend uses real functions.
    virtual void set_host(JitHost* host) = 0;
};

// Block cache + code pool on top of a backend.
class Jit6502 {
public:
    Jit6502(std::unique_ptr<JitBackend> backend, JitHost* host, FetchFn fetch, bool chain = true);
    bool ok() const { return ok_; }
    // Returns true and fills the CPU state when a block for `pc` was executed.
    // On return `ctx.pc` is the next pc and `ctx.cycles` the cycles consumed.
    // `horizon` is the number of cycles until the next interrupt-raising event; blocks that could
    // run past it are not executed (returns false) so the interpreter handles that stretch exactly.
    bool run_block(JitContext& ctx, unsigned* instructions = nullptr, uint32_t horizon = std::numeric_limits<uint32_t>::max());
    void invalidate_all() { flush_pending_ = true; }
    void prepare_context(JitContext& ctx);
    size_t compiled_blocks() const { return compiled_; }
    size_t flushes() const { return flushes_; }

private:
    struct Entry { uint64_t address = 0; uint16_t instructions = 0; uint32_t max_cycles = 0; bool uncompilable = false; };
    void flush(bool rewind_pool);
    std::unique_ptr<JitBackend> backend_;
    JitHost* host_;
    FetchFn fetch_;
    bool ok_ = false;
    bool chain_ = true;
    bool flush_pending_ = false;
    size_t used_bytes_ = 0;
    size_t thunk_bytes_ = 0;
    uint64_t entry_address_ = 0;
    uint64_t exit_address_ = 0;
    std::vector<Entry> table_; // indexed by pc - 0x8000
    size_t compiled_ = 0, flushes_ = 0;
};

} // namespace nes::jit
