#pragma once
// Native (in-process) JIT backend for AArch64 hosts: generated code is stored in an
// anonymous mapping that is writable while compiling and executable while running.
#include "jit6502.h"

#include <memory>

namespace nes::jit {

// Returns nullptr when the host cannot execute generated AArch64 code (non-ARM64 build,
// or the OS refused an executable mapping). `ram` is the 2 KiB CPU RAM used by inlined accesses.
std::unique_ptr<JitBackend> make_native_backend(uint8_t* ram);

} // namespace nes::jit
