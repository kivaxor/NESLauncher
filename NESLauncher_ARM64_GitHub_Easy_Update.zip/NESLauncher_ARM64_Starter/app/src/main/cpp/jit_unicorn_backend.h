#pragma once
// Test-only JIT backend that executes the generated AArch64 code inside the Unicorn
// CPU emulator, so the recompiler can be verified on any host (including x86 CI).
#include "jit6502.h"

#include <unicorn/unicorn.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace nes::jit {

class UnicornBackend : public JitBackend {
public:
    static constexpr uint64_t kCode = 0x10000000, kCodeSize = 1u << 20;
    static constexpr uint64_t kCtx = 0x20000000, kRam = 0x20001000, kDataSize = 0x4000;
    static constexpr uint64_t kStack = 0x30000000, kStackSize = 0x10000;
    static constexpr uint64_t kHelper = 0x40000000, kEnd = 0x50000000;

    // `ram` is the host CPU RAM (2 KiB) mirrored into the emulator around every run and helper call.
    explicit UnicornBackend(uint8_t* ram) : ram_(ram) {
        check(uc_open(UC_ARCH_ARM64, UC_MODE_ARM, &uc_), "uc_open");
        check(uc_mem_map(uc_, kCode, kCodeSize, UC_PROT_ALL), "map code");
        check(uc_mem_map(uc_, kCtx, kDataSize, UC_PROT_READ | UC_PROT_WRITE), "map data");
        check(uc_mem_map(uc_, kStack, kStackSize, UC_PROT_READ | UC_PROT_WRITE), "map stack");
        check(uc_mem_map(uc_, kHelper, 0x1000, UC_PROT_ALL), "map helper");
        check(uc_mem_map(uc_, kEnd, 0x1000, UC_PROT_ALL), "map end");
        const uint32_t ret = 0xD65F03C0u;
        check(uc_mem_write(uc_, kHelper, &ret, 4), "helper ret");
        check(uc_mem_write(uc_, kHelper + 16, &ret, 4), "helper ret");
        uc_hook h;
        check(uc_hook_add(uc_, &h, UC_HOOK_CODE, reinterpret_cast<void*>(&UnicornBackend::on_code), this, kHelper, kHelper + 32), "hook");
    }
    ~UnicornBackend() override { uc_close(uc_); }

    size_t capacity_bytes() const override { return kCodeSize; }
    uint64_t code_base() const override { return kCode; }
    bool write_code(size_t offset, const uint32_t* words, size_t count) override {
        if (uc_mem_write(uc_, kCode + offset, words, count * 4) != UC_ERR_OK) return false;
        // Translated host code only needs discarding when previously executed addresses are rewritten.
        // (uc_ctl_remove_cache is avoided: it can crash inside Unicorn for large ranges.)
        // After a flush nothing above the rewritten block has been translated yet, so it becomes the new mark.
        if (offset < high_water_) { uc_ctl_flush_tb(uc_); high_water_ = offset + count * 4; }
        else high_water_ = offset + count * 4;
        return true;
    }
    uint64_t ram_address() override { return kRam; }
    uint64_t read_helper_address() override { return kHelper; }
    uint64_t write_helper_address() override { return kHelper + 16; }
    void set_host(JitHost* host) override { host_ = host; }

    void execute(JitContext& ctx, uint64_t entry, uint64_t block) override {
        ram_to_guest();
        check(uc_mem_write(uc_, kCtx, &ctx, sizeof ctx), "write ctx");
        uint64_t x0 = kCtx, x1 = block, sp = kStack + kStackSize - 64, lr = kEnd;
        uc_reg_write(uc_, UC_ARM64_REG_X0, &x0);
        uc_reg_write(uc_, UC_ARM64_REG_X1, &x1);
        uc_reg_write(uc_, UC_ARM64_REG_SP, &sp);
        uc_reg_write(uc_, UC_ARM64_REG_X30, &lr);
        const uc_err err = uc_emu_start(uc_, entry, kEnd, 0, 2000000);
        if (err != UC_ERR_OK) {
            std::fprintf(stderr, "unicorn error: %s (entry %llx block %llx)\n", uc_strerror(err),
                         static_cast<unsigned long long>(entry), static_cast<unsigned long long>(block));
            std::abort();
        }
        check(uc_mem_read(uc_, kCtx, &ctx, sizeof ctx), "read ctx");
        ram_to_host();
    }

private:
    static void check(uc_err e, const char* what) {
        if (e != UC_ERR_OK) { std::fprintf(stderr, "unicorn %s failed: %s\n", what, uc_strerror(e)); std::abort(); }
    }
    void ram_to_guest() { check(uc_mem_write(uc_, kRam, ram_, 2048), "ram->guest"); }
    void ram_to_host() { check(uc_mem_read(uc_, kRam, ram_, 2048), "ram->host"); }

    static void on_code(uc_engine* uc, uint64_t address, uint32_t, void* user) {
        auto* self = static_cast<UnicornBackend*>(user);
        JitContext ctx;
        uc_mem_read(uc, kCtx, &ctx, sizeof ctx);
        uint64_t x1 = 0, x2 = 0;
        uc_reg_read(uc, UC_ARM64_REG_X1, &x1);
        uc_reg_read(uc, UC_ARM64_REG_X2, &x2);
        self->ram_to_host();
        if (address == kHelper) {
            const uint8_t v = self->host_->jit_read(ctx, static_cast<uint16_t>(x1));
            uint64_t x0 = v;
            uc_reg_write(uc, UC_ARM64_REG_X0, &x0);
        } else if (address == kHelper + 16) {
            self->host_->jit_write(ctx, static_cast<uint16_t>(x1), static_cast<uint8_t>(x2));
        }
        self->ram_to_guest();
        uc_mem_write(uc, kCtx + kCtxStop, &ctx.stop, 4);
    }

    uc_engine* uc_ = nullptr;
    size_t high_water_ = 0;
    uint8_t* ram_;
    JitHost* host_ = nullptr;
};

} // namespace nes::jit
