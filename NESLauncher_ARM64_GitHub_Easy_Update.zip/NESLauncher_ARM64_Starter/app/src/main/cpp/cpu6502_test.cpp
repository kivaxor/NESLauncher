#include "cpu6502.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
    // Bus RAM mirrors every 2 KiB through $1FFF.
    nes::CpuBus bus;
    bus.write(0x0003, 0x5A);
    assert(bus.read(0x0803) == 0x5A);
    assert(bus.read(0x1803) == 0x5A);

    // LDA #$10; ADC #$05; STA $02; INX; NOP
    bus.load(0x6000, {0xA9,0x10,0x69,0x05,0x85,0x02,0xE8,0xEA});
    bus.set_reset_vector(0x6000);
    nes::Cpu6502 cpu(bus);
    cpu.reset();
    assert(cpu.pc() == 0x6000);
    assert(cpu.step() == 2 && cpu.a() == 0x10);
    assert(cpu.step() == 2 && cpu.a() == 0x15);
    assert(cpu.step() == 3 && bus.read(0x0002) == 0x15);
    assert(cpu.step() == 2 && cpu.x() == 1);
    assert(cpu.step() == 2 && cpu.pc() == 0x6008);

    // Zero and negative flags, compare, and branch taken.
    bus.load(0x6100, {0xA9,0x00,0xC9,0x00,0xF0,0x02,0xA9,0x7F,0xA9,0x80});
    cpu.set_state(0x6100,0,0,0,0xFD,0x24);
    assert(cpu.step() == 2 && (cpu.status() & 0x02));
    assert(cpu.step() == 2 && (cpu.status() & 0x01) && (cpu.status() & 0x02));
    assert(cpu.step() == 3 && cpu.pc() == 0x6108);
    assert(cpu.step() == 2 && cpu.a() == 0x80 && (cpu.status() & 0x80));

    // Indexed absolute page crossing adds a cycle for a read instruction.
    bus.write(0x00FF, 0x11);
    bus.write(0x0100, 0x22);
    bus.load(0x6200, {0xBD,0xFF,0x00}); // LDA $00FF,X
    cpu.set_state(0x6200,0,1,0,0xFD,0x24);
    assert(cpu.step() == 5 && cpu.a() == 0x22);

    // Indirect-indexed reads must add one cycle when Y crosses a page.
    // Pointer $10/$11 contains $00FF; Y=1 reads from $0100.
    bus.write(0x0010, 0xFF);
    bus.write(0x0011, 0x00);
    bus.write(0x0100, 0x01);
    const uint8_t indirect_y_reads[] = {0x11, 0x31, 0x51, 0x71, 0xD1, 0xF1};
    for (const uint8_t opcode : indirect_y_reads) {
        bus.load(0x6210, {opcode, 0x10});
        cpu.set_state(0x6210, 0x00, 0x00, 0x01, 0xFD, 0x25);
        assert(cpu.step() == 6);
    }

    // JSR/RTS stack round-trip.
    bus.load(0x6300, {0x20,0x06,0x63,0xA9,0x44,0xEA,0xA9,0x33,0x60});
    cpu.set_state(0x6300,0,0,0,0xFD,0x24);
    assert(cpu.step() == 6 && cpu.pc() == 0x6306);
    assert(cpu.step() == 2 && cpu.a() == 0x33);
    assert(cpu.step() == 6 && cpu.pc() == 0x6303);
    assert(cpu.step() == 2 && cpu.a() == 0x44);

    // Zero-page indexed addressing wraps within page zero.
    bus.write(0x0000, 0xA7);
    bus.write(0x00FF, 0x31);
    bus.load(0x6400, {0xB5,0xFF}); // LDA $FF,X with X=1 -> $00
    cpu.set_state(0x6400,0,1,0,0xFD,0x24);
    assert(cpu.step() == 4 && cpu.a() == 0xA7);

    // NMOS 6502 JMP indirect wraps the high-byte read inside the same page.
    bus.write(0x02FF, 0x34);
    bus.write(0x0200, 0x12);
    bus.write(0x0300, 0x99);
    bus.load(0x6500, {0x6C,0xFF,0x02}); // JMP ($02FF) -> $1234, not $9934
    cpu.set_state(0x6500,0,0,0,0xFD,0x24);
    assert(cpu.step() == 5 && cpu.pc() == 0x1234);

    // NMI is serviced before the next opcode and pushes the interrupted PC.
    bus.set_vector(0xFFFA, 0x7000);
    bus.load(0x6600, {0xEA});
    cpu.set_state(0x6600,0,0,0,0xFD,0x24);
    cpu.request_nmi();
    assert(cpu.step() == 7 && cpu.pc() == 0x7000 && cpu.sp() == 0xFA);
    assert(bus.read(0x01FD) == 0x66 && bus.read(0x01FC) == 0x00);
    assert((bus.read(0x01FB) & 0x10) == 0); // B flag is clear in hardware interrupt stack copy.

    // IRQ remains pending while I is set, then is serviced after CLI.
    bus.set_vector(0xFFFE, 0x7100);
    bus.load(0x6700, {0x58,0xEA}); // CLI; NOP
    cpu.set_state(0x6700,0,0,0,0xFD,0x24);
    cpu.request_irq();
    assert(cpu.step() == 2 && cpu.pc() == 0x6701);
    assert(cpu.step() == 7 && cpu.pc() == 0x7100);

    // ADC overflow and carry are independent; $7F + $01 => $80 with V set.
    bus.load(0x6800, {0xA9,0x7F,0x18,0x69,0x01});
    cpu.set_state(0x6800,0,0,0,0xFD,0x24);
    assert(cpu.step() == 2 && cpu.a() == 0x7F);
    assert(cpu.step() == 2 && (cpu.status() & 1) == 0);
    assert(cpu.step() == 2 && cpu.a() == 0x80);
    assert((cpu.status() & 0x40) != 0 && (cpu.status() & 0x80) != 0 && (cpu.status() & 1) == 0);

    std::cout << "CPU 6502 tests passed\n";
    return 0;
}
