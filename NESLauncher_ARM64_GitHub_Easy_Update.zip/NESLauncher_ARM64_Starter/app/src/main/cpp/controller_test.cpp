#include "cpu6502.h"

#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    nes::CpuBus bus;
    // NES serial order: A, B, Select, Start, Up, Down, Left, Right.
    constexpr uint8_t buttons = 0b10100101;
    bus.set_controller_state(0, buttons);
    bus.write(0x4016, 1);
    assert((bus.read(0x4016) & 1U) == 1U); // A while strobe is high.
    bus.write(0x4016, 0);                 // Falling edge latches the state.
    for (unsigned bit = 0; bit < 8; ++bit) {
        assert((bus.read(0x4016) & 1U) == ((buttons >> bit) & 1U));
    }
    // Reads after eight buttons return 1, as on the NES controller port.
    assert((bus.read(0x4016) & 1U) == 1U);

    bus.set_controller_state(1, 0b00000010);
    bus.write(0x4016, 1);
    bus.write(0x4016, 0);
    assert((bus.read(0x4017) & 1U) == 0U); // Player 2 A
    assert((bus.read(0x4017) & 1U) == 1U); // Player 2 B
    assert((bus.read(0x4017) & 0x40U) != 0U);
    std::cout << "NES controller tests passed\n";
}
