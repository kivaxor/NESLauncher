#include "cpu6502.h"

#include <atomic>
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    nes::CpuBus bus;
    // NES serial order: A, B, Select, Start, Up, Down, Left, Right.
    constexpr uint8_t buttons = 0b10100101;
    bus.set_controller_state(0, buttons);
    bus.write(0x4016, 1);
    assert((bus.read(0x4016) & 1U) == 1U); // A while strobe is high.
    bus.write(0x4016, 0);                 // Falling edge latches the state.
    for (unsigned bit = 0; bit < 8; ++bit) {
        assert((bus.read(0x4016) & 1U) == ((buttons >> bit) & 1U));
    }
    // Reads after eight buttons return 1, as on the NES controller port.
    assert((bus.read(0x4016) & 1U) == 1U);

    bus.set_controller_state(1, 0b00000010);
    bus.write(0x4016, 1);
    bus.write(0x4016, 0);
    assert((bus.read(0x4017) & 1U) == 0U); // Player 2 A
    assert((bus.read(0x4017) & 1U) == 1U); // Player 2 B
    assert((bus.read(0x4017) & 0x40U) != 0U);
    // Live source: the bus samples it when the game polls, so a value changed after the last push
    // (for example by a UI thread) is still seen by the very next strobe/read.
    {
        nes::CpuBus live;
        std::atomic<uint8_t> src0{0}, src1{0};
        live.set_controller_source(0, &src0);
        live.set_controller_source(1, &src1);
        live.set_controller_state(0, 0xFF); // stale pushed value must not win over the source
        src0.store(0b00000110);             // B + Select
        src1.store(0b00000001);             // player 2: A
        live.write(0x4016, 1);
        live.write(0x4016, 0);
        for (unsigned bit = 0; bit < 8; ++bit) assert((live.read(0x4016) & 1U) == ((0b00000110U >> bit) & 1U));
        assert((live.read(0x4017) & 1U) == 1U);
        // Strobe held high: reads follow the source as it changes.
        live.write(0x4016, 1);
        src0.store(0);
        assert((live.read(0x4016) & 1U) == 0U);
        src0.store(1);
        assert((live.read(0x4016) & 1U) == 1U);
        live.write(0x4016, 0);
        // Reset keeps the source attached.
        live.reset();
        src0.store(0b10000000);
        live.write(0x4016, 1);
        live.write(0x4016, 0);
        for (unsigned bit = 0; bit < 7; ++bit) assert((live.read(0x4016) & 1U) == 0U);
        assert((live.read(0x4016) & 1U) == 1U);
    }
    std::cout << "NES controller tests passed\n";
}
