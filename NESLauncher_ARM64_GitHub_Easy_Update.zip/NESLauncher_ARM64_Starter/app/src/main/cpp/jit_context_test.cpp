#include "jit6502.h"
#include <cstdio>
#include <map>
using namespace nes::jit;
struct Host : JitHost { uint8_t jit_read(JitContext&, uint16_t) override { return 0; } void jit_write(JitContext&, uint16_t, uint8_t) override {} };
struct Stub : JitBackend {
    unsigned slots; unsigned slot = 0; size_t writes = 0; std::map<unsigned, size_t> chain_sets;
    explicit Stub(unsigned s) : slots(s) {}
    size_t capacity_bytes() const override { return 1u << 20; }
    uint64_t code_base() const override { return 0x10000000; }
    bool write_code(size_t, const uint32_t*, size_t) override { ++writes; return true; }
    uint64_t ram_address() override { return 0; }
    uint64_t read_helper_address() override { return 0; }
    uint64_t write_helper_address() override { return 0; }
    uint64_t chain_table_address() override { return 0x60000000 + slot * 0x80000; }
    void set_chain_entry(uint16_t, uint64_t) override { ++chain_sets[slot]; }
    void reset_chain(uint64_t) override {}
    unsigned chain_slots() const override { return slots; }
    void select_chain_slot(unsigned s) override { slot = s; }
    void execute(JitContext& c, uint64_t, uint64_t) override { c.cycles = 2; }
    void set_host(JitHost*) override {}
};
static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
int main() {
    Host host;
    // ROM bytes: bank sig 1 -> LDA #1 ; sig 2 -> LDA #2 (blok berbeda), keduanya berakhir NOP-loop
    uint32_t sig = 1;
    auto fetch = [&](uint16_t a) -> uint8_t { uint8_t code[] = {0xA9, uint8_t(sig), 0x4C, 0x00, 0x80}; return code[(a - 0x8000) % 5]; };
    for (unsigned slots : {1u, 8u}) {
        auto be = std::make_unique<Stub>(slots);
        Stub* raw = be.get();
        Jit6502 jit(std::move(be), &host, fetch, true);
        CHECK(jit.ok());
        JitContext ctx{};
        auto run = [&](uint32_t s) { sig = s; jit.select_mapping(s); ctx.pc = 0x8000; jit.run_block(ctx, nullptr, 1000); };
        run(1); run(2); run(1); run(2); run(1);
        std::printf("slots=%u compiled=%zu switches=%zu reuses=%zu flushes=%zu\n", slots, jit.compiled_blocks(), jit.mapping_switches(), jit.mapping_reuses(), jit.flushes());
        if (slots == 8) { CHECK(jit.compiled_blocks() == 2); CHECK(jit.mapping_reuses() == 3); CHECK(jit.flushes() == 0); }
        else { CHECK(jit.compiled_blocks() == 5); CHECK(jit.mapping_reuses() == 0); }
        // invalidate_all menghapus semua konteks
        jit.invalidate_all(); run(1);
        CHECK(jit.flushes() == 1);
        (void)raw;
    }
    // LRU: 9 mapping berbeda pada 8 slot, lalu kembali ke yang paling baru tetap hit
    {
        auto be = std::make_unique<Stub>(8);
        Jit6502 jit(std::move(be), &host, fetch, true);
        JitContext ctx{};
        auto run = [&](uint32_t s) { sig = s; jit.select_mapping(s); ctx.pc = 0x8000; jit.run_block(ctx, nullptr, 1000); };
        for (uint32_t s = 10; s < 19; ++s) run(s);
        size_t before = jit.compiled_blocks();
        run(18); CHECK(jit.compiled_blocks() == before);   // terbaru masih ada
        run(10); CHECK(jit.compiled_blocks() == before + 1); // tertua sudah terbuang
    }
    std::printf(fails ? "GAGAL\n" : "OK\n");
    return fails;
}
