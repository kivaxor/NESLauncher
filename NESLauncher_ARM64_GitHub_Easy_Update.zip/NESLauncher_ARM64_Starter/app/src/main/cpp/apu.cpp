#include "apu.h"

#include <algorithm>

namespace nes {
namespace {
constexpr std::array<uint8_t, 32> kLength = {
    10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
    12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30};
constexpr uint8_t kDuty[4][8] = {{0, 1, 0, 0, 0, 0, 0, 0}, {0, 1, 1, 0, 0, 0, 0, 0},
                                 {0, 1, 1, 1, 1, 0, 0, 0}, {1, 0, 0, 1, 1, 1, 1, 1}};
constexpr uint8_t kTriangle[32] = {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
                                   0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
constexpr uint16_t kNoisePeriod[16] = {4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068};
constexpr uint16_t kDmcRate[16] = {428, 380, 340, 320, 286, 254, 226, 214, 190, 160, 142, 128, 106, 84, 72, 54};

// Standard non-linear mixer lookup tables (nesdev "APU Mixer").
struct MixTables {
    float pulse[31];
    float tnd[203];
    MixTables() {
        pulse[0] = 0.0f;
        for (int i = 1; i < 31; ++i) pulse[i] = 95.88f / (8128.0f / static_cast<float>(i) + 100.0f);
        tnd[0] = 0.0f;
        for (int i = 1; i < 203; ++i) tnd[i] = 163.67f / (24329.0f / static_cast<float>(i) + 100.0f);
    }
};
const MixTables kMix;
}

Apu::Apu(uint32_t sample_rate) : sample_rate_(sample_rate == 0 ? 44100 : sample_rate) { reset(); }

void Apu::reset() {
    pulse_[0] = Pulse{};
    pulse_[1] = Pulse{};
    pulse_[0].ones_complement = true; // Pulse 1 negates with one's complement; pulse 2 with two's.
    triangle_ = Triangle{};
    noise_ = Noise{};
    dmc_ = Dmc{};
    mix_sum_ = 0.0;
    mix_count_ = 0;
    five_step_ = irq_inhibit_ = frame_irq_ = false;
    frame_cycle_ = 0;
    cycle_ = 0;
    sample_accum_ = 0.0;
    hp_prev_in_ = hp_prev_out_ = 0.0f;
    samples_.clear();
}

uint8_t Apu::Pulse::output() const {
    if (!enabled || length == 0 || timer_period < 8) return 0;
    if (!kDuty[duty][seq]) return 0;
    // The sweep unit mutes the channel when its target period would overflow.
    const uint16_t delta = static_cast<uint16_t>(timer_period >> sweep_shift);
    if (!sweep_negate && static_cast<uint32_t>(timer_period) + delta > 0x7FF) return 0;
    return constant ? volume : decay;
}
void Apu::Pulse::clock_timer() {
    if (timer == 0) { timer = timer_period; seq = static_cast<uint8_t>((seq + 1) & 7); }
    else --timer;
}
void Apu::Pulse::clock_envelope() {
    if (start) { start = false; decay = 15; divider = volume; return; }
    if (divider == 0) {
        divider = volume;
        if (decay > 0) --decay; else if (loop) decay = 15;
    } else --divider;
}
void Apu::Pulse::clock_length() { if (!loop && length > 0) --length; }
void Apu::Pulse::clock_sweep() {
    const uint16_t delta = static_cast<uint16_t>(timer_period >> sweep_shift);
    uint32_t target = timer_period;
    if (sweep_negate) target = timer_period - delta - (ones_complement ? 1 : 0);
    else target = timer_period + delta;
    if (sweep_div == 0 && sweep_enable && sweep_shift > 0 && timer_period >= 8 && target <= 0x7FF)
        timer_period = static_cast<uint16_t>(target);
    if (sweep_div == 0 || sweep_reload) { sweep_div = sweep_period; sweep_reload = false; }
    else --sweep_div;
}

uint8_t Apu::Triangle::output() const {
    if (!enabled || length == 0 || linear == 0 || timer_period < 2) return 0;
    return kTriangle[seq];
}
void Apu::Triangle::clock_timer() {
    if (timer == 0) {
        timer = timer_period;
        if (length > 0 && linear > 0) seq = static_cast<uint8_t>((seq + 1) & 31);
    } else --timer;
}

uint8_t Apu::Noise::output() const {
    if (!enabled || length == 0 || (shift & 1)) return 0;
    return constant ? volume : decay;
}
void Apu::Noise::clock_timer() {
    if (timer == 0) {
        timer = timer_period;
        const uint16_t bit = static_cast<uint16_t>((shift & 1) ^ ((shift >> (mode ? 6 : 1)) & 1));
        shift = static_cast<uint16_t>((shift >> 1) | (bit << 14));
    } else --timer;
}

void Apu::write(uint16_t address, uint8_t value) {
    if (address >= 0x4000 && address <= 0x4007) {
        Pulse& p = pulse_[(address >> 2) & 1];
        switch (address & 3) {
        case 0:
            p.duty = value >> 6; p.loop = (value & 0x20) != 0; p.constant = (value & 0x10) != 0;
            p.volume = value & 0x0F; break;
        case 1:
            p.sweep_enable = (value & 0x80) != 0; p.sweep_period = (value >> 4) & 7;
            p.sweep_negate = (value & 0x08) != 0; p.sweep_shift = value & 7; p.sweep_reload = true; break;
        case 2: p.timer_period = static_cast<uint16_t>((p.timer_period & 0x700) | value); break;
        default:
            p.timer_period = static_cast<uint16_t>((p.timer_period & 0x0FF) | ((value & 7) << 8));
            if (p.enabled) p.length = kLength[value >> 3];
            p.seq = 0; p.start = true; break;
        }
        return;
    }
    switch (address) {
    case 0x4008: triangle_.control = (value & 0x80) != 0; triangle_.linear_period = value & 0x7F; break;
    case 0x400A: triangle_.timer_period = static_cast<uint16_t>((triangle_.timer_period & 0x700) | value); break;
    case 0x400B:
        triangle_.timer_period = static_cast<uint16_t>((triangle_.timer_period & 0x0FF) | ((value & 7) << 8));
        if (triangle_.enabled) triangle_.length = kLength[value >> 3];
        triangle_.reload = true; break;
    case 0x400C:
        noise_.loop = (value & 0x20) != 0; noise_.constant = (value & 0x10) != 0; noise_.volume = value & 0x0F; break;
    case 0x400E: noise_.mode = (value & 0x80) != 0; noise_.timer_period = kNoisePeriod[value & 0x0F]; break;
    case 0x400F:
        if (noise_.enabled) noise_.length = kLength[value >> 3];
        noise_.start = true; break;
    case 0x4010:
        dmc_.irq_enable = (value & 0x80) != 0;
        dmc_.loop = (value & 0x40) != 0;
        dmc_.rate = kDmcRate[value & 0x0F];
        if (!dmc_.irq_enable) dmc_.irq_flag = false;
        break;
    case 0x4011: dmc_.level = value & 0x7F; break;
    case 0x4012: dmc_.sample_addr = static_cast<uint16_t>(0xC000 | (static_cast<uint16_t>(value) << 6)); break;
    case 0x4013: dmc_.length = static_cast<uint16_t>((static_cast<uint16_t>(value) << 4) | 1U); break;
    case 0x4015:
        pulse_[0].enabled = (value & 1) != 0; pulse_[1].enabled = (value & 2) != 0;
        triangle_.enabled = (value & 4) != 0; noise_.enabled = (value & 8) != 0;
        if (!pulse_[0].enabled) pulse_[0].length = 0;
        if (!pulse_[1].enabled) pulse_[1].length = 0;
        if (!triangle_.enabled) triangle_.length = 0;
        if (!noise_.enabled) noise_.length = 0;
        dmc_.irq_flag = false;
        if ((value & 0x10) != 0) {
            if (dmc_.remaining == 0) dmc_restart();
            dmc_fetch();
        } else {
            dmc_.remaining = 0;
        }
        break;
    case 0x4017:
        five_step_ = (value & 0x80) != 0; irq_inhibit_ = (value & 0x40) != 0;
        if (irq_inhibit_) frame_irq_ = false;
        frame_cycle_ = 0;
        if (five_step_) { clock_frame_quarter(); clock_frame_half(); }
        break;
    default: break;
    }
}

uint8_t Apu::read_status() {
    uint8_t v = 0;
    if (pulse_[0].length) v |= 1;
    if (pulse_[1].length) v |= 2;
    if (triangle_.length) v |= 4;
    if (noise_.length) v |= 8;
    if (dmc_.remaining) v |= 0x10;
    if (dmc_.irq_flag) v |= 0x80;
    if (frame_irq_) v |= 0x40;
    frame_irq_ = false;
    return v;
}

void Apu::clock_frame_quarter() {
    for (auto& p : pulse_) p.clock_envelope();
    if (noise_.start) { noise_.start = false; noise_.decay = 15; noise_.divider = noise_.volume; }
    else if (noise_.divider == 0) {
        noise_.divider = noise_.volume;
        if (noise_.decay > 0) --noise_.decay; else if (noise_.loop) noise_.decay = 15;
    } else --noise_.divider;
    if (triangle_.reload) triangle_.linear = triangle_.linear_period;
    else if (triangle_.linear > 0) --triangle_.linear;
    if (!triangle_.control) triangle_.reload = false;
}

void Apu::clock_frame_half() {
    for (auto& p : pulse_) { p.clock_length(); p.clock_sweep(); }
    if (!triangle_.control && triangle_.length > 0) --triangle_.length;
    if (!noise_.loop && noise_.length > 0) --noise_.length;
}

float Apu::mix() const {
    const unsigned p = static_cast<unsigned>(pulse_[0].output()) + pulse_[1].output();
    const unsigned t = 3U * triangle_.output() + 2U * noise_.output() + dmc_.level;
    return kMix.pulse[p] + kMix.tnd[t];
}

void Apu::dmc_restart() {
    dmc_.addr = dmc_.sample_addr;
    dmc_.remaining = dmc_.length;
}

void Apu::dmc_fetch() {
    if (dmc_.has_buffer || dmc_.remaining == 0 || !dmc_read_) return;
    dmc_.buffer = dmc_read_(dmc_.addr);
    dmc_.has_buffer = true;
    dmc_.addr = static_cast<uint16_t>((dmc_.addr + 1U) | 0x8000U);
    if (--dmc_.remaining == 0) {
        if (dmc_.loop) dmc_restart();
        else if (dmc_.irq_enable) dmc_.irq_flag = true; // flag only; the CPU IRQ line is not driven
    }
}

void Apu::clock_dmc() {
    if (--dmc_.timer != 0) return;
    dmc_.timer = dmc_.rate;
    if (!dmc_.silence) {
        if ((dmc_.shift & 1U) != 0) { if (dmc_.level <= 125) dmc_.level = static_cast<uint8_t>(dmc_.level + 2); }
        else if (dmc_.level >= 2) dmc_.level = static_cast<uint8_t>(dmc_.level - 2);
    }
    dmc_.shift = static_cast<uint8_t>(dmc_.shift >> 1);
    if (--dmc_.bits == 0) {
        dmc_.bits = 8;
        if (dmc_.has_buffer) {
            dmc_.silence = false;
            dmc_.shift = dmc_.buffer;
            dmc_.has_buffer = false;
            dmc_fetch();
        } else {
            dmc_.silence = true;
        }
    }
}

void Apu::tick() {
    // Triangle runs at CPU rate; pulse and noise at every other CPU cycle.
    triangle_.clock_timer();
    if ((cycle_ & 1U) == 0) { pulse_[0].clock_timer(); pulse_[1].clock_timer(); noise_.clock_timer(); }
    ++cycle_;
    // Frame counter in CPU cycles (NTSC).
    ++frame_cycle_;
    if (!five_step_) {
        switch (frame_cycle_) {
        case 7457: clock_frame_quarter(); break;
        case 14913: clock_frame_quarter(); clock_frame_half(); break;
        case 22371: clock_frame_quarter(); break;
        case 29829: clock_frame_quarter(); clock_frame_half(); if (!irq_inhibit_) frame_irq_ = true; break;
        case 29830: frame_cycle_ = 0; break;
        default: break;
        }
    } else {
        switch (frame_cycle_) {
        case 7457: clock_frame_quarter(); break;
        case 14913: clock_frame_quarter(); clock_frame_half(); break;
        case 22371: clock_frame_quarter(); break;
        case 37281: clock_frame_quarter(); clock_frame_half(); break;
        case 37282: frame_cycle_ = 0; break;
        default: break;
        }
    }
}

void Apu::clock_cpu_cycles(uint32_t cycles) {
    const double step = static_cast<double>(sample_rate_) / static_cast<double>(kCpuHz);
    while (cycles-- > 0) {
        tick();
        clock_dmc();
        mix_sum_ += static_cast<double>(mix());
        ++mix_count_;
        sample_accum_ += step;
        if (sample_accum_ >= 1.0) {
            sample_accum_ -= 1.0;
            // Box filter: average every CPU-cycle mix in this output period (anti-aliasing).
            const float in = static_cast<float>(mix_sum_ / static_cast<double>(mix_count_));
            mix_sum_ = 0.0;
            mix_count_ = 0;
            // Simple one-pole high-pass removes DC offset, like the console's output stage.
            const float out = in - hp_prev_in_ + 0.996f * hp_prev_out_;
            hp_prev_in_ = in;
            hp_prev_out_ = out;
            const float scaled = std::clamp(out * 32000.0f, -32767.0f, 32767.0f);
            if (samples_.size() < 16384) samples_.push_back(static_cast<int16_t>(scaled));
        }
    }
}

size_t Apu::take_samples(std::vector<int16_t>& out) {
    const size_t n = samples_.size();
    out.insert(out.end(), samples_.begin(), samples_.end());
    samples_.clear();
    return n;
}

} // namespace nes
