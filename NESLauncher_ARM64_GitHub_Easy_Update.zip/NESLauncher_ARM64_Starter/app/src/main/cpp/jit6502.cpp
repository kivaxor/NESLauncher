#include "jit6502.h"

#include "a64.h"
#include "cpu6502.h"

#include <algorithm>
#include <cassert>

namespace nes::jit {
namespace {

using Op = Cpu6502::Op;
using Mode = Cpu6502::Mode;
using Instruction = Cpu6502::Instruction;

// Host register assignment (see jit6502.h).
constexpr uint32_t kCtx = 19, kA = 20, kX = 21, kY = 22, kSP = 23, kNZ = 24, kC = 25, kV = 26, kID = 27, kCyc = 28;
constexpr size_t kMaxBlockInstructions = 48;

struct Operand {
    enum Kind { None, Static, DynZp, DynAny } kind = None;
    uint16_t value = 0; // Static address
};

// ---- shared flag helpers --------------------------------------------------------
// Packs the register-resident flags into the 6502 P byte (bit 5 set, B clear).
void pack_p(Asm& a, uint32_t dst) {
    a.tst_imm(kNZ, 0xFF);
    a.cset(4, EQ);
    a.lsl_imm(4, 4, 1);          // Z << 1
    a.tst_imm(kNZ, 0x180);
    a.cset(5, NE);
    a.lsl_imm(5, 5, 7);          // N << 7
    a.orr_reg(4, 4, 5);
    a.orr_reg(4, 4, kC);
    a.orr_reg(4, 4, kV, 6);      // V << 6
    a.orr_reg(4, 4, kID);
    a.orr_imm(dst, 4, 0x20);
}

// Unpacks the P byte held in w`src` into the flag registers. Clobbers w3..w5.
void unpack_p(Asm& a, uint32_t src) {
    a.and_imm(kC, src, 1);
    a.ubfx(kV, src, 6, 1);
    a.and_imm(kID, src, 0x0C);
    a.and_imm(3, src, 0x80);      // N bit
    a.mov_imm(4, 1);
    a.cmp_imm(3, 0);
    a.csel(5, 3, 4, NE);          // Z=0: N ? 0x80 : 1
    a.lsl_imm(3, 3, 1);           // Z=1: N ? 0x100 : 0
    a.tst_imm(src, 2);
    a.csel(kNZ, 3, 5, NE);
}

class Compiler {
public:
    Compiler(const FetchFn& fetch, uint64_t code_address, uint64_t exit_address, bool chain)
        : fetch_(fetch), a_(code_address), exit_address_(exit_address), chain_(chain) {}

    bool run(uint16_t start_pc, BlockInfo& out) {
        const auto& table = Cpu6502::table();
        start_pc_ = start_pc;
        start_label_ = a_.new_label();
        a_.bind(start_label_);
        Asm::Label slow_entry = a_.new_label();
        size_t budget_add = 0;
        if (chain_) {
            // Prologue: leave for the host when this block could run past the cycle budget
            // (the next interrupt-raising event), so the interpreter handles that stretch exactly.
            a_.ldr_w(1, kCtx, kCtxBudget);
            budget_add = a_.size();
            a_.add_imm(2, kCyc, 0); // immediate patched with max_cycles below
            a_.cmp(2, 1);
            a_.b_cond(HI, slow_entry);
        }
        uint32_t cur = start_pc;
        unsigned count = 0;
        bool terminated = false;
        while (count < kMaxBlockInstructions && cur <= 0xFFFC) {
            const uint8_t opcode = fetch_(static_cast<uint16_t>(cur));
            const Instruction& ins = table[opcode];
            if (ins.op == Op::Ill || ins.op == Op::BRK) break;
            const uint32_t size = instruction_size(ins.mode);
            const uint8_t b1 = size > 1 ? fetch_(static_cast<uint16_t>(cur + 1)) : 0;
            const uint8_t b2 = size > 2 ? fetch_(static_cast<uint16_t>(cur + 2)) : 0;
            terminated = emit_instruction(ins, static_cast<uint16_t>(cur), b1, b2);
            ++count;
            cur += size;
            if (terminated) break;
        }
        if (count == 0) return false;
        if (!terminated) exit_static(static_cast<uint16_t>(cur), 0);
        for (const Stub& s : stubs_) {
            a_.bind(s.label);
            exit_static_with(s.next_pc, s.cycles, false);
        }
        if (chain_) {
            a_.bind(slow_entry);
            a_.mov_imm(0, start_pc);
            a_.b_abs(exit_address_);
            a_.patch(budget_add, 0x11000000u | (max_cycles_ << 10) | (kCyc << 5) | 2u); // add w2, w28, #max_cycles
        }
        out.start_pc = start_pc;
        out.instructions = count;
        out.max_cycles = max_cycles_;
        out.code = a_.take();
        return true;
    }

private:
    struct Stub { Asm::Label label; uint16_t next_pc; uint32_t cycles; };

    static uint32_t instruction_size(Mode m) {
        switch (m) {
        case Mode::Imp: case Mode::Acc: return 1;
        case Mode::Abs: case Mode::AbsX: case Mode::AbsY: case Mode::Ind: return 3;
        default: return 2;
        }
    }

    // ---- exits ----------------------------------------------------------------
    // Jumps to the translated block of the pc in w0 (or to the host exit when there is none yet).
    void chain_jump() {
        a_.ldr_x(2, kCtx, kCtxChain);
        a_.ldr_x_uxtw3(1, 2, 0);
        a_.br(1);
    }
    // `chainable` exits may continue directly in the next block; the others return to the host
    // (stop requests, and instructions after which interrupts must be re-evaluated).
    void exit_static_with(uint16_t next_pc, uint32_t cycles, bool chainable = true) {
        if (cycles) a_.add_imm(kCyc, kCyc, cycles);
        if (chain_ && chainable && next_pc == start_pc_) { a_.b(start_label_); return; }
        a_.mov_imm(0, next_pc);
        if (chain_ && chainable) chain_jump(); else a_.b_abs(exit_address_);
    }
    void exit_static(uint16_t next_pc, uint32_t extra, bool chainable = true) {
        exit_static_with(next_pc, pending_ + extra, chainable);
        pending_ = 0;
    }
    void exit_dynamic(uint32_t extra, bool chainable = true) { // pc already in w0
        const uint32_t cycles = pending_ + extra;
        if (cycles) a_.add_imm(kCyc, kCyc, cycles);
        if (chain_ && chainable) chain_jump(); else a_.b_abs(exit_address_);
        pending_ = 0;
    }

    // ---- memory access --------------------------------------------------------
    void flush_cycles() {
        if (pending_) { a_.add_imm(kCyc, kCyc, pending_); pending_ = 0; }
    }
    void call_read() { // w1 = address -> w0
        flush_cycles();
        a_.str_w(kCyc, kCtx, kCtxCycles);
        a_.mov_x(0, kCtx);
        a_.ldr_x(16, kCtx, kCtxRead);
        a_.blr(16);
        a_.and_imm(0, 0, 0xFF);
    }
    void call_write() { // w1 = address, w2 = value
        flush_cycles();
        a_.str_w(kCyc, kCtx, kCtxCycles);
        a_.mov_x(0, kCtx);
        a_.ldr_x(16, kCtx, kCtxWrite);
        a_.blr(16);
    }
    void read_operand(const Operand& op) { // -> w0
        switch (op.kind) {
        case Operand::Static:
            if (op.value < 0x2000) {
                a_.ldr_x(2, kCtx, kCtxRam);
                a_.ldrb_imm(0, 2, op.value & 0x7FF);
            } else {
                a_.mov_imm(1, op.value);
                call_read();
                if (op.value < 0x6000) risky_ = true;
            }
            break;
        case Operand::DynZp:
            a_.ldr_x(2, kCtx, kCtxRam);
            a_.ldrb_reg_uxtw(0, 2, 1);
            break;
        case Operand::DynAny:
            call_read();
            risky_ = true;
            break;
        case Operand::None: break;
        }
    }
    void write_operand(const Operand& op) { // value in w2; DynAny/DynZp address in w1
        switch (op.kind) {
        case Operand::Static:
            if (op.value < 0x2000) {
                a_.ldr_x(3, kCtx, kCtxRam);
                a_.strb_imm(2, 3, op.value & 0x7FF);
            } else {
                a_.mov_imm(1, op.value);
                call_write();
                risky_ = true;
            }
            break;
        case Operand::DynZp:
            a_.ldr_x(3, kCtx, kCtxRam);
            a_.strb_reg_uxtw(2, 3, 1);
            break;
        case Operand::DynAny:
            call_write();
            risky_ = true;
            break;
        case Operand::None: break;
        }
    }

    // Computes the effective address. For dynamic modes it is left in w1.
    Operand address(const Instruction& ins, uint8_t b1, uint8_t b2, bool store) {
        Operand op;
        const uint16_t abs = static_cast<uint16_t>(b1 | (b2 << 8));
        switch (ins.mode) {
        case Mode::Zp: op.kind = Operand::Static; op.value = b1; break;
        case Mode::Abs: op.kind = Operand::Static; op.value = abs; break;
        case Mode::ZpX: case Mode::ZpY:
            a_.add_imm(1, ins.mode == Mode::ZpX ? kX : kY, b1);
            a_.and_imm(1, 1, 0xFF);
            op.kind = Operand::DynZp;
            break;
        case Mode::AbsX: case Mode::AbsY: {
            const uint32_t reg = ins.mode == Mode::AbsX ? kX : kY;
            a_.mov_imm(1, abs);
            a_.add(1, 1, reg);
            a_.and_imm(1, 1, 0xFFFF);
            if (ins.page_cycle && !store && (abs & 0xFF) != 0) {
                a_.mov_imm(2, abs & 0xFF);
                a_.add(2, 2, reg);
                a_.lsr_imm(2, 2, 8);
                a_.add(kCyc, kCyc, 2);
            }
            op.kind = Operand::DynAny;
            break;
        }
        case Mode::XInd:
            a_.add_imm(1, kX, b1);
            a_.and_imm(1, 1, 0xFF);
            a_.ldr_x(3, kCtx, kCtxRam);
            a_.ldrb_reg_uxtw(0, 3, 1);
            a_.add_imm(1, 1, 1);
            a_.and_imm(1, 1, 0xFF);
            a_.ldrb_reg_uxtw(2, 3, 1);
            a_.orr_reg(1, 0, 2, 8);
            op.kind = Operand::DynAny;
            break;
        case Mode::IndY:
            a_.ldr_x(3, kCtx, kCtxRam);
            a_.ldrb_imm(0, 3, b1);
            a_.ldrb_imm(2, 3, (b1 + 1) & 0xFF);
            a_.orr_reg(1, 0, 2, 8);
            a_.add(1, 1, kY);
            a_.and_imm(1, 1, 0xFFFF);
            if (ins.page_cycle && !store) {
                a_.add(2, 0, kY);
                a_.lsr_imm(2, 2, 8);
                a_.add(kCyc, kCyc, 2);
            }
            op.kind = Operand::DynAny;
            break;
        default: break;
        }
        return op;
    }

    // ---- stack ----------------------------------------------------------------
    void stack_base() { a_.ldr_x(3, kCtx, kCtxRam); a_.add_imm_x(3, 3, 0x100); }
    void push(uint32_t reg) { // needs stack_base() in x3
        a_.strb_reg_uxtw(reg, 3, kSP);
        a_.sub_imm(kSP, kSP, 1);
        a_.and_imm(kSP, kSP, 0xFF);
    }
    void pull(uint32_t dst) {
        a_.add_imm(kSP, kSP, 1);
        a_.and_imm(kSP, kSP, 0xFF);
        a_.ldrb_reg_uxtw(dst, 3, kSP);
    }

    // ---- arithmetic -----------------------------------------------------------
    void adc_w0() { // A += w0 + C
        a_.add(3, kA, 0);
        a_.add(3, 3, kC);
        a_.eor_reg(4, kA, 3);
        a_.eor_reg(5, 0, 3);
        a_.and_reg(4, 4, 5);
        a_.ubfx(kV, 4, 7, 1);
        a_.lsr_imm(kC, 3, 8);
        a_.and_imm(kA, 3, 0xFF);
        a_.mov(kNZ, kA);
    }
    void compare_w0(uint32_t reg) {
        a_.cmp(reg, 0);
        a_.cset(kC, HS);
        a_.sub(3, reg, 0);
        a_.and_imm(kNZ, 3, 0xFF);
    }
    // Shift/rotate of value register `r`; result in kNZ.
    void shift_op(Op op, uint32_t r) {
        switch (op) {
        case Op::ASL: a_.lsr_imm(kC, r, 7); a_.lsl_imm(3, r, 1); a_.and_imm(kNZ, 3, 0xFF); break;
        case Op::LSR: a_.and_imm(kC, r, 1); a_.lsr_imm(kNZ, r, 1); break;
        case Op::ROL: a_.lsl_imm(3, r, 1); a_.orr_reg(3, 3, kC); a_.lsr_imm(kC, r, 7); a_.and_imm(kNZ, 3, 0xFF); break;
        case Op::ROR: a_.lsl_imm(4, kC, 7); a_.lsr_imm(3, r, 1); a_.orr_reg(kNZ, 3, 4); a_.and_imm(kC, r, 1); break;
        default: assert(false);
        }
    }

    // Returns true when the instruction terminates the block.
    bool emit_instruction(const Instruction& ins, uint16_t pc, uint8_t b1, uint8_t b2) {
        risky_ = false;
        max_cycles_ += ins.cycles + (ins.mode == Mode::Rel ? 2u : (ins.page_cycle ? 1u : 0u));
        const Op op = ins.op;
        const bool store = op == Op::STA || op == Op::STX || op == Op::STY;
        bool terminator = false;

        auto finish = [&]() {
            pending_ += ins.cycles;
            if (risky_ && !terminator) {
                const uint16_t next = static_cast<uint16_t>(pc + instruction_size(ins.mode));
                Asm::Label l = a_.new_label();
                a_.ldr_w(0, kCtx, kCtxStop);
                a_.cbnz(0, l);
                stubs_.push_back({l, next, pending_});
            }
        };

        switch (op) {
        // ---- loads -----------------------------------------------------------
        case Op::LDA: case Op::LDX: case Op::LDY: {
            load_value(ins, b1, b2);
            const uint32_t dst = op == Op::LDA ? kA : (op == Op::LDX ? kX : kY);
            a_.mov(dst, 0);
            a_.mov(kNZ, 0);
            break;
        }
        // ---- stores ----------------------------------------------------------
        case Op::STA: case Op::STX: case Op::STY: {
            const Operand o = address(ins, b1, b2, true);
            a_.mov(2, op == Op::STA ? kA : (op == Op::STX ? kX : kY));
            write_operand(o);
            break;
        }
        // ---- ALU -------------------------------------------------------------
        case Op::AND: load_value(ins, b1, b2); a_.and_reg(kA, kA, 0); a_.mov(kNZ, kA); break;
        case Op::ORA: load_value(ins, b1, b2); a_.orr_reg(kA, kA, 0); a_.mov(kNZ, kA); break;
        case Op::EOR: load_value(ins, b1, b2); a_.eor_reg(kA, kA, 0); a_.mov(kNZ, kA); break;
        case Op::ADC: load_value(ins, b1, b2); adc_w0(); break;
        case Op::SBC: load_value(ins, b1, b2); a_.eor_imm(0, 0, 0xFF); adc_w0(); break;
        case Op::CMP: load_value(ins, b1, b2); compare_w0(kA); break;
        case Op::CPX: load_value(ins, b1, b2); compare_w0(kX); break;
        case Op::CPY: load_value(ins, b1, b2); compare_w0(kY); break;
        case Op::BIT:
            load_value(ins, b1, b2);
            a_.and_reg(3, kA, 0);
            a_.and_imm(4, 0, 0x80);
            a_.orr_reg(5, 3, 4);
            a_.lsl_imm(6, 4, 1);
            a_.cmp_imm(3, 0);
            a_.csel(kNZ, 6, 5, EQ);
            a_.ubfx(kV, 0, 6, 1);
            break;
        case Op::ASL: case Op::LSR: case Op::ROL: case Op::ROR:
            if (ins.mode == Mode::Acc) {
                shift_op(op, kA);
                a_.mov(kA, kNZ);
            } else {
                rmw(ins, b1, b2, [&]() { shift_op(op, 0); });
            }
            break;
        case Op::INC: rmw(ins, b1, b2, [&]() { a_.add_imm(3, 0, 1); a_.and_imm(kNZ, 3, 0xFF); }); break;
        case Op::DEC: rmw(ins, b1, b2, [&]() { a_.sub_imm(3, 0, 1); a_.and_imm(kNZ, 3, 0xFF); }); break;
        case Op::INX: a_.add_imm(kX, kX, 1); a_.and_imm(kX, kX, 0xFF); a_.mov(kNZ, kX); break;
        case Op::INY: a_.add_imm(kY, kY, 1); a_.and_imm(kY, kY, 0xFF); a_.mov(kNZ, kY); break;
        case Op::DEX: a_.sub_imm(kX, kX, 1); a_.and_imm(kX, kX, 0xFF); a_.mov(kNZ, kX); break;
        case Op::DEY: a_.sub_imm(kY, kY, 1); a_.and_imm(kY, kY, 0xFF); a_.mov(kNZ, kY); break;
        // ---- transfers / flags ----------------------------------------------
        case Op::TAX: a_.mov(kX, kA); a_.mov(kNZ, kA); break;
        case Op::TAY: a_.mov(kY, kA); a_.mov(kNZ, kA); break;
        case Op::TXA: a_.mov(kA, kX); a_.mov(kNZ, kX); break;
        case Op::TYA: a_.mov(kA, kY); a_.mov(kNZ, kY); break;
        case Op::TSX: a_.mov(kX, kSP); a_.mov(kNZ, kSP); break;
        case Op::TXS: a_.mov(kSP, kX); break;
        case Op::CLC: a_.mov_imm(kC, 0); break;
        case Op::SEC: a_.mov_imm(kC, 1); break;
        case Op::CLV: a_.mov_imm(kV, 0); break;
        case Op::CLD: a_.and_imm(kID, kID, 0xFFFFFFF7u); break;
        case Op::SED: a_.orr_imm(kID, kID, 0x08); break;
        case Op::SEI: a_.orr_imm(kID, kID, 0x04); break;
        case Op::CLI: a_.and_imm(kID, kID, 0xFFFFFFFBu); terminator = true; break;
        case Op::NOP: break;
        // ---- stack -----------------------------------------------------------
        case Op::PHA: stack_base(); push(kA); break;
        case Op::PHP: pack_p(a_, 6); a_.orr_imm(6, 6, 0x10); stack_base(); push(6); break;
        case Op::PLA: stack_base(); pull(kA); a_.mov(kNZ, kA); break;
        case Op::PLP: stack_base(); pull(0); unpack_p(a_, 0); terminator = true; break;
        // ---- control flow ----------------------------------------------------
        case Op::JMP:
            if (ins.mode == Mode::Abs) {
                pending_ += ins.cycles;
                exit_static(static_cast<uint16_t>(b1 | (b2 << 8)), 0);
                return true;
            } else {
                const uint16_t base = static_cast<uint16_t>(b1 | (b2 << 8));
                const uint16_t hi_addr = static_cast<uint16_t>((base & 0xFF00) | ((base + 1) & 0xFF));
                Operand lo; lo.kind = Operand::Static; lo.value = base;
                Operand hi; hi.kind = Operand::Static; hi.value = hi_addr;
                read_operand(lo);
                a_.str_w(0, kCtx, kCtxTmp0);
                read_operand(hi);
                a_.ldr_w(1, kCtx, kCtxTmp0);
                a_.orr_reg(0, 1, 0, 8);
                pending_ += ins.cycles;
                exit_dynamic(0);
                return true;
            }
        case Op::JSR: {
            const uint16_t ret = static_cast<uint16_t>(pc + 2);
            stack_base();
            a_.mov_imm(4, ret >> 8);
            push(4);
            a_.mov_imm(4, ret & 0xFF);
            push(4);
            pending_ += ins.cycles;
            exit_static(static_cast<uint16_t>(b1 | (b2 << 8)), 0);
            return true;
        }
        case Op::RTS:
            stack_base();
            pull(4);
            pull(5);
            a_.orr_reg(0, 4, 5, 8);
            a_.add_imm(0, 0, 1);
            a_.and_imm(0, 0, 0xFFFF);
            pending_ += ins.cycles;
            exit_dynamic(0);
            return true;
        case Op::RTI:
            stack_base();
            pull(0);
            unpack_p(a_, 0);
            stack_base();
            pull(4);
            pull(5);
            a_.orr_reg(0, 4, 5, 8);
            pending_ += ins.cycles;
            exit_dynamic(0, false); // the I flag changed: let the host re-check pending interrupts
            return true;
        case Op::BCC: case Op::BCS: case Op::BEQ: case Op::BMI: case Op::BNE: case Op::BPL: case Op::BVC: case Op::BVS: {
            const uint16_t next = static_cast<uint16_t>(pc + 2);
            const uint16_t target = static_cast<uint16_t>(next + static_cast<int8_t>(b1));
            const bool crossed = (next & 0xFF00) != (target & 0xFF00);
            Asm::Label taken = a_.new_label();
            switch (op) {
            case Op::BEQ: a_.tst_imm(kNZ, 0xFF); a_.b_cond(EQ, taken); break;
            case Op::BNE: a_.tst_imm(kNZ, 0xFF); a_.b_cond(NE, taken); break;
            case Op::BMI: a_.tst_imm(kNZ, 0x180); a_.b_cond(NE, taken); break;
            case Op::BPL: a_.tst_imm(kNZ, 0x180); a_.b_cond(EQ, taken); break;
            case Op::BCS: a_.cbnz(kC, taken); break;
            case Op::BCC: a_.cbz(kC, taken); break;
            case Op::BVS: a_.cbnz(kV, taken); break;
            default:      a_.cbz(kV, taken); break; // BVC
            }
            exit_static_with(next, pending_ + 2);
            a_.bind(taken);
            exit_static_with(target, pending_ + 3 + (crossed ? 1 : 0));
            pending_ = 0;
            return true;
        }
        default:
            assert(false && "opcode not handled by the recompiler");
            break;
        }
        (void)store;
        finish();
        if (terminator) {
            // CLI / PLP: leave the block so pending IRQs are re-evaluated.
            const uint16_t next = static_cast<uint16_t>(pc + instruction_size(ins.mode));
            exit_static(next, 0, false);
        }
        return terminator;
    }

    // Loads the operand value of a read instruction into w0.
    void load_value(const Instruction& ins, uint8_t b1, uint8_t b2) {
        if (ins.mode == Mode::Imm) { a_.mov_imm(0, b1); return; }
        const Operand o = address(ins, b1, b2, false);
        read_operand(o);
    }

    // Read-modify-write of memory: value in w0, `body` leaves the result in kNZ.
    template <typename Body>
    void rmw(const Instruction& ins, uint8_t b1, uint8_t b2, Body body) {
        const Operand o = address(ins, b1, b2, true);
        if (o.kind == Operand::DynAny) a_.str_w(1, kCtx, kCtxTmp0);
        read_operand(o);
        if (o.kind == Operand::DynAny) a_.ldr_w(1, kCtx, kCtxTmp0);
        body();
        a_.mov(2, kNZ);
        write_operand(o);
    }

    const FetchFn& fetch_;
    Asm a_;
    uint64_t exit_address_;
    bool chain_;
    uint16_t start_pc_ = 0;
    Asm::Label start_label_;
    uint32_t pending_ = 0;
    uint32_t max_cycles_ = 0;
    bool risky_ = false;
    std::vector<Stub> stubs_;
};

} // namespace

Thunks build_thunks(uint64_t base_address) {
    Asm a(base_address);
    // entry(x0 = ctx, x1 = block)
    a.stp_x_pre(29, 30, 31, -96);
    a.stp_x(19, 20, 31, 16);
    a.stp_x(21, 22, 31, 32);
    a.stp_x(23, 24, 31, 48);
    a.stp_x(25, 26, 31, 64);
    a.stp_x(27, 28, 31, 80);
    a.mov_x(kCtx, 0);
    a.mov_x(16, 1);
    a.ldr_w(kA, kCtx, kCtxA);
    a.ldr_w(kX, kCtx, kCtxX);
    a.ldr_w(kY, kCtx, kCtxY);
    a.ldr_w(kSP, kCtx, kCtxSp);
    a.ldr_w(0, kCtx, kCtxP);
    unpack_p(a, 0);
    a.mov_imm(kCyc, 0);
    a.str_w(31, kCtx, kCtxStop);
    a.br(16);
    // exit(w0 = next pc)
    const size_t exit_index = a.size();
    a.str_w(0, kCtx, kCtxPc);
    a.str_w(kA, kCtx, kCtxA);
    a.str_w(kX, kCtx, kCtxX);
    a.str_w(kY, kCtx, kCtxY);
    a.str_w(kSP, kCtx, kCtxSp);
    pack_p(a, 6);
    a.str_w(6, kCtx, kCtxP);
    a.str_w(kCyc, kCtx, kCtxCycles);
    a.ldp_x(19, 20, 31, 16);
    a.ldp_x(21, 22, 31, 32);
    a.ldp_x(23, 24, 31, 48);
    a.ldp_x(25, 26, 31, 64);
    a.ldp_x(27, 28, 31, 80);
    a.ldp_x_post(29, 30, 31, 96);
    a.ret();
    Thunks t;
    t.exit_offset_bytes = exit_index * 4;
    t.code = a.take();
    return t;
}

bool compile_block(uint16_t pc, const FetchFn& fetch, uint64_t code_address, uint64_t exit_address, BlockInfo& out, bool chain) {
    Compiler c(fetch, code_address, exit_address, chain);
    return c.run(pc, out);
}

// ---- Jit6502 ----------------------------------------------------------------------
Jit6502::Jit6502(std::unique_ptr<JitBackend> backend, JitHost* host, FetchFn fetch, bool chain)
    : backend_(std::move(backend)), host_(host), fetch_(std::move(fetch)), chain_(chain) {
    if (!backend_) return;
    backend_->set_host(host_);
    const uint64_t base = backend_->code_base();
    const Thunks thunks = build_thunks(base);
    thunk_bytes_ = thunks.code.size() * 4;
    if (thunk_bytes_ + 4096 > backend_->capacity_bytes()) return;
    if (!backend_->write_code(0, thunks.code.data(), thunks.code.size())) return;
    entry_address_ = base;
    exit_address_ = base + thunks.exit_offset_bytes;
    used_bytes_ = thunk_bytes_;
    table_.assign(0x8000, Entry{});
    backend_->reset_chain(exit_address_);
    ok_ = true;
}

// Forgets all translated blocks. The code pool is only rewound when it is exhausted, so stale blocks
// are simply left behind instead of rewriting memory that was already executed.
void Jit6502::flush(bool rewind_pool) {
    std::fill(table_.begin(), table_.end(), Entry{});
    backend_->reset_chain(exit_address_);
    if (rewind_pool) used_bytes_ = thunk_bytes_;
    flush_pending_ = false;
    ++flushes_;
}

bool Jit6502::run_block(JitContext& ctx, unsigned* instructions, uint32_t horizon) {
    if (!ok_ || ctx.pc < 0x8000 || ctx.pc > 0xFFFF) return false;
    if (flush_pending_) flush(false);
    Entry* e = &table_[ctx.pc - 0x8000];
    if (e->uncompilable) return false;
    if (e->address == 0) {
        BlockInfo info;
        const uint64_t base = backend_->code_base();
        bool compiled = compile_block(static_cast<uint16_t>(ctx.pc), fetch_, base + used_bytes_, exit_address_, info, chain_);
        if (compiled && used_bytes_ + info.code.size() * 4 > backend_->capacity_bytes()) {
            flush(true);
            e = &table_[ctx.pc - 0x8000];
            compiled = compile_block(static_cast<uint16_t>(ctx.pc), fetch_, base + used_bytes_, exit_address_, info, chain_);
        }
        if (!compiled) { e->uncompilable = true; return false; }
        if (!backend_->write_code(used_bytes_, info.code.data(), info.code.size())) {
            ok_ = false;
            return false;
        }
        e->address = base + used_bytes_;
        e->instructions = static_cast<uint16_t>(info.instructions);
        e->max_cycles = info.max_cycles;
        if (chain_) backend_->set_chain_entry(static_cast<uint16_t>(ctx.pc), base + used_bytes_);
        used_bytes_ += info.code.size() * 4;
        ++compiled_;
    }
    if (!chain_ && e->max_cycles > horizon) return false;
    ctx.budget = std::min<uint32_t>(horizon, 1u << 24);
    ctx.chain = backend_->chain_table_address();
    ctx.ram = backend_->ram_address();
    ctx.read_fn = backend_->read_helper_address();
    ctx.write_fn = backend_->write_helper_address();
    ctx.host = reinterpret_cast<uint64_t>(host_);
    if (instructions) *instructions = e->instructions;
    backend_->execute(ctx, entry_address_, e->address);
    // A block that bailed out in its budget check consumed nothing: the interpreter must run instead.
    return ctx.cycles != 0;
}

} // namespace nes::jit
