#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace nes {

enum class NametableMirroring : uint8_t {
    Horizontal, Vertical, FourScreen, SingleScreenLower, SingleScreenUpper
};

// Cartridge with simple discrete mappers: 0 (NROM), 1 (MMC1), 2 (UxROM),
// 3 (CNROM) and 7 (AxROM). Cartridge data is copied on load; the caller may
// release its input buffer.
class Cartridge {
public:
    static bool mapper_supported(uint16_t mapper);

    bool load_ines(const uint8_t* data, size_t size, std::string* error = nullptr);
    void unload();
    bool loaded() const { return loaded_; }
    uint16_t mapper() const { return loaded_ ? mapper_ : 0xFFFF; }
    NametableMirroring mirroring() const { return mirroring_; }
    bool has_battery() const { return battery_; }
    bool chr_is_ram() const { return chr_ram_; }

    bool cpu_read(uint16_t address, uint8_t& value) const;
    bool cpu_write(uint16_t address, uint8_t value);
    bool ppu_read(uint16_t address, uint8_t& value) const;
    bool ppu_write(uint16_t address, uint8_t value);

    // Battery-backed PRG RAM is exposed as an exact 8 KiB blob for host persistence.
    bool export_battery_ram(std::vector<uint8_t>& out) const;
    bool import_battery_ram(const uint8_t* data, size_t size, std::string* error = nullptr);

    const std::vector<uint8_t>& prg_rom() const { return prg_rom_; }
    const std::vector<uint8_t>& chr_memory() const { return chr_; }

private:
    size_t prg_offset(uint16_t address) const;
    size_t chr_offset(uint16_t address) const;
    void write_mmc1(uint16_t address, uint8_t value);
    void apply_mmc1_mirroring();
    void reset_mapper_state();

    bool loaded_ = false;
    bool battery_ = false;
    bool chr_ram_ = false;
    uint16_t mapper_ = 0;
    NametableMirroring mirroring_ = NametableMirroring::Horizontal;
    std::vector<uint8_t> prg_rom_;
    std::vector<uint8_t> chr_; // CHR ROM (any multiple of 8 KiB) or 8 KiB CHR RAM
    std::array<uint8_t, 8192> prg_ram_{};

    // Mapper registers.
    uint8_t prg_bank_ = 0;   // UxROM / AxROM
    uint8_t chr_bank_ = 0;   // CNROM
    uint8_t mmc1_shift_ = 0x10;
    uint8_t mmc1_control_ = 0x0C;
    uint8_t mmc1_chr0_ = 0;
    uint8_t mmc1_chr1_ = 0;
    uint8_t mmc1_prg_ = 0;
};

// Kept for existing code and tests that predate multi-mapper support.
using NromCartridge = Cartridge;

} // namespace nes
