#include "cpu6502.h"
#include "ppu2c02.h"

#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    nes::CpuBus bus;
    nes::Ppu2C02 ppu;
    bus.attach_ppu(&ppu);
    ppu.reset();
    bus.reset();

    for (uint16_t i = 0; i < 256; ++i)
        bus.write(i, static_cast<uint8_t>(i ^ 0xA5U));
    ppu.cpu_write_register(0x2003, 0x00);
    bus.write(0x4014, 0x00);

    // OAMADDR wraps after 256 bytes, so it points back to byte zero.
    for (uint16_t i = 0; i < 256; ++i) {
        ppu.cpu_write_register(0x2003, static_cast<uint8_t>(i));
        assert(ppu.cpu_read_register(0x2004) == static_cast<uint8_t>(i ^ 0xA5U));
    }
    assert(bus.take_dma_stall_cycles(false) == 513);
    assert(bus.take_dma_stall_cycles(false) == 0);

    // DMA from a different page and a nonzero OAM address must also wrap safely.
    for (uint16_t i = 0; i < 256; ++i)
        bus.write(static_cast<uint16_t>(0x0200 + i), static_cast<uint8_t>(255U - i));
    ppu.cpu_write_register(0x2003, 0x80);
    bus.write(0x4014, 0x02);
    for (uint16_t i = 0; i < 256; ++i) {
        ppu.cpu_write_register(0x2003, static_cast<uint8_t>(0x80U + i));
        assert(ppu.cpu_read_register(0x2004) == static_cast<uint8_t>(255U - i));
    }
    assert(bus.take_dma_stall_cycles(true) == 514);

    // Both DMA start alignments must produce their respective hardware stall.
    bus.write(0x4014, 0x00);
    assert(bus.take_dma_stall_cycles(false) == 513);
    bus.write(0x4014, 0x00);
    assert(bus.take_dma_stall_cycles(true) == 514);

    std::cout << "NES OAM DMA tests passed\n";
}
