#include "apu.h"
#include "nes_machine.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

static int peak(const std::vector<int16_t>& s) {
    int p = 0;
    for (int16_t x : s) p = std::max(p, std::abs(static_cast<int>(x)));
    return p;
}

int main() {
    // Silence when nothing is enabled.
    {
        nes::Apu apu(44100);
        apu.clock_cpu_cycles(20000);
        std::vector<int16_t> out;
        const size_t n = apu.take_samples(out);
        assert(n > 450 && n < 540); // 20000 CPU cycles at 44.1 kHz is about 493 samples
        assert(peak(out) == 0);
    }
    // Pulse 1 produces audible output and the length counter reports in $4015.
    {
        nes::Apu apu(44100);
        apu.write(0x4015, 0x01);
        apu.write(0x4000, 0xBF);
        apu.write(0x4002, 0xFD);
        apu.write(0x4003, 0x08);
        assert((apu.read_status() & 1) == 1);
        apu.clock_cpu_cycles(20000);
        std::vector<int16_t> out;
        apu.take_samples(out);
        assert(peak(out) > 1000);
        apu.write(0x4015, 0x00);
        assert((apu.read_status() & 1) == 0);
    }
    // Triangle and noise channels also reach the mixer.
    {
        nes::Apu apu(44100);
        apu.write(0x4015, 0x04);
        apu.write(0x4008, 0xFF);
        apu.write(0x400A, 0x40);
        apu.write(0x400B, 0x08);
        apu.write(0x4017, 0x80); // five-step mode clocks the linear counter immediately
        apu.clock_cpu_cycles(20000);
        std::vector<int16_t> out;
        apu.take_samples(out);
        assert(peak(out) > 500);

        nes::Apu noise(44100);
        noise.write(0x4015, 0x08);
        noise.write(0x400C, 0x3F);
        noise.write(0x400E, 0x02);
        noise.write(0x400F, 0x08);
        noise.clock_cpu_cycles(20000);
        out.clear();
        noise.take_samples(out);
        assert(peak(out) > 500);
    }
    // Length counter expires after enough half-frame clocks; frame IRQ and inhibit.
    {
        nes::Apu apu(44100);
        apu.write(0x4015, 0x01);
        apu.write(0x4000, 0x1F);   // halt clear, constant volume
        apu.write(0x4003, 0x18);   // length index 3 -> 2 half-frame clocks
        assert((apu.read_status() & 1) == 1);
        apu.clock_cpu_cycles(30000);
        assert(apu.frame_irq());
        const uint8_t status = apu.read_status();
        assert((status & 1) == 0 && (status & 0x40) != 0);
        assert(!apu.frame_irq()); // reading $4015 acknowledges the IRQ
        apu.clock_cpu_cycles(30000);
        assert(apu.frame_irq());
        apu.write(0x4017, 0x40);  // inhibit clears and blocks the IRQ
        assert(!apu.frame_irq());
        apu.clock_cpu_cycles(30000);
        assert(!apu.frame_irq());
    }
    // Machine integration: a ROM that starts pulse 1 yields audio every frame.
    {
        std::vector<uint8_t> rom(16 + 16384, 0xEA);
        rom[0] = 'N'; rom[1] = 'E'; rom[2] = 'S'; rom[3] = 0x1A; rom[4] = 1;
        std::fill(rom.begin() + 5, rom.begin() + 16, 0);
        const uint8_t code[] = {0xA9, 0x01, 0x8D, 0x15, 0x40, 0xA9, 0xBF, 0x8D, 0x00, 0x40,
                                0xA9, 0xFD, 0x8D, 0x02, 0x40, 0xA9, 0x08, 0x8D, 0x03, 0x40,
                                0x4C, 0x14, 0x80};
        std::copy(std::begin(code), std::end(code), rom.begin() + 16);
        rom[16 + 0x3FFC] = 0x00; rom[16 + 0x3FFD] = 0x80;
        nes::NesMachine machine(44100);
        std::string error;
        std::array<uint8_t, 256 * 240> frame{};
        assert(machine.load_rom(rom.data(), rom.size(), &error));
        for (int i = 0; i < 4; ++i) assert(machine.run_frame(frame, &error));
        std::vector<int16_t> out;
        const size_t n = machine.take_audio(out);
        assert(n > 1800 && n < 3500);
        assert(peak(out) > 1000);
        assert(machine.audio_sample_rate() == 44100);
    }
    // DMC plays PRG bytes through the reader, raises the level and finishes after its length.
    {
        nes::Apu apu(44100);
        int reads = 0;
        apu.set_dmc_reader([&reads](uint16_t address) {
            assert(address >= 0xC000);
            ++reads;
            return static_cast<uint8_t>(0xFF); // all ones: output level climbs
        });
        apu.write(0x4010, 0x0F); // fastest rate, no loop, no IRQ
        apu.write(0x4012, 0x00); // $C000
        apu.write(0x4013, 0x01); // 17 bytes
        apu.write(0x4015, 0x10);
        assert((apu.read_status() & 0x10) != 0);
        apu.clock_cpu_cycles(4000);
        std::vector<int16_t> out;
        apu.take_samples(out);
        assert(peak(out) > 100);
        apu.clock_cpu_cycles(20000);
        assert(reads == 17);
        assert((apu.read_status() & 0x10) == 0);
        // $4015 bit 4 clear stops playback immediately.
        apu.write(0x4015, 0x10);
        assert((apu.read_status() & 0x10) != 0);
        apu.write(0x4015, 0x00);
        assert((apu.read_status() & 0x10) == 0);
        // Direct load ($4011) sets the output level without playback.
        apu.write(0x4011, 0x40);
        apu.clock_cpu_cycles(2000);
    }
    // Rate adjust stretches output by the requested ratio (default 1.0 is exact).
    {
        nes::Apu a(48000), b(48000);
        b.set_rate_adjust(1.01);
        a.clock_cpu_cycles(1789773);
        b.clock_cpu_cycles(1789773);
        std::vector<int16_t> oa, ob;
        a.take_samples(oa);
        b.take_samples(ob);
        // The sample queue is capped; compare through a drained loop instead.
        size_t na = oa.size(), nb = ob.size();
        for (int i = 0; i < 59; ++i) {
            a.clock_cpu_cycles(29830); b.clock_cpu_cycles(29830);
            oa.clear(); ob.clear();
            a.take_samples(oa); b.take_samples(ob);
            na += oa.size(); nb += ob.size();
        }
        assert(nb > na);
        const double ratio = static_cast<double>(nb) / static_cast<double>(na);
        assert(ratio > 1.005 && ratio < 1.015);
        b.set_rate_adjust(5.0); // clamped to +2%
        b.set_rate_adjust(0.0); // clamped to -2%
    }
    std::cout << "APU tests passed\n";
}
