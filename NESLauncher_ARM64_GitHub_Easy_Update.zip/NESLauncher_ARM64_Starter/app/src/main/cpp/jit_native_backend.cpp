#include "jit_native_backend.h"

#if defined(__aarch64__) && (defined(__linux__) || defined(__ANDROID__))
#include <sys/mman.h>
#include <unistd.h>
#include <algorithm>
#include <cstring>
#include <vector>

namespace nes::jit {
namespace {

uint8_t read_helper(JitContext* ctx, uint32_t address) {
    return reinterpret_cast<JitHost*>(ctx->host)->jit_read(*ctx, static_cast<uint16_t>(address));
}
void write_helper(JitContext* ctx, uint32_t address, uint32_t value) {
    reinterpret_cast<JitHost*>(ctx->host)->jit_write(*ctx, static_cast<uint16_t>(address), static_cast<uint8_t>(value));
}

class NativeBackend : public JitBackend {
public:
    static constexpr size_t kCapacity = 8u << 20;
    static constexpr unsigned kSlots = 8;
    static constexpr size_t kChainEntries = 65536;

    explicit NativeBackend(uint8_t* ram) : ram_(ram) {
        page_ = static_cast<size_t>(sysconf(_SC_PAGESIZE));
        // Preferred: one read/write/execute mapping, so compiling a block costs a memcpy and a cache
        // flush instead of two mprotect() system calls. Falls back to toggling W^X per write.
        void* p = mmap(nullptr, kCapacity, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p != MAP_FAILED) {
            rwx_ = true;
        } else {
            p = mmap(nullptr, kCapacity, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        }
        if (p != MAP_FAILED) base_ = static_cast<uint8_t*>(p);
    }
    ~NativeBackend() override { if (base_) munmap(base_, kCapacity); }

    bool valid() const { return base_ != nullptr; }
    size_t capacity_bytes() const override { return base_ ? kCapacity : 0; }
    uint64_t code_base() const override { return reinterpret_cast<uint64_t>(base_); }

    bool write_code(size_t offset, const uint32_t* words, size_t count) override {
        const size_t bytes = count * 4;
        if (!base_ || offset + bytes > kCapacity) return false;
        if (rwx_) {
            std::memcpy(base_ + offset, words, bytes);
            __builtin___clear_cache(reinterpret_cast<char*>(base_ + offset), reinterpret_cast<char*>(base_ + offset + bytes));
            return true;
        }
        const size_t first = offset & ~(page_ - 1);
        const size_t last = (offset + bytes + page_ - 1) & ~(page_ - 1);
        // Pages are only ever written while not executing (single-threaded), so toggle W^X per write.
        if (mprotect(base_ + first, last - first, PROT_READ | PROT_WRITE) != 0) return false;
        std::memcpy(base_ + offset, words, bytes);
        __builtin___clear_cache(reinterpret_cast<char*>(base_ + offset), reinterpret_cast<char*>(base_ + offset + bytes));
        return mprotect(base_ + first, last - first, PROT_READ | PROT_EXEC) == 0;
    }

    uint64_t ram_address() override { return reinterpret_cast<uint64_t>(ram_); }
    uint64_t read_helper_address() override { return reinterpret_cast<uint64_t>(&read_helper); }
    uint64_t write_helper_address() override { return reinterpret_cast<uint64_t>(&write_helper); }
    void set_host(JitHost*) override {}
    unsigned chain_slots() const override { return kSlots; }
    void select_chain_slot(unsigned slot) override { slot_ = slot < kSlots ? slot : 0; }
    uint64_t chain_table_address() override { return reinterpret_cast<uint64_t>(chain_.data() + slot_ * kChainEntries); }
    void set_chain_entry(uint16_t pc, uint64_t target) override { chain_[slot_ * kChainEntries + pc] = target; }
    void reset_chain(uint64_t target) override {
        auto first = chain_.begin() + static_cast<std::ptrdiff_t>(slot_ * kChainEntries);
        std::fill(first, first + static_cast<std::ptrdiff_t>(kChainEntries), target);
    }

    void execute(JitContext& ctx, uint64_t entry, uint64_t block) override {
        using Entry = void (*)(JitContext*, uint64_t);
        reinterpret_cast<Entry>(entry)(&ctx, block);
    }

private:
    uint8_t* base_ = nullptr;
    uint8_t* ram_;
    std::vector<uint64_t> chain_ = std::vector<uint64_t>(kChainEntries * kSlots, 0);
    unsigned slot_ = 0;
    bool rwx_ = false;
    size_t page_ = 4096;
};

} // namespace

std::unique_ptr<JitBackend> make_native_backend(uint8_t* ram) {
    auto backend = std::make_unique<NativeBackend>(ram);
    if (!backend->valid()) return nullptr;
    return backend;
}

} // namespace nes::jit
#else
namespace nes::jit {
std::unique_ptr<JitBackend> make_native_backend(uint8_t*) { return nullptr; }
} // namespace nes::jit
#endif
