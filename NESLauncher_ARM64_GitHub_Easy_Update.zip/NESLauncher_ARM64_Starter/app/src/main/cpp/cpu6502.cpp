#include "cpu6502.h"
#include "cartridge.h"
#include "ppu2c02.h"
#include "apu.h"
#include <algorithm>
#include <cstddef>

namespace nes {
CpuBus::CpuBus() { reset(); }
void CpuBus::reset() {
    memory_.fill(0);
    ram.fill(0);
    prg_.fill(0);
    prg_size_ = 0;
    controller_live_.fill(0);
    controller_shift_.fill(0);
    controller_strobe_ = false;
    dma_transfers_pending_ = 0;
}
uint8_t CpuBus::read(uint16_t address) {
    if (address == 0x4015 && apu_) return apu_->read_status();
    if (address == 0x4016 || address == 0x4017) {
        const unsigned player = address - 0x4016;
        if (controller_strobe_) return static_cast<uint8_t>((controller_live_[player] & 1U) | 0x40U);
        const uint8_t bit = static_cast<uint8_t>(controller_shift_[player] & 1U);
        controller_shift_[player] = static_cast<uint8_t>((controller_shift_[player] >> 1) | 0x80U);
        return static_cast<uint8_t>(bit | 0x40U);
    }
    if (address >= 0x2000 && address < 0x4000 && ppu_)
        return ppu_->cpu_read_register(static_cast<uint16_t>(0x2000 | (address & 7)));
    uint8_t cartridge_value = 0;
    if (cartridge_ && cartridge_->cpu_read(address, cartridge_value)) return cartridge_value;
    if (address < 0x2000) return ram[address & 0x07FF];
    if (address >= 0x8000 && prg_size_) {
        const size_t offset = static_cast<size_t>(address - 0x8000);
        if (prg_size_ == 16384) return prg_[offset & 0x3FFF];
        return prg_[offset & 0x7FFF];
    }
    return memory_[address];
}
void CpuBus::write(uint16_t address, uint8_t value) {
    if (address == 0x4014 && ppu_) {
        // OAM DMA copies one CPU page into PPU OAM starting at the current OAMADDR.
        // The machine computes the 513/514-cycle stall after this instruction
        // returns, when its cycle length and estimated alignment are available.
        const uint16_t base = static_cast<uint16_t>(value) << 8;
        for (uint16_t offset = 0; offset < 256; ++offset) {
            const uint8_t byte = read(static_cast<uint16_t>(base | offset));
            ppu_->cpu_write_register(0x2004, byte);
        }
        ++dma_transfers_pending_;
        return;
    }
    if (address == 0x4016) {
        const bool next_strobe = (value & 1U) != 0;
        if (next_strobe || controller_strobe_) controller_shift_ = controller_live_;
        controller_strobe_ = next_strobe;
        return;
    }
    if (apu_ && ((address >= 0x4000 && address <= 0x4013) || address == 0x4015 || address == 0x4017)) {
        apu_->write(address, value);
        return;
    }
    if (address >= 0x2000 && address < 0x4000 && ppu_) {
        ppu_->cpu_write_register(static_cast<uint16_t>(0x2000 | (address & 7)), value);
        return;
    }
    if (cartridge_ && cartridge_->cpu_write(address, value)) return;
    if (address < 0x2000) ram[address & 0x07FF] = value;
    else if (address < 0x8000) memory_[address] = value; // PPU/APU/mapper I/O is wired later.
}
void CpuBus::load(uint16_t address, const std::vector<uint8_t>& bytes) {
    for (size_t i = 0; i < bytes.size() && static_cast<size_t>(address) + i < 65536; ++i)
        write(static_cast<uint16_t>(address + i), bytes[i]);
}
void CpuBus::map_prg_rom(const uint8_t* data, size_t size) {
    prg_size_ = (size == 16384 || size == 32768) ? size : 0;
    prg_.fill(0xFF);
    if (prg_size_ && data) std::copy(data, data + size, prg_.begin());
}
void CpuBus::set_controller_state(unsigned player, uint8_t buttons) {
    if (player >= controller_live_.size()) return;
    controller_live_[player] = buttons;
    if (controller_strobe_) controller_shift_[player] = buttons;
}
uint32_t CpuBus::take_dma_stall_cycles(bool odd_cpu_cycle) {
    const uint32_t transfers = dma_transfers_pending_;
    dma_transfers_pending_ = 0;
    if (transfers == 0) return 0;
    // NTSC OAM DMA takes 513 cycles on even alignment and 514 on odd alignment.
    // The instruction-stepped CPU supplies estimated parity, not bus-cycle truth.
    return transfers * (odd_cpu_cycle ? 514U : 513U);
}
void CpuBus::set_reset_vector(uint16_t address) { set_vector(0xFFFC, address); }
void CpuBus::set_vector(uint16_t vector, uint16_t address) {
    memory_[vector] = static_cast<uint8_t>(address);
    memory_[static_cast<uint16_t>(vector + 1)] = static_cast<uint8_t>(address >> 8);
}

Cpu6502::Cpu6502(CpuBus& bus) : bus_(bus) { reset(); }
void Cpu6502::reset() { a_=x_=y_=0; sp_=0xFD; p_=0x24; pc_=static_cast<uint16_t>(read(0xFFFC) | (read(0xFFFD)<<8)); nmi_pending_=irq_pending_=false; }
void Cpu6502::set_state(uint16_t pc,uint8_t a,uint8_t x,uint8_t y,uint8_t sp,uint8_t p) { pc_=pc;a_=a;x_=x;y_=y;sp_=sp;p_=static_cast<uint8_t>((p|0x20)&~0x10); }
void Cpu6502::request_nmi() { nmi_pending_=true; }
void Cpu6502::request_irq() { irq_pending_=true; }
uint8_t Cpu6502::fetch8() { return read(pc_++); }
uint16_t Cpu6502::fetch16() { const uint8_t lo=fetch8(); return static_cast<uint16_t>(lo | (fetch8()<<8)); }
void Cpu6502::push(uint8_t v) { write(static_cast<uint16_t>(0x100|sp_),v); --sp_; }
uint8_t Cpu6502::pull() { ++sp_; return read(static_cast<uint16_t>(0x100|sp_)); }
void Cpu6502::set_nz(uint8_t v) { p_=static_cast<uint8_t>((p_&~0x82) | (v==0?0x02:0) | (v&0x80)); }
void Cpu6502::compare(uint8_t lhs,uint8_t rhs) { const uint16_t d=static_cast<uint16_t>(lhs)-rhs; p_=static_cast<uint8_t>((p_&~0x83)|(lhs>=rhs?1:0)|((static_cast<uint8_t>(d)==0)?2:0)|(d&0x80)); }
void Cpu6502::interrupt(uint16_t vector,bool brk) { push(static_cast<uint8_t>(pc_>>8)); push(static_cast<uint8_t>(pc_)); push(static_cast<uint8_t>((p_|0x20)|(brk?0x10:0))); p_|=0x04; p_&=static_cast<uint8_t>(~0x10); pc_=static_cast<uint16_t>(read(vector)|(read(vector+1)<<8)); }

const std::array<Cpu6502::Instruction,256>& Cpu6502::table() {
    static const auto t=[] { std::array<Instruction,256> a{}; auto s=[&](int c,Op o,Mode m,int cy,bool pg=false){a[c]={o,m,static_cast<uint8_t>(cy),pg};};
#define I(code,op,mode,cy) s(code,Op::op,Mode::mode,cy)
#define P(code,op,mode,cy) s(code,Op::op,Mode::mode,cy,true)
    I(0x00,BRK,Imp,7); I(0x01,ORA,XInd,6); I(0x05,ORA,Zp,3); I(0x06,ASL,Zp,5); I(0x08,PHP,Imp,3); I(0x09,ORA,Imm,2); I(0x0A,ASL,Acc,2); I(0x0D,ORA,Abs,4); I(0x0E,ASL,Abs,6);
    I(0x10,BPL,Rel,2); P(0x11,ORA,IndY,5); I(0x15,ORA,ZpX,4); I(0x16,ASL,ZpX,6); I(0x18,CLC,Imp,2); P(0x19,ORA,AbsY,4); P(0x1D,ORA,AbsX,4); I(0x1E,ASL,AbsX,7);
    I(0x20,JSR,Abs,6); I(0x21,AND,XInd,6); I(0x24,BIT,Zp,3); I(0x25,AND,Zp,3); I(0x26,ROL,Zp,5); I(0x28,PLP,Imp,4); I(0x29,AND,Imm,2); I(0x2A,ROL,Acc,2); I(0x2C,BIT,Abs,4); I(0x2D,AND,Abs,4); I(0x2E,ROL,Abs,6);
    I(0x30,BMI,Rel,2); P(0x31,AND,IndY,5); I(0x35,AND,ZpX,4); I(0x36,ROL,ZpX,6); I(0x38,SEC,Imp,2); P(0x39,AND,AbsY,4); P(0x3D,AND,AbsX,4); I(0x3E,ROL,AbsX,7);
    I(0x40,RTI,Imp,6); I(0x41,EOR,XInd,6); I(0x45,EOR,Zp,3); I(0x46,LSR,Zp,5); I(0x48,PHA,Imp,3); I(0x49,EOR,Imm,2); I(0x4A,LSR,Acc,2); I(0x4C,JMP,Abs,3); I(0x4D,EOR,Abs,4); I(0x4E,LSR,Abs,6);
    I(0x50,BVC,Rel,2); P(0x51,EOR,IndY,5); I(0x55,EOR,ZpX,4); I(0x56,LSR,ZpX,6); I(0x58,CLI,Imp,2); P(0x59,EOR,AbsY,4); P(0x5D,EOR,AbsX,4); I(0x5E,LSR,AbsX,7);
    I(0x60,RTS,Imp,6); I(0x61,ADC,XInd,6); I(0x65,ADC,Zp,3); I(0x66,ROR,Zp,5); I(0x68,PLA,Imp,4); I(0x69,ADC,Imm,2); I(0x6A,ROR,Acc,2); I(0x6C,JMP,Ind,5); I(0x6D,ADC,Abs,4); I(0x6E,ROR,Abs,6);
    I(0x70,BVS,Rel,2); P(0x71,ADC,IndY,5); I(0x75,ADC,ZpX,4); I(0x76,ROR,ZpX,6); I(0x78,SEI,Imp,2); P(0x79,ADC,AbsY,4); P(0x7D,ADC,AbsX,4); I(0x7E,ROR,AbsX,7);
    I(0x81,STA,XInd,6); I(0x84,STY,Zp,3); I(0x85,STA,Zp,3); I(0x86,STX,Zp,3); I(0x88,DEY,Imp,2); I(0x8A,TXA,Imp,2); I(0x8C,STY,Abs,4); I(0x8D,STA,Abs,4); I(0x8E,STX,Abs,4);
    I(0x90,BCC,Rel,2); I(0x91,STA,IndY,6); I(0x94,STY,ZpX,4); I(0x95,STA,ZpX,4); I(0x96,STX,ZpY,4); I(0x98,TYA,Imp,2); I(0x99,STA,AbsY,5); I(0x9A,TXS,Imp,2); I(0x9D,STA,AbsX,5);
    I(0xA0,LDY,Imm,2); I(0xA1,LDA,XInd,6); I(0xA2,LDX,Imm,2); I(0xA4,LDY,Zp,3); I(0xA5,LDA,Zp,3); I(0xA6,LDX,Zp,3); I(0xA8,TAY,Imp,2); I(0xA9,LDA,Imm,2); I(0xAA,TAX,Imp,2); I(0xAC,LDY,Abs,4); I(0xAD,LDA,Abs,4); I(0xAE,LDX,Abs,4);
    I(0xB0,BCS,Rel,2); P(0xB1,LDA,IndY,5); I(0xB4,LDY,ZpX,4); I(0xB5,LDA,ZpX,4); I(0xB6,LDX,ZpY,4); I(0xB8,CLV,Imp,2); P(0xB9,LDA,AbsY,4); I(0xBA,TSX,Imp,2); P(0xBC,LDY,AbsX,4); P(0xBD,LDA,AbsX,4); P(0xBE,LDX,AbsY,4);
    I(0xC0,CPY,Imm,2); I(0xC1,CMP,XInd,6); I(0xC4,CPY,Zp,3); I(0xC5,CMP,Zp,3); I(0xC6,DEC,Zp,5); I(0xC8,INY,Imp,2); I(0xC9,CMP,Imm,2); I(0xCA,DEX,Imp,2); I(0xCC,CPY,Abs,4); I(0xCD,CMP,Abs,4); I(0xCE,DEC,Abs,6);
    I(0xD0,BNE,Rel,2); P(0xD1,CMP,IndY,5); I(0xD5,CMP,ZpX,4); I(0xD6,DEC,ZpX,6); I(0xD8,CLD,Imp,2); P(0xD9,CMP,AbsY,4); P(0xDD,CMP,AbsX,4); I(0xDE,DEC,AbsX,7);
    I(0xE0,CPX,Imm,2); I(0xE1,SBC,XInd,6); I(0xE4,CPX,Zp,3); I(0xE5,SBC,Zp,3); I(0xE6,INC,Zp,5); I(0xE8,INX,Imp,2); I(0xE9,SBC,Imm,2); I(0xEA,NOP,Imp,2); I(0xEC,CPX,Abs,4); I(0xED,SBC,Abs,4); I(0xEE,INC,Abs,6);
    I(0xF0,BEQ,Rel,2); P(0xF1,SBC,IndY,5); I(0xF5,SBC,ZpX,4); I(0xF6,INC,ZpX,6); I(0xF8,SED,Imp,2); P(0xF9,SBC,AbsY,4); P(0xFD,SBC,AbsX,4); I(0xFE,INC,AbsX,7);
#undef I
#undef P
    return a; }(); return t;
}
uint16_t Cpu6502::address(Mode m,bool* crossed) {
    if(crossed) *crossed=false;
    uint16_t base=0, result=0; uint8_t z=0;
    switch(m) {
    case Mode::Imm: return pc_++;
    case Mode::Zp: return fetch8();
    case Mode::ZpX: return static_cast<uint8_t>(fetch8()+x_);
    case Mode::ZpY: return static_cast<uint8_t>(fetch8()+y_);
    case Mode::Abs: return fetch16();
    case Mode::AbsX: base=fetch16(); result=static_cast<uint16_t>(base+x_); break;
    case Mode::AbsY: base=fetch16(); result=static_cast<uint16_t>(base+y_); break;
    case Mode::XInd: z=static_cast<uint8_t>(fetch8()+x_); return static_cast<uint16_t>(read(z)|(read(static_cast<uint8_t>(z+1))<<8));
    case Mode::IndY: z=fetch8(); base=static_cast<uint16_t>(read(z)|(read(static_cast<uint8_t>(z+1))<<8)); result=static_cast<uint16_t>(base+y_); break;
    case Mode::Ind: base=fetch16(); return static_cast<uint16_t>(read(base)|(read(static_cast<uint16_t>((base&0xFF00)|static_cast<uint8_t>(base+1)))<<8));
    case Mode::Rel: { int8_t off=static_cast<int8_t>(fetch8()); base=pc_; result=static_cast<uint16_t>(pc_+off); if(crossed) *crossed=(base&0xFF00)!=(result&0xFF00); return result; }
    default: return 0;
    }
    if(crossed) *crossed=(base&0xFF00)!=(result&0xFF00);
    return result;
}
int Cpu6502::step() {
    if(nmi_pending_) { nmi_pending_=false; interrupt(0xFFFA,false); return 7; }
    if(irq_pending_ && !(p_&0x04)) { irq_pending_=false; interrupt(0xFFFE,false); return 7; }
    const uint8_t code=fetch8(); const Instruction ins=table()[code]; bool crossed=false;
    const bool store=ins.op==Op::STA||ins.op==Op::STX||ins.op==Op::STY;
    uint16_t addr=0; uint8_t v=0; int cycles=ins.cycles;
    if(ins.mode!=Mode::Imp && ins.mode!=Mode::Acc) addr=address(ins.mode,&crossed);
    if(ins.page_cycle && crossed && !store) ++cycles;
    auto operand=[&](){return ins.mode==Mode::Acc?a_:read(addr);};
    auto save=[&](uint8_t n){if(ins.mode==Mode::Acc)a_=n;else write(addr,n);};
    switch(ins.op) {
    case Op::ADC: { v=read(addr); uint16_t sum=static_cast<uint16_t>(a_)+v+(p_&1); p_=static_cast<uint8_t>((p_&~0x41)|(((~(a_^v)&(a_^sum))&0x80)?0x40:0)| (sum>255?1:0)); a_=static_cast<uint8_t>(sum); set_nz(a_); break; }
    case Op::SBC: { v=read(addr); uint16_t val=static_cast<uint16_t>(v^0xFF); uint16_t sum=static_cast<uint16_t>(a_)+val+(p_&1); p_=static_cast<uint8_t>((p_&~0x41)|(((~(a_^val)&(a_^sum))&0x80)?0x40:0)|(sum>255?1:0)); a_=static_cast<uint8_t>(sum); set_nz(a_); break; }
    case Op::AND: a_&=read(addr); set_nz(a_); break; case Op::ORA:a_|=read(addr);set_nz(a_);break;case Op::EOR:a_^=read(addr);set_nz(a_);break;
    case Op::ASL: v=operand(); p_=static_cast<uint8_t>((p_&~1)|(v>>7)); v=static_cast<uint8_t>(v<<1);save(v);set_nz(v);break;
    case Op::LSR: v=operand();p_=static_cast<uint8_t>((p_&~1)|(v&1));v>>=1;save(v);set_nz(v);break;
    case Op::ROL: v=operand();{uint8_t c=p_&1;p_=static_cast<uint8_t>((p_&~1)|(v>>7));v=static_cast<uint8_t>((v<<1)|c);}save(v);set_nz(v);break;
    case Op::ROR: v=operand();{uint8_t c=(p_&1)?0x80:0;p_=static_cast<uint8_t>((p_&~1)|(v&1));v=static_cast<uint8_t>((v>>1)|c);}save(v);set_nz(v);break;
    case Op::BIT:v=read(addr);p_=static_cast<uint8_t>((p_&~0xC2)|(v&0xC0)|((a_&v)?0:2));break;
    case Op::CMP:compare(a_,read(addr));break;case Op::CPX:compare(x_,read(addr));break;case Op::CPY:compare(y_,read(addr));break;
    case Op::DEC:v=static_cast<uint8_t>(read(addr)-1);write(addr,v);set_nz(v);break;case Op::INC:v=static_cast<uint8_t>(read(addr)+1);write(addr,v);set_nz(v);break;
    case Op::DEX:--x_;set_nz(x_);break;case Op::DEY:--y_;set_nz(y_);break;case Op::INX:++x_;set_nz(x_);break;case Op::INY:++y_;set_nz(y_);break;
    case Op::LDA:a_=read(addr);set_nz(a_);break;case Op::LDX:x_=read(addr);set_nz(x_);break;case Op::LDY:y_=read(addr);set_nz(y_);break;
    case Op::STA:write(addr,a_);break;case Op::STX:write(addr,x_);break;case Op::STY:write(addr,y_);break;
    case Op::BCC:case Op::BCS:case Op::BEQ:case Op::BMI:case Op::BNE:case Op::BPL:case Op::BVC:case Op::BVS:{bool take=false;switch(ins.op){case Op::BCC:take=!(p_&1);break;case Op::BCS:take=p_&1;break;case Op::BEQ:take=p_&2;break;case Op::BMI:take=p_&0x80;break;case Op::BNE:take=!(p_&2);break;case Op::BPL:take=!(p_&0x80);break;case Op::BVC:take=!(p_&0x40);break;case Op::BVS:take=p_&0x40;break;default:break;}if(take){pc_=addr;++cycles;if(crossed)++cycles;}break;}
    case Op::JMP:pc_=addr;break;case Op::JSR:{uint16_t ret=static_cast<uint16_t>(pc_-1);push(ret>>8);push(ret&0xFF);pc_=addr;break;}
    case Op::RTS:{const uint8_t lo=pull();const uint8_t hi=pull();pc_=static_cast<uint16_t>((lo|(hi<<8))+1);break;}case Op::RTI:{p_=static_cast<uint8_t>((pull()|0x20)&~0x10);const uint8_t lo=pull();const uint8_t hi=pull();pc_=static_cast<uint16_t>(lo|(hi<<8));break;}
    case Op::BRK:++pc_;interrupt(0xFFFE,true);break;
    case Op::PHA:push(a_);break;case Op::PHP:push(static_cast<uint8_t>(p_|0x30));break;case Op::PLA:a_=pull();set_nz(a_);break;case Op::PLP:p_=static_cast<uint8_t>((pull()|0x20)&~0x10);break;
    case Op::CLC:p_&=~1;break;case Op::CLD:p_&=~8;break;case Op::CLI:p_&=~4;break;case Op::CLV:p_&=~0x40;break;case Op::SEC:p_|=1;break;case Op::SED:p_|=8;break;case Op::SEI:p_|=4;break;
    case Op::TAX:x_=a_;set_nz(x_);break;case Op::TAY:y_=a_;set_nz(y_);break;case Op::TSX:x_=sp_;set_nz(x_);break;case Op::TXA:a_=x_;set_nz(a_);break;case Op::TXS:sp_=x_;break;case Op::TYA:a_=y_;set_nz(a_);break;
    case Op::NOP:break;case Op::Ill: cycles=2;break;
    }
    p_=static_cast<uint8_t>((p_|0x20)&~0x10);
    return cycles;
}
}
