// Tool: runs a .nes file with the interpreter and with the recompiler (Unicorn) in lockstep
// and reports the first frame where the pictures differ. Usage: jit_rom_parity rom.nes [frames]
#include "jit_unicorn_backend.h"
#include "nes_machine.h"

#include <cstdio>
#include <fstream>
#include <iterator>

using namespace nes;

int main(int argc, char** argv) {
    if (argc < 2) { std::printf("usage: %s rom.nes [frames]\n", argv[0]); return 2; }
    const int frames = argc > 2 ? std::atoi(argv[2]) : 300;
    std::ifstream in(argv[1], std::ios::binary);
    std::vector<uint8_t> rom((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    NesMachine a, b;
    std::string error;
    if (!a.load_rom(rom.data(), rom.size(), &error)) { std::printf("SKIP %s: %s\n", argv[1], error.c_str()); return 3; }
    b.load_rom(rom.data(), rom.size(), &error);
    if (!b.use_jit_backend(std::make_unique<jit::UnicornBackend>(b.cpu_ram_data()))) { std::printf("jit init failed\n"); return 1; }
    std::array<uint8_t, 256 * 240> fa{}, fb{};
    for (int f = 0; f < frames; ++f) {
        const bool ra = a.run_frame(fa, &error), rb = b.run_frame(fb, &error);
        if (ra != rb) { std::printf("DIFF %s frame %d: run_frame result differs\n", argv[1], f); return 1; }
        if (!ra) { std::printf("STOP %s frame %d: %s\n", argv[1], f, error.c_str()); return 0; }
        {
            const bool same = a.cpu_cycle_count() == b.cpu_cycle_count() && a.program_counter() == b.program_counter() &&
                              a.cpu_a() == b.cpu_a() && a.cpu_x() == b.cpu_x() && a.cpu_y() == b.cpu_y() &&
                              a.cpu_sp() == b.cpu_sp() && a.cpu_status() == b.cpu_status();
            bool ram_same = true;
            for (uint16_t i = 0; i < 2048; ++i) ram_same = ram_same && a.cpu_peek_ram(i) == b.cpu_peek_ram(i);
            if (!same || !ram_same) {
                std::printf("DIFF %s frame %d: CPU state differs (cycles %llu/%llu pc %04X/%04X ram %s)\n", argv[1], f,
                            (unsigned long long)a.cpu_cycle_count(), (unsigned long long)b.cpu_cycle_count(),
                            a.program_counter(), b.program_counter(), ram_same ? "same" : "DIFFERENT");
                return 1;
            }
        }
        if (fa != fb) {
            int n = 0; for (size_t i = 0; i < fa.size(); ++i) n += fa[i] != fb[i];
            std::printf("DIFF %s frame %d: %d pixels differ\n", argv[1], f, n); return 1;
        }
    }
    std::printf("OK   %s: %d frames identical (jit blocks %llu, interpreted steps %llu, cycles %llu/%llu)\n", argv[1], frames,
                (unsigned long long)b.recompiled_blocks_run(), (unsigned long long)b.interpreted_steps(),
                (unsigned long long)a.cpu_cycle_count(), (unsigned long long)b.cpu_cycle_count());
    return 0;
}
