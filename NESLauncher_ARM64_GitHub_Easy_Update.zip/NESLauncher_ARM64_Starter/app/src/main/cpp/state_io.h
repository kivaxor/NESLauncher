#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <type_traits>
#include <vector>

namespace nes {

// Minimal binary writer/reader used by save states. Everything is written in host byte order; a
// state is only ever loaded by the same build family (the header carries a version, the machine
// also compares the exact size a save would produce).
class StateWriter {
public:
    explicit StateWriter(std::vector<uint8_t>& out) : out_(out) {}
    void bytes(const void* data, size_t size) {
        const auto* p = static_cast<const uint8_t*>(data);
        out_.insert(out_.end(), p, p + size);
    }
    template <class T>
    void pod(const T& value) {
        static_assert(std::is_trivially_copyable_v<T>, "state fields must be trivially copyable");
        bytes(&value, sizeof(T));
    }
    template <class T, size_t N>
    void pod_array(const std::array<T, N>& values) { bytes(values.data(), sizeof(T) * N); }

private:
    std::vector<uint8_t>& out_;
};

class StateReader {
public:
    StateReader(const uint8_t* data, size_t size) : data_(data), size_(size) {}
    bool bytes(void* out, size_t size) {
        if (!ok_ || size > size_ - pos_) { ok_ = false; return false; }
        if (size) std::memcpy(out, data_ + pos_, size);
        pos_ += size;
        return true;
    }
    template <class T>
    bool pod(T& value) {
        static_assert(std::is_trivially_copyable_v<T>, "state fields must be trivially copyable");
        return bytes(&value, sizeof(T));
    }
    template <class T, size_t N>
    bool pod_array(std::array<T, N>& values) { return bytes(values.data(), sizeof(T) * N); }
    bool ok() const { return ok_; }
    size_t remaining() const { return size_ - pos_; }

private:
    const uint8_t* data_;
    size_t size_;
    size_t pos_ = 0;
    bool ok_ = true;
};

} // namespace nes
