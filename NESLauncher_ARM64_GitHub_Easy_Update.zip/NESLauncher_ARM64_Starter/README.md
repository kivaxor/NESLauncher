# NES Launcher ARM64 — Native Emulator Foundation

This is an incremental development project, **not yet a complete or playable NES emulator**.

- Fixed missing page-crossing cycle penalties for ORA, AND, EOR, ADC, CMP, and SBC using indirect-indexed (`(zp),Y`) addressing, with a regression test covering all six opcodes.

## Pembaruan terbaru (2026-10-24): Recompiler dinamis 6502 → ARM64

Emulator kini punya **dynamic recompiler (JIT) ARM64 asli**, dengan interpreter sebagai cadangan.

- **Cara kerja** (`jit6502.cpp`, `a64.h`): blok dasar kode 6502 dari ROM ($8000–$FFFF) diterjemahkan ke kode mesin ARM64 saat pertama dijalankan, lalu di-cache per alamat. Register 6502 tinggal di register ARM64 (A/X/Y/SP, flag N/Z/C/V/I/D di register biasa, bukan NZCV, sehingga aman terhadap pemanggilan fungsi). Akses RAM dengan alamat tetap di-inline; akses lain (PPU, APU, controller, mapper) lewat fungsi bantu yang menyinkronkan PPU/APU lebih dulu.
- **Block chaining**: blok langsung melompat ke blok berikutnya lewat tabel (65536 entri) tanpa kembali ke C++; tiap blok memeriksa anggaran siklus di awalnya. Sebelum ini JIT justru lebih lambat dari interpreter karena rata-rata blok NES hanya ~3 siklus (loop tunggu seperti `BIT $2002 / BPL`) dan tiap blok melewati dispatcher C++.
- **Akurasi sama dengan interpreter**: blok tidak dijalankan bila bisa melewati event NMI/IRQ/akhir frame (`event_horizon()`), sehingga interupsi diambil pada instruksi yang persis sama; cache dibuang bila bank PRG berubah (`prg_signature()`); BRK, opcode tak resmi, kode di RAM dan interupsi tertunda tetap dijalankan interpreter.
- **Backend** (`jit_native_backend.cpp`): memori `mmap` yang diganti RW→RX per penulisan (W^X), hanya aktif di ARM64 Linux/Android. Jika mmap/mprotect gagal, otomatis memakai interpreter. Di perangkat x86_64 (emulator) interpreter dipakai.
- **UI**: tombol **JIT** di bilah atas (Aktif/Mati, tersimpan). Ada pengaman crash: jika aplikasi mati mendadak saat JIT aktif, JIT otomatis dimatikan pada peluncuran berikutnya.
- **Perbaikan terkait**: urutan evaluasi `pull()` di RTS/RTI dibuat eksplisit (sebelumnya urutan evaluasi C++ tidak terdefinisi); `NesMachine::run_frame` kini mengembalikan salinan frame yang diambil tepat saat frame selesai (`Ppu2C02::completed_frame()`).

### Verifikasi
Kode ARM64 hasil JIT dijalankan di emulator CPU **Unicorn** (target aarch64) dan dibandingkan dengan interpreter:
- `jit_diff_test`: ratusan ribu blok acak (semua 150 opcode resmi, state awal acak): register, flag, pc, siklus, RAM dan memori harus identik.
- `jit_machine_test`: ROM sintetis (PPU, NMI, OAM DMA, controller, APU): frame, audio, RAM dan jumlah siklus identik.
- `jit_rom_parity <rom.nes> [frame]`: menjalankan ROM nyata dengan kedua mode secara berdampingan; membandingkan frame, register CPU, RAM dan siklus tiap frame. Dicoba pada 149 ROM uji/homebrew publik (blargg instr_test/timing/interrupts/ppu_vbl_nmi/mmc3, demo raster, dll.): **semua identik** selama 300 frame (10 ROM dilewati karena mapper belum didukung).
- CI: job `recompiler-tests` membangun Unicorn dan menjalankan tes di atas.

Batasan: kecepatan JIT **belum diukur** dan APK belum dijalankan di perangkat ARM64 sungguhan (Unicorn menguji instruksi dan ABI, bukan `mmap`/izin eksekusi Android). Jika terjadi masalah, matikan lewat tombol JIT.

## Pembaruan sebelumnya (2026-10-23)

- **Mapper baru:** MMC1 (1), UxROM (2), CNROM (3), dan AxROM (7), selain NROM (0). `NromCartridge` kini alias untuk `Cartridge`. Mapper lain (mis. MMC3) ditolak dengan pesan jelas tanpa mengganggu game yang sedang berjalan.
- **PPU per-scanline:** tiap scanline digambar dari register loopy `v/t` (increment Y pada dot 256, salin horizontal pada dot 257, salin vertikal pada pre-render dot 280–304). Perubahan scroll di tengah frame (status bar, layar terbelah) kini berlaku mulai scanline berikutnya. Sprite dipilih per scanline (maks. 8, flag overflow), dan sprite-zero hit muncul pada dot piksel yang bertumpuk, bukan di akhir frame. Fungsi snapshot `render_background_frame()` dipertahankan untuk tes lama.
- **APU dasar:** pulse ×2 (envelope, sweep, length), triangle (linear counter), noise, frame counter 4/5-langkah dengan IRQ, dan mixer non-linear. DMC belum ada (register diterima, keluaran senyap). Audio mono 16-bit 44,1 kHz dikirim ke Android lewat `nativeTakeAudio` dan `AudioTrack` (write blocking, sehingga kecepatan emulasi mengikuti jam audio).
- **Perbaikan build:** `MainActivity` kini mewarisi `ComponentActivity` (sebelumnya `Activity`, yang tidak punya `registerForActivityResult` sehingga tidak akan lolos kompilasi). Gradle kini menetapkan `ndkVersion`, `buildToolsVersion`, dan target JVM 17 secara eksplisit; library native dibuat dengan alignment halaman 16 KiB.
- **CI:** workflow menjalankan 10 tes native dengan ASan + UBSan sebelum membangun APK.
- **Nama ZIP:** gunakan `NESLauncher_ARM64_GitHub_Easy_Update.zip` (tanpa akhiran `-1` dari unduhan ganda) agar `prepare-zip-source.sh` memilihnya secara langsung.

Batasan: renderer menggambar satu scanline pada dot 0 dari state yang dikunci saat itu, sehingga perubahan PPUCTRL/PPUMASK di tengah scanline baru berlaku di scanline berikutnya. Build Android dan audio belum diverifikasi di perangkat.

## Implemented
- Android launcher screen and Storage Access Framework ROM picker.
- JNI bridge to native C++, including ROM loading and 256×240 framebuffer transfer to Kotlin.
- iNES 1.0 / NES 2.0 header parsing, ROM length validation, trainer and metadata checks.
- CPU 6502/Ricoh 2A03 interpreter foundation with official-opcode coverage in progress.
- Mappers 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM) and 7 (AxROM): PRG/CHR banking, CHR ROM or CHR RAM, PRG RAM, trainer mapping, and header/mapper-controlled mirroring (including single-screen). iNES 1.0 only; NES 2.0 headers are rejected.
- PPU 2C02 register/memory foundation: CPU register mirrors, PPUADDR/PPUDATA, buffered reads, VRAM increment, palette aliases, horizontal/vertical/four-screen nametable mapping, and vblank/NMI flag behavior.
- `NesMachine` coordinator: loads supported NROM cartridges, executes CPU instructions, advances the PPU at 3 dots per CPU cycle, forwards NMI requests, and produces one framebuffer snapshot per frame. Reloading resets CPU RAM, PPU volatile memory/registers/timing, controller shift state, and frame count. ROM replacement is transactional at the JNI boundary: an invalid new ROM does not replace the currently active machine.
- Android preview controls: select a ROM, load NROM, request a single frame, or start/pause a continuous worker-thread frame loop. Bitmap and ARGB buffers are reused, display updates are coalesced, and the loop is stopped during Activity lifecycle transitions. The target is best-effort ~60 frame updates/s, not a guaranteed 60 FPS.
- Initial deterministic 256×240 snapshot renderer: background tile bitplanes, attribute-table palette selection, universal backdrop, coarse/fine horizontal and vertical scroll sampling across nametable boundaries, left-edge clipping, 8×8/8×16 sprites, horizontal/vertical flips, sprite palettes, OAM priority, behind-background priority, sprite-zero hit approximation, and scanline sprite-overflow approximation. This is a snapshot renderer, not a cycle-accurate PPU.
- Sprite priority regression fix (2026-10-23): snapshot composition now visits OAM entries from index 0 upward, so the lowest-numbered opaque sprite owns overlapping pixels; a two-sprite overlap test verifies the visible palette.
- Controller ports `$4016/$4017`: strobe/latch and serial A/B/Select/Start/Up/Down/Left/Right reads for two players; Android touch buttons send live player-one state through JNI. Basic OAM DMA at `$4014` copies a 256-byte CPU page into PPU OAM and models 513/514-cycle stalls from estimated CPU-cycle parity; exact alignment still awaits cycle-by-cycle bus scheduling.
- Native tests for parser, CPU subset, indirect-indexed page-crossing cycle penalties, NROM, PPU register/memory behavior, background pixels, sprite composition, priority, sprite-zero overlap, machine coordination, controller serial protocol, and OAM DMA transfer/stall handling.

## Native tests
Configure and run from this directory on a host with CMake and a C++20 compiler:

```sh
cmake -S app/src/main/cpp -B build-host -DBUILD_NES_TESTS=ON -DCMAKE_CXX_FLAGS='-Werror'
cmake --build build-host -j2
ctest --test-dir build-host --output-on-failure
```

Sanitizer configuration: add `-fsanitize=address,undefined -g` to `CMAKE_CXX_FLAGS` and `-fsanitize=address,undefined` to `CMAKE_EXE_LINKER_FLAGS`.

## Android build requirements
- Android Studio, Android SDK (project currently targets API 35), Android NDK, CMake, and JDK 17.
- Open this folder in Android Studio, sync Gradle, install prompted components, then build the debug APK.

This environment does not currently have a verified Android SDK/Gradle build path, so an APK has **not** been built or verified here.

## Known limitations / next milestones
- Android frame output is wired through JNI and a `Bitmap` preview, but it has not been compiled or tested in an Android APK in this environment. A continuous worker loop exists, but frame pacing and gameplay are not device-verified. PPU timing, scrolling, hardware-accurate sprite evaluation, and exact sprite-zero hit/overflow timing remain incomplete. Basic NTSC odd-frame dot skipping is now modeled when background or sprite rendering is enabled. The renderer produces a snapshot from current VRAM/OAM only.
- DMC audio, mappers beyond 0/1/2/3/7 (for example MMC3), and full machine save states are not implemented. The native cartridge API and JNI now expose exact 8 KiB battery-backed PRG RAM export/import hooks; Android private-file persistence/autosave is wired up for battery-backed PRG RAM, but has not been verified in an Android APK on-device. Controller support is currently limited to the standard serial button registers.
- CPU undocumented opcodes, edge-case behavior, interrupt timing, and cycle-accurate bus timing need more validation.
- The ARM64 recompiler exists (see above) but is verified only under emulation and on a host emulator; on-device speed and executable-memory permissions are unverified. Gameplay tests are not done.
- No claim of playable gameplay until Android build and legal homebrew test ROMs are validated.

## Recommended next milestones
1. Add MMC3 (mapper 4) with scanline IRQ, the DMC channel, and unofficial CPU opcodes.
2. Move toward a dot-accurate PPU fetch pipeline and cycle-stepped CPU bus timing.
3. Build and run the Android APK on an ARM64 device with legal homebrew test ROMs.
4. Measure the recompiler on a device, add block chaining and flag liveness analysis for more speed.

### Update PPU timing

- Clock NTSC PPU dasar: 3 dot per siklus CPU, scanline 0–261, VBlank pada scanline 241 dot 1, dan pembersihan status pada pre-render scanline 261 dot 1. Ini belum mencakup odd-frame dot skip atau raster rendering per-dot.
- Frame display updates are coalesced: if the main thread has not presented the prior queued frame yet, intermediate display updates are dropped instead of building an unbounded UI queue.


## Update: reset-safe ROM replacement

- Added `CpuBus::reset()` to clear CPU RAM, scratch memory, controller latch/shift state, and legacy PRG mapping without disconnecting attached devices.
- Added `Ppu2C02::reset()` to reset PPU registers, VRAM/OAM/palette/pattern RAM, NMI state, scanline/dot position, and frame counter while preserving the cartridge connection.
- `NesMachine::load_rom()` now resets volatile machine state after successful loads. Failed replacement attempts clear volatile state and do not permit continuing the previous game.
- Extended machine integration tests for ROM reload frame-counter reset and failed-ROM recovery.
- Strict `-Werror` native build: 6/6 tests passed. ASan + UBSan build: 6/6 tests passed.
- Android APK/device behavior remains unverified in this environment.


## Update: OAM DMA foundation (2026-10-23)

- Added `$4014` OAM DMA transfer from a CPU page into PPU OAM, respecting current OAMADDR and byte wrap.
- DMA stall cycles are consumed by the machine coordinator and included in PPU clock advancement. The instruction-stepped model selects 513/514 cycles from estimated parity; exact cycle-by-cycle bus contention is not yet modeled.
- Added regression test checking all 256 copied bytes, two source pages, OAM wrap, and one-shot stall consumption. Native strict and sanitizer suites: **7/7 passed**.


## Update: scroll-aware background snapshot (2026-10-23)

- Background snapshot rendering now reads the PPU scroll latch state populated by `$2005`, including coarse/fine X and Y offsets and base nametable selection from `t`.
- Background sampling crosses adjacent horizontal/vertical nametables and wraps within the 2×2 logical nametable space, while cartridge mirroring remains applied by the PPU memory mapper.
- Added regression checks for one-tile horizontal scroll and fine-X pixel sampling.
- Host C++20 strict build (`-Werror`): **7/7 tests passed**. Android APK/device validation is still outstanding; rendering remains snapshot-based rather than scanline/cycle accurate.


## Update: NTSC odd-frame timing (2026-10-23)

- Added the NTSC pre-render scanline odd-frame dot skip when either background or sprite rendering is enabled. Frame parity resets with `Ppu2C02::reset()` and toggles at frame boundaries.
- Added regression checks for rendered odd-frame duration (one dot shorter) and unchanged frame duration when rendering is disabled.
- Strict C++20 build with `-Werror`: **7/7 tests passed**. AddressSanitizer + UBSan: **7/7 tests passed**.
- Limitation: this improves frame timing only; the PPU remains snapshot-rendered and does not model the full per-dot background/sprite pipeline. Android APK/device gameplay is not verified.

### Grayscale palette output

The snapshot renderer applies `PPUMASK` bit 0 at final palette lookup, masking output color indices with `$30` in grayscale mode without modifying palette RAM. This is a palette-index approximation; emphasis-color output and per-dot video signal behavior are not modeled.

### Battery-backed PRG RAM API (2026-10-23)

- Added cartridge-level `export_battery_ram()` and `import_battery_ram()` for exact 8 KiB battery-backed PRG RAM blobs.
- Added JNI hooks `nativeExportBatteryRam()` and `nativeImportBatteryRam()` guarded by the machine mutex. These return RAM bytes / status messages for future Kotlin persistence integration.
- Import validates cartridge presence, battery flag, non-null data, and exact blob length. Non-battery cartridges cannot use these battery persistence hooks.
- Kotlin now stores battery RAM in app-private files using `AtomicFile`, keyed by the selected ROM bytes SHA-256. It attempts restore after loading that ROM and saves on pause, Activity lifecycle transitions, and before replacing a ROM. This covers battery-backed PRG RAM only, not full save states.


### Automatic Android battery saves (2026-10-23)

- Connected Kotlin to `nativeExportBatteryRam()` / `nativeImportBatteryRam()`.
- Battery RAM files are stored under app-private `filesDir/battery_saves/`, keyed by SHA-256 of the complete ROM bytes so unrelated ROMs do not share saves.
- Uses Android `AtomicFile` with `fd.sync()` to reduce risk of partial save files after interruption.
- Restores an existing save after successful ROM load; saves on emulation pause, Activity pause/destroy, and before attempting ROM replacement.
- Save persistence is only for cartridges declaring battery-backed PRG RAM. It is not a CPU/PPU save state.
- Native strict and sanitizer suites remain 7/7 passed. Android Gradle/APK build and on-device persistence tests remain unavailable in this environment.


### Perlindungan saat gagal memuat ROM

Parser cartridge memvalidasi ROM ke buffer sementara dan baru mengganti cartridge setelah seluruh validasi serta persiapan data berhasil. ROM rusak atau mapper yang belum didukung tidak menghapus game aktif maupun RAM baterainya. Ini adalah perlindungan di level cartridge dan mesin, bukan hanya di lapisan Android.

## Update: edge-triggered PPU NMI (2026-10-23)

- Corrected the PPU NMI request logic to model the NMI output as a line derived from `PPUSTATUS.VBlank` and `PPUCTRL.NMI-enable`. A request is queued only on a low-to-high transition, not every time `PPUCTRL` is rewritten while VBlank remains active.
- Enabling NMI during an already-active VBlank still creates the required rising edge; disabling and re-enabling creates a new edge. Reading `PPUSTATUS` clears VBlank and cancels a pending request.
- Added regression coverage for enable-during-VBlank, duplicate control writes, line drop/rise, and status-read cancellation.
- Strict C++20 `-Werror` build: **7/7 passed**. AddressSanitizer + UndefinedBehaviorSanitizer: **7/7 passed**.
- PPU remains a frame-snapshot renderer; accurate cycle-level NMI race timing and Android APK/device gameplay are not yet verified.


### Build APK langsung dari ZIP yang diunggah ke GitHub

Tidak perlu mengekstrak ZIP secara manual. Simpan file ZIP proyek (misalnya `NESLauncher_ARM64_Starter_ci_apk_build.zip`) di direktori utama repositori GitHub bersama folder `.github/workflows` dan `scripts`. Setelah ZIP di-commit/push ke cabang `main` atau `master`, workflow **Build Android APK** akan mendeteksi ZIP di direktori utama, memvalidasi isinya, mengekstraknya secara otomatis, lalu membangun APK. Workflow menolak entri arsip yang mencoba menulis di luar direktori ekstraksi dan memeriksa bahwa struktur Gradle Android ada.

Untuk menjalankan secara manual, buka **Actions → Build Android APK → Run workflow**. Kolom `source_zip` opsional menerima nama/path relatif ZIP di direktori utama; kosongkan untuk deteksi otomatis. Jika tidak ada ZIP di direktori utama, workflow menggunakan berkas proyek yang sudah ada di repositori. GitHub tidak menjalankan workflow hanya karena file ZIP diunggah ke halaman Releases/Artifacts; ZIP harus berada di repositori dan di-push, atau workflow dijalankan manual.

### Build APK Android (2026-10-23)

Proyek ini sekarang menyertakan alur CI GitHub Actions untuk membangun APK debug pada runner Linux dengan Java 17, Gradle 8.9, Android SDK 35, CMake 3.22.1, dan NDK 27.2.12479018. Jalankan workflow **Build Android APK** secara manual melalui tab Actions setelah sumber berada di repositori GitHub; APK akan tersedia sebagai artifact `NESLauncher-debug-apk` selama 14 hari. Workflow hanya menghasilkan APK debug yang belum ditandatangani untuk rilis.

Untuk build lokal, sediakan Java 17, Gradle 8.9, Android SDK platform 35, Build Tools 35.0.0, CMake 3.22.1, dan NDK 27.2.12479018, set `ANDROID_SDK_ROOT`, lalu jalankan:

```bash
./scripts/build-android-apk.sh
```

Skrip akan menyalin APK hasil build ke `dist/NESLauncher-debug.apk`. Lingkungan kerja saat ini tidak memiliki Android SDK/NDK atau Gradle, sehingga APK belum dapat dibuat atau diuji langsung di sini. Workflow CI ini ditambahkan sebagai jalur build yang dapat dijalankan setelah proyek didorong ke GitHub; keberhasilannya belum diklaim sebelum workflow benar-benar berjalan.


## Update: MMC3 (mapper 4) dan header NES 2.0

- **Header NES 2.0** kini diterima (ukuran PRG/CHR dan nomor mapper 12-bit dibaca; submapper dan ukuran RAM tambahan diabaikan).
- **MMC3 (mapper 4):** banking PRG 8 KiB (dua mode), banking CHR 2 KiB/1 KiB dengan inversi A12, kontrol mirroring, dan IRQ scanline (latch/reload/enable/ack). Penghitung di-clock sekali per scanline render pada dot 260 sebagai pendekatan tepi naik A12. Batasan: renderer berbasis snapshot per scanline, jadi pergantian bank CHR di tengah garis bisa bergeser sekitar satu baris dibanding perangkat keras asli.
- **UI:** layar game penuh lebar dengan piksel tajam, gamepad ala konsol, "Pilih ROM" langsung memuat dan memulai.
- Diuji di host dengan ASan+UBSan: 10 tes native lulus, plus ROM MMC3 sintetis yang menghasilkan 48 IRQ/frame (241 clock / periode 5) sesuai perhitungan. Belum diuji di perangkat dengan game MMC3 sungguhan.

### Kontrol virtual yang bisa dikustomisasi
Tombol **Kontrol** di bilah atas membuka menu:
- **Atur posisi & ukuran tombol:** emulasi dijeda, lalu seret tombol untuk memindah, ketuk untuk memilih, dan pakai **−** / **+** untuk mengubah ukuran (50%–200%). **Reset** mengembalikan tata letak awal, **Selesai** menyimpan dan melanjutkan emulasi.
- **Transparansi tombol** (20%–100%), **getaran** hidup/mati, dan **tombol Turbo A/B** (tampil/sembunyi; menekan = A/B ditekan otomatis ±15 kali per detik).
- Semua pengaturan disimpan di SharedPreferences dan dipakai lagi saat aplikasi dibuka.

D-pad kini satu kontrol: jari boleh digeser antar arah, diagonal otomatis, dan semua tombol mendukung multitouch penuh (mis. geser D-pad sambil menekan A + B). Kode ada di `VirtualPadView.kt`.

## Perubahan 2026-11-04 (lag, suara pecah, kontrol)

- **Suara pecah:** APU memakai filter rata-rata (box filter) atas semua siklus CPU per sampel keluaran, bukan
  mengambil satu titik (aliasing). Saluran **DMC sekarang diemulasikan** (sampel drum/suara game seperti Kunio-kun
  sebelumnya hening). IRQ DMC dan pencurian siklus CPU oleh DMC belum diemulasikan. Keluaran audio 48 kHz
  (tanpa resampling oleh sistem) dengan AudioTrack mode latensi rendah dan prioritas thread audio.
- **Lag / FPS turun:** JIT ARM64 sekarang **mati secara default** (kunci pengaturan baru `jit_enabled_v2`);
  interpreter memakai sekitar 1,2 ms/frame pada PC (jauh di bawah batas 16,6 ms) dan tidak punya jeda kompilasi.
  JIT tetap bisa dinyalakan dengan tombol JIT.
- **Kontrol:** sentuhan tidak lagi menunggu frame yang sedang berjalan (sebelumnya thread UI menunggu kunci
  native selama satu frame penuh). Status tombol disimpan atomik dan dipakai di awal tiap frame.
- Tes baru: DMC di `apu_test.cpp`. Semua 11 tes host lulus dengan ASan + UBSan.
